package com.wifitools.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Build
import java.net.ConnectException
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** Helpers shared by the background "Network Watch" job and the widget. */
object NetUtil {

    fun localIpv4(ctx: Context): String? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val lp = cm.getLinkProperties(cm.activeNetwork) ?: return null
        val la = lp.linkAddresses.firstOrNull { it.address is Inet4Address } ?: return null
        return la.address.hostAddress
    }

    fun isAlive(host: String): Boolean {
        val addr = InetAddress.getByName(host)
        try {
            if (addr.isReachable(400)) return true
        } catch (e: Exception) { }
        for (port in intArrayOf(80, 443, 53, 22, 445, 8080, 62078)) {
            val s = Socket()
            try {
                s.connect(InetSocketAddress(addr, port), 150)
                return true
            } catch (e: ConnectException) {
                return true
            } catch (e: Exception) {
            } finally {
                try { s.close() } catch (e: Exception) { }
            }
        }
        return false
    }

    /** Returns the IPs of all devices that answer on the local /24 network. */
    fun scanIps(ctx: Context): Set<String> {
        val me = localIpv4(ctx) ?: return emptySet()
        val base = me.substringBeforeLast(".")
        val pool = Executors.newFixedThreadPool(48)
        try {
            val tasks = (1..254).map { i ->
                Callable<String?> {
                    val h = "$base.$i"
                    if (h == me || isAlive(h)) h else null
                }
            }
            return pool.invokeAll(tasks)
                .mapNotNull { f -> try { f.get() } catch (e: Exception) { null } }
                .toSet()
        } finally {
            pool.shutdown()
        }
    }

    @Suppress("DEPRECATION")
    fun notifyNew(ctx: Context, title: String, text: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val chId = "wifi_watch"
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(chId, "Network Watch", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val pi = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, chId) else Notification.Builder(ctx)
        b.setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
        nm.notify((System.currentTimeMillis() % 100000).toInt(), b.build())
    }

    fun runWatch(ctx: Context) {
        val prefs = ctx.getSharedPreferences("wifitools", Context.MODE_PRIVATE)
        val known: Set<String> = HashSet(prefs.getStringSet("known", emptySet()) ?: emptySet())
        val now = scanIps(ctx)
        if (now.isEmpty()) return
        val fresh = now.filter { it !in known }
        if (fresh.isNotEmpty()) {
            notifyNew(
                ctx,
                "New device on your Wi-Fi",
                "Unknown device(s): " + fresh.joinToString(", ") + ". Open WiFi Tools to check."
            )
            prefs.edit().putStringSet("known", HashSet(known + fresh)).apply()
        }
    }
}

class WatchJobService : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        Thread {
            try {
                NetUtil.runWatch(applicationContext)
            } catch (e: Exception) {
            }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean = true
}
