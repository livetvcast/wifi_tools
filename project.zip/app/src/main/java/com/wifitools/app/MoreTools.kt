package com.wifitools.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Extra network tools. Every function returns text in the small markup
 * understood by MainActivity.render():
 *   "# Title", "key|value", "stat|Label|123|unit", "! note"
 */
class NetKit(private val ctx: Context) {

    // ------------------------------------------------------------------
    //  helpers
    // ------------------------------------------------------------------

    private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)

    private fun validHost(h: String) =
        h.isNotEmpty() && h.length <= 253 && Regex("^[A-Za-z0-9._:\\-]+$").matches(h)

    fun cleanHost(raw: String): String {
        var h = raw.trim()
        h = h.removePrefix("https://").removePrefix("http://")
        h = h.substringBefore("/").substringBefore("?")
        return h
    }

    private fun runCmd(args: List<String>, timeoutMs: Long): String {
        val p = ProcessBuilder(args).redirectErrorStream(true).start()
        val sb = StringBuilder()
        val t = Thread {
            try {
                p.inputStream.bufferedReader().forEachLine { sb.appendLine(it) }
            } catch (e: Exception) {
            }
        }
        t.start()
        t.join(timeoutMs)
        if (t.isAlive) {
            p.destroy()
            t.join(500)
        }
        return sb.toString()
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "WifiTools/3.0")
        return try {
            c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun localIp(): String? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val lp = cm.getLinkProperties(cm.activeNetwork) ?: return null
        val la = lp.linkAddresses.firstOrNull { it.address is Inet4Address } ?: return null
        return la.address.hostAddress
    }

    // ------------------------------------------------------------------
    //  Ping
    // ------------------------------------------------------------------

    fun ping(rawHost: String): String {
        val host = cleanHost(rawHost)
        if (!validHost(host)) return "Invalid host name."
        val out = try {
            runCmd(listOf("ping", "-c", "5", "-W", "2", host), 20000)
        } catch (e: Exception) {
            ""
        }
        val tx = Regex("(\\d+) packets transmitted, (\\d+)").find(out)
        val loss = Regex("(\\d+)% packet loss").find(out)
        val rtt = Regex("=\\s*([\\d.]+)/([\\d.]+)/([\\d.]+)").find(out)

        if (tx != null && rtt != null) {
            val sb = StringBuilder()
            sb.appendLine("stat|Average|${rtt.groupValues[2]}|ms")
            sb.appendLine("stat|Min|${rtt.groupValues[1]}|ms")
            sb.appendLine("stat|Max|${rtt.groupValues[3]}|ms")
            sb.appendLine("Host|$host")
            sb.appendLine("Sent|${tx.groupValues[1]}")
            sb.appendLine("Received|${tx.groupValues[2]}")
            sb.appendLine("Packet loss|${loss?.groupValues?.get(1) ?: "?"}%")
            return sb.toString()
        }
        if (tx != null) {
            return "# No reply from $host\n" +
                "Sent|${tx.groupValues[1]}\n" +
                "Received|${tx.groupValues[2]}\n" +
                "! The host may be offline or may block ping."
        }
        return tcpPing(host)
    }

    private fun tcpPing(host: String): String {
        val times = ArrayList<Long>()
        for (i in 1..5) {
            val s = Socket()
            try {
                val t = System.nanoTime()
                s.connect(InetSocketAddress(host, 443), 2000)
                times.add((System.nanoTime() - t) / 1_000_000)
            } catch (e: Exception) {
            } finally {
                try { s.close() } catch (e: Exception) { }
            }
        }
        if (times.isEmpty()) {
            return "# No reply from $host\n! ICMP ping is not available here and TCP port 443 did not answer."
        }
        return "stat|Average|${times.average().toLong()}|ms\n" +
            "stat|Min|${times.min()}|ms\n" +
            "stat|Max|${times.max()}|ms\n" +
            "Host|$host\n" +
            "! ICMP ping is unavailable, so TCP connect time to port 443 was measured instead."
    }

    // ------------------------------------------------------------------
    //  Traceroute
    // ------------------------------------------------------------------

    fun traceroute(rawHost: String, update: (String) -> Unit): String {
        val host = cleanHost(rawHost)
        if (!validHost(host)) return "Invalid host name."
        val sb = StringBuilder()
        sb.appendLine("# Route to $host")
        var reached = false
        var anyReply = false
        for (ttl in 1..25) {
            val out = try {
                runCmd(listOf("ping", "-c", "1", "-t", "$ttl", "-W", "2", host), 6000)
            } catch (e: Exception) {
                ""
            }
            val from = Regex("[Ff]rom\\s+(\\d{1,3}(?:\\.\\d{1,3}){3})").find(out)?.groupValues?.get(1)
            val time = Regex("time=([\\d.]+)\\s*ms").find(out)?.groupValues?.get(1)
            val isReply = out.contains("bytes from") && time != null
            if (from != null) anyReply = true
            val value = when {
                from == null -> "* no reply"
                time != null -> "$from  ($time ms)"
                else -> from
            }
            sb.appendLine("Hop $ttl|$value")
            update(sb.toString())
            if (isReply) {
                reached = true
                break
            }
        }
        if (!anyReply) {
            return "# Traceroute is not available\n" +
                "! This phone or network did not return ICMP replies. Some devices block it."
        }
        if (reached) {
            sb.appendLine("! A big jump in time between hops shows where the slowdown starts.")
        } else {
            sb.appendLine("! Stopped before the destination. Some routers hide themselves.")
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  Port scanner (common ports only, meant for your own devices)
    // ------------------------------------------------------------------

    private val ports = linkedMapOf(
        21 to "FTP", 22 to "SSH", 23 to "Telnet", 25 to "SMTP", 53 to "DNS", 80 to "HTTP",
        110 to "POP3", 135 to "RPC", 139 to "NetBIOS", 143 to "IMAP", 443 to "HTTPS",
        445 to "SMB (file sharing)", 554 to "RTSP (camera)", 631 to "IPP (printer)",
        993 to "IMAPS", 1723 to "PPTP VPN", 1883 to "MQTT", 3306 to "MySQL",
        3389 to "Remote Desktop", 5000 to "UPnP / NAS", 5900 to "VNC", 7547 to "TR-069 (ISP management)",
        8000 to "HTTP alt", 8080 to "HTTP alt", 8443 to "HTTPS alt", 8888 to "HTTP alt",
        9100 to "Printer (raw)", 49152 to "UPnP"
    )

    suspend fun portScan(rawHost: String, update: (String) -> Unit): String = coroutineScope {
        val host = cleanHost(rawHost)
        if (!validHost(host)) return@coroutineScope "Invalid host name."
        val addr = try {
            InetAddress.getByName(host)
        } catch (e: Exception) {
            return@coroutineScope "Cannot find host $host."
        }
        update("Scanning ${ports.size} common ports on $host ...")
        val openPorts = ConcurrentHashMap<Int, String>()
        val sem = Semaphore(32)
        ports.map { (port, name) ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    val s = Socket()
                    try {
                        s.connect(InetSocketAddress(addr, port), 600)
                        openPorts[port] = name
                    } catch (e: Exception) {
                    } finally {
                        try { s.close() } catch (e: Exception) { }
                    }
                }
            }
        }.awaitAll()

        val sb = StringBuilder()
        sb.appendLine("# ${openPorts.size} open port(s) on $host")
        if (openPorts.isEmpty()) {
            sb.appendLine("! No common ports answered. That is good for security.")
        }
        for (p in openPorts.keys.sorted()) sb.appendLine("$p|${openPorts[p]}")
        if (openPorts.containsKey(23)) sb.appendLine("! Telnet (23) is insecure. Turn it off if you can.")
        if (openPorts.containsKey(21)) sb.appendLine("! FTP (21) sends passwords in plain text.")
        sb.appendLine("! Only scan devices that belong to you.")
        sb.toString()
    }

    // ------------------------------------------------------------------
    //  DNS lookup (DNS over HTTPS via Cloudflare)
    // ------------------------------------------------------------------

    private val typeNums = linkedMapOf("A" to 1, "AAAA" to 28, "CNAME" to 5, "MX" to 15, "NS" to 2, "TXT" to 16)

    private fun doh(name: String, type: String): List<String> {
        val url = "https://cloudflare-dns.com/dns-query?name=${URLEncoder.encode(name, "UTF-8")}&type=$type"
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 7000
        c.setRequestProperty("accept", "application/dns-json")
        return try {
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val arr = j.optJSONArray("Answer")
            val want = typeNums[type] ?: -1
            val res = ArrayList<String>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optInt("type") == want) res.add(o.optString("data"))
                }
            }
            res
        } finally {
            c.disconnect()
        }
    }

    fun dnsLookup(rawDomain: String): String {
        val d = cleanHost(rawDomain)
        if (!validHost(d)) return "Invalid domain."
        val sb = StringBuilder()
        sb.appendLine("# DNS records for $d")
        var total = 0
        for (type in typeNums.keys) {
            val recs = try { doh(d, type) } catch (e: Exception) { emptyList() }
            for (r in recs) {
                sb.appendLine("$type|${r.replace("|", "/")}")
                total++
            }
        }
        if (total == 0) return "No records found for $d, or the lookup failed."
        sb.appendLine("! Answers come from Cloudflare DNS over HTTPS.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  Whois (RDAP)
    // ------------------------------------------------------------------

    fun whois(rawDomain: String): String {
        val d = cleanHost(rawDomain)
        if (!validHost(d) || !d.contains(".")) return "Enter a domain like example.com"
        val txt = try {
            val c = URL("https://rdap.org/domain/$d").openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.instanceFollowRedirects = true
            try {
                c.inputStream.bufferedReader().readText()
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            return "# No public record found\n" +
                "! The registry has no RDAP data for $d. Some country domains are not supported."
        }
        val j = try { JSONObject(txt) } catch (e: Exception) { return "Could not read the registry reply." }

        val sb = StringBuilder()
        sb.appendLine("# $d")

        val ev = j.optJSONArray("events")
        if (ev != null) {
            for (i in 0 until ev.length()) {
                val o = ev.getJSONObject(i)
                val label = when (o.optString("eventAction")) {
                    "registration" -> "Registered"
                    "expiration" -> "Expires"
                    "last changed" -> "Last changed"
                    else -> null
                }
                if (label != null) sb.appendLine("$label|${o.optString("eventDate").substringBefore("T")}")
            }
        }

        val st = j.optJSONArray("status")
        if (st != null && st.length() > 0) {
            val list = ArrayList<String>()
            for (i in 0 until st.length()) list.add(st.optString(i))
            sb.appendLine("Status|${list.joinToString(", ")}")
        }

        val ents = j.optJSONArray("entities")
        if (ents != null) {
            for (i in 0 until ents.length()) {
                val en = ents.getJSONObject(i)
                val roles = en.optJSONArray("roles")
                var isRegistrar = false
                if (roles != null) {
                    for (k in 0 until roles.length()) if (roles.optString(k) == "registrar") isRegistrar = true
                }
                if (!isRegistrar) continue
                val props = en.optJSONArray("vcardArray")?.optJSONArray(1) ?: continue
                for (k in 0 until props.length()) {
                    val item = props.optJSONArray(k) ?: continue
                    if (item.optString(0) == "fn") {
                        sb.appendLine("Registrar|${item.optString(3)}")
                        break
                    }
                }
            }
        }

        val ns = j.optJSONArray("nameservers")
        if (ns != null) {
            for (i in 0 until ns.length()) {
                sb.appendLine("Nameserver|${ns.getJSONObject(i).optString("ldhName").lowercase()}")
            }
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  VPN and DNS leak check
    // ------------------------------------------------------------------

    fun leakCheck(): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val vpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true

        val me = JSONObject(httpGet("https://ipinfo.io/json"))
        val ip = me.optString("ip", "-")
        val org = me.optString("org", "-")
        val country = me.optString("country", "-")

        val rIp = try {
            InetAddress.getAllByName("whoami.akamai.net").firstOrNull()?.hostAddress
        } catch (e: Exception) {
            null
        }
        var rOrg = "-"
        var rCountry = "-"
        if (rIp != null) {
            try {
                val r = JSONObject(httpGet("https://ipinfo.io/$rIp/json"))
                rOrg = r.optString("org", "-")
                rCountry = r.optString("country", "-")
            } catch (e: Exception) {
            }
        }

        val sb = StringBuilder()
        sb.appendLine("# Connection")
        sb.appendLine("VPN|${if (vpn) "Active" else "Not detected"}")
        sb.appendLine("Public IP|$ip")
        sb.appendLine("ISP|$org ($country)")
        sb.appendLine("# DNS resolver the internet sees")
        sb.appendLine("Resolver IP|${rIp ?: "unknown"}")
        sb.appendLine("Owner|$rOrg ($rCountry)")

        val a1 = org.substringBefore(" ")
        val a2 = rOrg.substringBefore(" ")
        when {
            rIp == null -> sb.appendLine("! Could not detect your DNS resolver.")
            vpn && a1 != a2 -> sb.appendLine(
                "! Possible DNS leak: the VPN network ($org) and the DNS resolver ($rOrg) belong to different companies."
            )
            vpn -> sb.appendLine("! Looks consistent: DNS and VPN seem to use the same network.")
            else -> sb.appendLine("! No VPN detected. Your DNS questions go to $rOrg.")
        }
        sb.appendLine("! This is a quick check, not a complete leak test.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  Channel analyzer
    // ------------------------------------------------------------------

    private class Net(val ssid: String, val ch: Int, val f: Int, val level: Int, val bssid: String)

    private fun channelOf(f: Int): Int = when {
        f == 2484 -> 14
        f in 2412..2472 -> (f - 2407) / 5
        f in 5000..5895 -> (f - 5000) / 5
        f >= 5955 -> (f - 5950) / 5
        else -> 0
    }

    private fun bandOf(f: Int) = when {
        f < 3000 -> "2.4 GHz"
        f < 5900 -> "5 GHz"
        else -> "6 GHz"
    }

    @Suppress("DEPRECATION")
    fun channels(update: (String) -> Unit): String {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!wm.isWifiEnabled) return "Wi-Fi is turned off."
        update("Scanning nearby Wi-Fi networks...")
        try { wm.startScan() } catch (e: Exception) { }
        Thread.sleep(3500)
        val results: List<ScanResult>? = try { wm.scanResults } catch (e: SecurityException) { null }
        if (results == null) return "Location permission is needed to scan nearby networks."
        if (results.isEmpty()) return "No networks found.\nTurn Location ON, allow the permission, and try again."

        val nets = results.map { Net(it.SSID ?: "", channelOf(it.frequency), it.frequency, it.level, it.BSSID ?: "") }
        val own = wm.connectionInfo
        val ownBssid = own?.bssid ?: ""
        val ownF = own?.frequency ?: 0

        val n24 = nets.filter { it.f in 2400..2500 }
        var best24 = 1
        var bestScore = Int.MAX_VALUE
        for (c in intArrayOf(1, 6, 11)) {
            var score = 0
            for (nn in n24) if (Math.abs(nn.ch - c) <= 4) score += maxOf(0, 100 + nn.level)
            if (score < bestScore) {
                bestScore = score
                best24 = c
            }
        }
        var overlap24 = 0
        for (nn in n24) if (Math.abs(nn.ch - best24) <= 4) overlap24++

        val n5 = nets.filter { it.f in 5000..5895 }
        var best5 = 36
        var bestCount = Int.MAX_VALUE
        for (c in intArrayOf(36, 40, 44, 48, 149, 153, 157, 161)) {
            val cnt = n5.count { it.ch == c }
            if (cnt < bestCount) {
                bestCount = cnt
                best5 = c
            }
        }

        val sb = StringBuilder()
        sb.appendLine("# Best channel for your router")
        sb.appendLine("2.4 GHz|Channel $best24 ($overlap24 network(s) overlap)")
        sb.appendLine("5 GHz|Channel $best5 ($bestCount network(s) on it)")
        if (ownF > 0) sb.appendLine("Your router now|Channel ${channelOf(ownF)} (${bandOf(ownF)})")

        sb.appendLine("# Nearby networks (${nets.size})")
        for (n in nets.sortedByDescending { it.level }.take(25)) {
            val name = (if (n.ssid.isEmpty()) "(hidden)" else n.ssid).replace("|", "/")
            val me = if (ownBssid.isNotEmpty() && n.bssid.equals(ownBssid, ignoreCase = true)) "  (you)" else ""
            sb.appendLine("$name  \u2022  ch ${n.ch}$me|${n.level} dBm")
        }
        sb.appendLine("! Change the channel in your router settings. Use the Router Page tile to open it.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  Wake-on-LAN
    // ------------------------------------------------------------------

    fun sendWol(rawMac: String): String {
        val clean = rawMac.trim().replace("-", ":").uppercase()
        if (!Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$").matches(clean)) {
            return "Invalid MAC address.\nUse the format AA:BB:CC:DD:EE:FF"
        }
        val macBytes = clean.split(":").map { it.toInt(16).toByte() }.toByteArray()
        val packet = ByteArray(6 + 16 * 6)
        for (i in 0 until 6) packet[i] = 0xFF.toByte()
        for (i in 0 until 16) System.arraycopy(macBytes, 0, packet, 6 + i * 6, 6)

        val targets = ArrayList<InetAddress>()
        targets.add(InetAddress.getByName("255.255.255.255"))
        val ip = localIp()
        if (ip != null) targets.add(InetAddress.getByName(ip.substringBeforeLast(".") + ".255"))

        var sent = 0
        val s = DatagramSocket()
        try {
            s.broadcast = true
            for (t in targets) {
                for (port in intArrayOf(9, 7)) {
                    try {
                        s.send(DatagramPacket(packet, packet.size, t, port))
                        sent++
                    } catch (e: Exception) {
                    }
                }
            }
        } finally {
            s.close()
        }
        if (sent == 0) return "Could not send the packet. Are you connected to Wi-Fi?"
        return "# Magic packet sent\n" +
            "MAC|$clean\n" +
            "Packets|$sent\n" +
            "! The PC must have Wake-on-LAN enabled in its BIOS and network settings."
    }
}
