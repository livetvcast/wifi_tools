package com.wifitools.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.widget.RemoteViews

/** Home-screen widget: shows the Wi-Fi name, signal and IP. Tap to open the app. */
class WifiWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, build(context))
        }
    }

    @Suppress("DEPRECATION")
    private fun build(context: Context): RemoteViews {
        val rv = RemoteViews(context.packageName, R.layout.widget)
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val ip = NetUtil.localIpv4(context)
        val onWifi = ip != null && wm.isWifiEnabled && info != null && info.networkId != -1

        if (!onWifi) {
            rv.setTextViewText(R.id.w_ssid, "Not connected")
            rv.setTextViewText(R.id.w_detail, "Connect to a Wi-Fi network")
        } else {
            val ssid = info.ssid?.trim('"')
            val name = if (ssid.isNullOrEmpty() || ssid == "<unknown ssid>") "Wi-Fi" else ssid
            rv.setTextViewText(R.id.w_ssid, name)
            rv.setTextViewText(R.id.w_detail, "${info.rssi} dBm  \u2022  ${info.linkSpeed} Mbps\nIP $ip")
        }

        val pi = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        rv.setOnClickPendingIntent(R.id.widget_root, pi)
        return rv
    }
}
