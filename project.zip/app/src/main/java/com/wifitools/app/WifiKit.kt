package com.wifitools.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import javax.net.ssl.SSLException

object WifiKit {

    private fun wm(ctx: Context) = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private fun cm(ctx: Context) = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    fun channelOf(f: Int): Int = when {
        f == 2484 -> 14
        f in 2412..2472 -> (f - 2407) / 5
        f in 5000..5895 -> (f - 5000) / 5
        f >= 5955 -> (f - 5950) / 5
        else -> 0
    }

    fun bandOf(f: Int) = when {
        f < 3000 -> "2.4 GHz"
        f < 5900 -> "5 GHz"
        else -> "6 GHz"
    }

    private fun widthName(w: Int) = when (w) {
        0 -> "20 MHz"
        1 -> "40 MHz"
        2 -> "80 MHz"
        3 -> "160 MHz"
        4 -> "80+80 MHz"
        5 -> "320 MHz"
        else -> "-"
    }

    fun securityOf(cap: String): String {
        val c = cap.uppercase()
        return when {
            c.contains("SAE") && c.contains("PSK") -> "WPA2 / WPA3"
            c.contains("SAE") -> "WPA3"
            c.contains("WPA2") && c.contains("WPA-") -> "WPA / WPA2 (mixed)"
            c.contains("WPA2") -> "WPA2"
            c.contains("WPA") -> "WPA (old)"
            c.contains("WEP") -> "WEP (broken)"
            c.contains("OWE") -> "Enhanced Open"
            c.contains("EAP") -> "Enterprise (802.1X)"
            else -> "Open (no password)"
        }
    }

    private fun isWeak(sec: String) = sec.startsWith("WEP") || sec.startsWith("Open") || sec.startsWith("WPA (old)")

    @Suppress("DEPRECATION")
    private fun cached(ctx: Context): List<ScanResult> =
        try { wm(ctx).scanResults ?: emptyList() } catch (e: Exception) { emptyList() }

    @Suppress("DEPRECATION")
    private fun freshScan(ctx: Context): List<ScanResult>? {
        val w = wm(ctx)
        if (!w.isWifiEnabled) return emptyList()
        try { w.startScan() } catch (e: Exception) { }
        Thread.sleep(3000)
        return try { w.scanResults } catch (e: SecurityException) { null }
    }

    @Suppress("DEPRECATION")
    private fun own(ctx: Context): ScanResult? {
        val b = wm(ctx).connectionInfo?.bssid ?: return null
        return cached(ctx).firstOrNull { it.BSSID.equals(b, ignoreCase = true) }
    }

    private fun mask(prefix: Int): String {
        if (prefix <= 0 || prefix > 32) return "-"
        val m = (-1L shl (32 - prefix)) and 0xFFFFFFFFL
        return "${(m shr 24) and 255}.${(m shr 16) and 255}.${(m shr 8) and 255}.${m and 255}"
    }

    private fun ipOf(i: Int): String = "${i and 255}.${(i shr 8) and 255}.${(i shr 16) and 255}.${(i shr 24) and 255}"

    // ------------------------------------------------------------------
    //  17. Analyzer
    // ------------------------------------------------------------------

    @Suppress("DEPRECATION")
    fun analyzer(ctx: Context, update: (String) -> Unit): String {
        update("Scanning nearby Wi-Fi networks...")
        val results = freshScan(ctx) ?: return "Location permission is needed to scan nearby networks."
        if (results.isEmpty()) return "No networks found.\nTurn Wi-Fi and Location ON, allow the permission, and try again."
        val ownB = wm(ctx).connectionInfo?.bssid ?: ""
        val sorted = results.sortedByDescending { it.level }
        val n24 = results.count { it.frequency < 3000 }
        val n5 = results.count { it.frequency in 3000..5899 }
        val n6 = results.count { it.frequency >= 5900 }
        val weak = results.count { isWeak(securityOf(it.capabilities ?: "")) }

        val sb = StringBuilder()
        sb.appendLine("# Summary")
        sb.appendLine("Networks found|${results.size}")
        sb.appendLine("2.4 GHz|$n24")
        sb.appendLine("5 GHz|$n5")
        if (n6 > 0) sb.appendLine("6 GHz|$n6")
        sb.appendLine("Open or weak security|$weak")
        sb.appendLine("Strongest|${(sorted[0].SSID ?: "").ifEmpty { "(hidden)" }} (${sorted[0].level} dBm)")
        sb.appendLine("# Networks (strongest first)")
        for (r in sorted.take(30)) {
            val name = (r.SSID ?: "").ifEmpty { "(hidden)" }.replace("|", "/")
            val me = if (ownB.isNotEmpty() && r.BSSID.equals(ownB, ignoreCase = true)) "  (you)" else ""
            val sec = securityOf(r.capabilities ?: "")
            sb.appendLine("$name$me|${r.level} dBm")
            sb.appendLine("   ${bandOf(r.frequency)}  \u2022  ch ${channelOf(r.frequency)}  \u2022  $sec")
        }
        sb.appendLine("! Closer to 0 dBm is stronger. -50 is excellent, -70 is fair, -85 is very weak.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  21. Frequency checker
    // ------------------------------------------------------------------

    @Suppress("DEPRECATION")
    fun frequency(ctx: Context): String {
        val info = wm(ctx).connectionInfo
        val f = info?.frequency ?: 0
        if (info == null || info.networkId == -1 || f <= 0) return "Not connected to Wi-Fi."
        val me = own(ctx)
        val sb = StringBuilder()
        sb.appendLine("# Your connection")
        sb.appendLine("Band|${bandOf(f)}")
        sb.appendLine("Frequency|$f MHz")
        sb.appendLine("Channel|${channelOf(f)}")
        if (me != null) sb.appendLine("Channel width|${widthName(me.channelWidth)}")
        if (Build.VERSION.SDK_INT >= 30) sb.appendLine("Wi-Fi standard|${standardName(info.wifiStandard)}")
        sb.appendLine("# What it means")
        if (f < 3000) {
            sb.appendLine("2.4 GHz|Better range and walls, but slower and more crowded")
            sb.appendLine("! If the router is close, switch your phone to the 5 GHz network for more speed.")
        } else {
            sb.appendLine("5/6 GHz|Faster and less crowded, but shorter range")
            sb.appendLine("! If the signal drops in far rooms, try the 2.4 GHz network there.")
        }
        return sb.toString()
    }

    private fun standardName(s: Int) = when (s) {
        1 -> "Legacy (802.11a/b/g)"
        4 -> "Wi-Fi 4 (802.11n)"
        5 -> "Wi-Fi 5 (802.11ac)"
        6 -> "Wi-Fi 6 (802.11ax)"
        7 -> "802.11ad"
        8 -> "Wi-Fi 7 (802.11be)"
        else -> "Unknown"
    }

    // ------------------------------------------------------------------
    //  22. Connected details
    // ------------------------------------------------------------------

    @Suppress("DEPRECATION")
    fun details(ctx: Context): String {
        val w = wm(ctx)
        val info = w.connectionInfo
        if (info == null || info.networkId == -1) return "Not connected to Wi-Fi."
        val me = own(ctx)
        val props = cm(ctx).let { it.getLinkProperties(it.activeNetwork) }
        val ssid = info.ssid?.trim('"') ?: "-"
        val sb = StringBuilder()
        sb.appendLine("# Network")
        sb.appendLine("Name (SSID)|${if (ssid == "<unknown ssid>") "hidden (allow Location)" else ssid}")
        sb.appendLine("BSSID|${info.bssid ?: "-"}")
        sb.appendLine("Security|${if (me != null) securityOf(me.capabilities ?: "") else "-"}")
        sb.appendLine("Hidden network|${if (info.hiddenSSID) "Yes" else "No"}")
        if (Build.VERSION.SDK_INT >= 30) sb.appendLine("Wi-Fi standard|${standardName(info.wifiStandard)}")
        sb.appendLine("# Radio")
        sb.appendLine("Band|${if (info.frequency > 0) bandOf(info.frequency) else "-"}")
        sb.appendLine("Channel|${if (info.frequency > 0) channelOf(info.frequency).toString() else "-"}")
        if (me != null) sb.appendLine("Channel width|${widthName(me.channelWidth)}")
        sb.appendLine("Signal|${info.rssi} dBm")
        sb.appendLine("Link speed|${info.linkSpeed} Mbps")
        if (Build.VERSION.SDK_INT >= 29) {
            sb.appendLine("Receive speed|${info.rxLinkSpeedMbps} Mbps")
            sb.appendLine("Send speed|${info.txLinkSpeedMbps} Mbps")
        }
        sb.appendLine("# Addresses")
        val la = props?.linkAddresses?.firstOrNull { it.address is Inet4Address }
        sb.appendLine("Phone IP|${la?.address?.hostAddress ?: "-"}")
        sb.appendLine("Subnet mask|${if (la != null) mask(la.prefixLength) else "-"}")
        val gw = props?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress
        sb.appendLine("Router|${gw ?: "-"}")
        val dns = props?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()
        sb.appendLine("DNS|${if (dns.isEmpty()) "-" else dns.joinToString(", ")}")
        val d = w.dhcpInfo
        if (d != null && d.serverAddress != 0) {
            sb.appendLine("DHCP server|${ipOf(d.serverAddress)}")
            sb.appendLine("Lease time|${d.leaseDuration / 3600} hours")
        }
        sb.appendLine("Phone MAC|${if (info.macAddress == "02:00:00:00:00:00") "hidden by Android (random)" else info.macAddress}")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  25. Security check
    // ------------------------------------------------------------------

    @Suppress("DEPRECATION")
    fun securityCheck(ctx: Context): String {
        val info = wm(ctx).connectionInfo
        val sb = StringBuilder()
        if (info != null && info.networkId != -1) {
            val me = own(ctx)
            sb.appendLine("# Your network")
            if (me == null) {
                sb.appendLine("Security|Unknown (turn Location ON and run Wi-Fi Analyzer once)")
            } else {
                val sec = securityOf(me.capabilities ?: "")
                sb.appendLine("Security|$sec")
                val verdict = when {
                    sec.startsWith("WPA3") || sec.startsWith("WPA2 / WPA3") -> "\u2714 Excellent"
                    sec == "WPA2" -> "\u2714 Good"
                    sec.startsWith("WPA / WPA2") -> "\u26A0 Mixed mode, switch to WPA2 only"
                    sec.startsWith("Open") -> "\u2718 Open network, anyone can see your traffic"
                    sec.startsWith("WEP") -> "\u2718 Very weak, change it now"
                    sec.startsWith("WPA (old)") -> "\u2718 Old, change to WPA2 or WPA3"
                    else -> "\u2714 OK"
                }
                sb.appendLine("Verdict|$verdict")
            }
        }
        sb.append(Guides.securityGuide())
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  26. Router IP
    // ------------------------------------------------------------------

    fun routerIp(ctx: Context): String {
        val props = cm(ctx).let { it.getLinkProperties(it.activeNetwork) } ?: return "Not connected."
        val gw = props.routes.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress
            ?: return "No router address found. Connect to Wi-Fi first."
        val sb = StringBuilder()
        sb.appendLine("# Router (gateway)")
        sb.appendLine("IP address|$gw")
        sb.appendLine("Web page|http://$gw")
        sb.appendLine("btn|Open router page|open_router")
        sb.appendLine("! If the page does not open, your router may use another address. See the Router Login Guide.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  28. Troubleshooter
    // ------------------------------------------------------------------

    @Suppress("DEPRECATION")
    fun troubleshoot(ctx: Context, update: (String) -> Unit): String {
        val fix = ArrayList<String>()
        val sb = StringBuilder()
        val w = wm(ctx)
        sb.appendLine("# Checks")

        update("Checking the Wi-Fi radio...")
        val on = w.isWifiEnabled
        sb.appendLine("Wi-Fi switch|${if (on) "\u2714 On" else "\u2718 Off"}")
        if (!on) {
            fix.add("Turn Wi-Fi on.")
            sb.appendLine("# What to try")
            sb.appendLine("1. Turn Wi-Fi on")
            sb.appendLine("btn|Open Wi-Fi settings|wifi_settings")
            return sb.toString()
        }

        val info = w.connectionInfo
        val connected = info != null && info.networkId != -1
        sb.appendLine("Connected to a network|${if (connected) "\u2714 Yes" else "\u2718 No"}")
        if (!connected) {
            sb.appendLine("# What to try")
            sb.appendLine("1. Pick your network in Wi-Fi settings and enter the password again")
            sb.appendLine("2. Move closer to the router")
            sb.appendLine("btn|Open Wi-Fi settings|wifi_settings")
            return sb.toString()
        }

        val rssi = info.rssi
        val level = when {
            rssi >= -60 -> "\u2714 Strong"
            rssi >= -70 -> "\u2714 Good"
            rssi >= -80 -> "\u26A0 Weak"
            else -> "\u2718 Very weak"
        }
        sb.appendLine("Signal|$level ($rssi dBm)")
        if (rssi < -75) fix.add("Signal is weak. Move closer to the router or remove obstacles.")

        val props = cm(ctx).let { it.getLinkProperties(it.activeNetwork) }
        val ip = props?.linkAddresses?.firstOrNull { it.address is Inet4Address }?.address?.hostAddress
        val ipOk = ip != null && !ip.startsWith("169.254") && ip != "0.0.0.0"
        sb.appendLine("IP address|${if (ipOk) "\u2714 $ip" else "\u2718 ${ip ?: "none"}"}")
        if (!ipOk) fix.add("The router did not give an IP address. Forget the network and reconnect, or restart the router.")

        update("Checking the router...")
        val gw = props?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway
        var gwOk = false
        if (gw != null) {
            gwOk = try { gw.isReachable(1000) } catch (e: Exception) { false }
            if (!gwOk) {
                for (port in intArrayOf(80, 443, 53)) {
                    val s = Socket()
                    try {
                        s.connect(InetSocketAddress(gw, port), 500)
                        gwOk = true
                    } catch (e: java.net.ConnectException) {
                        gwOk = true
                    } catch (e: Exception) {
                    } finally {
                        try { s.close() } catch (e: Exception) { }
                    }
                    if (gwOk) break
                }
            }
        }
        sb.appendLine("Router reachable|${if (gwOk) "\u2714 ${gw?.hostAddress}" else "\u2718 No answer"}")
        if (!gwOk) fix.add("The router does not answer. Restart the router (unplug for 30 seconds).")

        update("Checking the internet...")
        var net = "fail"
        try {
            val c = URL("https://www.google.com/generate_204").openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            c.instanceFollowRedirects = false
            try {
                net = if (c.responseCode == 204) "ok" else "portal"
            } finally {
                c.disconnect()
            }
        } catch (e: SSLException) {
            net = "portal"
        } catch (e: Exception) {
            net = "fail"
        }
        sb.appendLine(
            "Internet|${when (net) { "ok" -> "\u2714 Working"; "portal" -> "\u26A0 Login page needed?"; else -> "\u2718 Not reachable" }}"
        )
        if (net == "portal") fix.add("This Wi-Fi may need a login (hotel, office, school). Open a browser and sign in.")
        if (net == "fail") fix.add("Router is fine but internet is down. Restart the router and modem, or contact your internet company.")

        update("Checking DNS...")
        val t0 = System.nanoTime()
        val dnsOk = try { InetAddress.getByName("example.com"); true } catch (e: Exception) { false }
        val dnsMs = (System.nanoTime() - t0) / 1_000_000
        sb.appendLine("DNS|${if (dnsOk) "\u2714 ${dnsMs} ms" else "\u2718 Failed"}")
        if (!dnsOk && net != "fail") fix.add("DNS is failing. Try Google (8.8.8.8) or Cloudflare (1.1.1.1) as Private DNS.")
        if (dnsOk && dnsMs > 400) fix.add("DNS is slow. Run the DNS Speed Test and switch to a faster server.")

        sb.appendLine("# What to try")
        if (fix.isEmpty()) {
            sb.appendLine("Everything looks fine.")
        } else {
            for ((i, f) in fix.withIndex()) sb.appendLine("${i + 1}. $f")
        }
        sb.appendLine("# Common fixes")
        sb.appendLine("1. Restart the router: unplug for 30 seconds")
        sb.appendLine("2. Forget the network on your phone and connect again")
        sb.appendLine("3. Use 5 GHz near the router and 2.4 GHz far away")
        sb.appendLine("4. Change the channel if many networks are around")
        sb.appendLine("btn|Open Wi-Fi settings|wifi_settings")
        return sb.toString()
    }
}
