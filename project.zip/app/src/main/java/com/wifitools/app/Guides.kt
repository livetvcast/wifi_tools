package com.wifitools.app

class OpEntry(val country: String, val name: String, val code: String)

/** A small reference list of mobile operators. It can be out of date. */
object OperatorDb {
    val all = listOf(
        OpEntry("Bangladesh", "Grameenphone", "470-01"),
        OpEntry("Bangladesh", "Robi", "470-02"),
        OpEntry("Bangladesh", "Banglalink", "470-03"),
        OpEntry("Bangladesh", "Teletalk", "470-04"),
        OpEntry("Bangladesh", "Airtel (merged into Robi)", "470-07"),
        OpEntry("India", "Jio", "404 / 405 (several codes)"),
        OpEntry("India", "Airtel", "404 / 405 (several codes)"),
        OpEntry("India", "Vi (Vodafone Idea)", "404 / 405 (several codes)"),
        OpEntry("India", "BSNL", "404 / 405 (several codes)"),
        OpEntry("Pakistan", "Jazz", "410-01"),
        OpEntry("Pakistan", "Ufone", "410-03"),
        OpEntry("Pakistan", "Zong", "410-04"),
        OpEntry("Pakistan", "Telenor", "410-06"),
        OpEntry("Nepal", "Nepal Telecom", "429-01"),
        OpEntry("Nepal", "Ncell", "429-02"),
        OpEntry("Sri Lanka", "Mobitel", "413-01"),
        OpEntry("Sri Lanka", "Dialog", "413-02"),
        OpEntry("Saudi Arabia", "STC", "420-01"),
        OpEntry("Saudi Arabia", "Mobily", "420-03"),
        OpEntry("Saudi Arabia", "Zain", "420-04"),
        OpEntry("UAE", "Etisalat (e&)", "424-02"),
        OpEntry("UAE", "du", "424-03"),
        OpEntry("Qatar", "Ooredoo", "427-01"),
        OpEntry("Qatar", "Vodafone Qatar", "427-02"),
        OpEntry("Kuwait", "Zain", "419-02"),
        OpEntry("Kuwait", "Ooredoo", "419-03"),
        OpEntry("Kuwait", "stc", "419-04"),
        OpEntry("Oman", "Omantel", "422-02"),
        OpEntry("Oman", "Ooredoo", "422-03"),
        OpEntry("Malaysia", "Maxis", "502-12"),
        OpEntry("Malaysia", "Celcom", "502-13"),
        OpEntry("Malaysia", "DiGi", "502-16"),
        OpEntry("Singapore", "Singtel", "525-01"),
        OpEntry("Singapore", "M1", "525-03"),
        OpEntry("Singapore", "StarHub", "525-05"),
        OpEntry("Indonesia", "Telkomsel", "510-10"),
        OpEntry("Indonesia", "Indosat", "510-01"),
        OpEntry("Indonesia", "XL Axiata", "510-11"),
        OpEntry("United Kingdom", "O2", "234-10"),
        OpEntry("United Kingdom", "Vodafone", "234-15"),
        OpEntry("United Kingdom", "Three", "234-20"),
        OpEntry("United Kingdom", "EE", "234-30"),
        OpEntry("United States", "T-Mobile", "310-260"),
        OpEntry("United States", "AT&T", "310-410"),
        OpEntry("United States", "Verizon", "311-480"),
        OpEntry("Turkey", "Turkcell", "286-01"),
        OpEntry("Turkey", "Vodafone", "286-02"),
        OpEntry("Turkey", "T\u00FCrk Telekom", "286-03"),
        OpEntry("Egypt", "Orange", "602-01"),
        OpEntry("Egypt", "Vodafone", "602-02"),
        OpEntry("Egypt", "Etisalat", "602-03")
    )

    fun find(code: String): OpEntry? {
        if (code.isEmpty()) return null
        return all.firstOrNull { it.code.replace("-", "") == code }
    }

    fun page(query: String, current: String): String {
        val q = query.trim().lowercase()
        val sb = StringBuilder()
        val mine = find(current)
        if (mine != null) {
            sb.appendLine("# Your SIM")
            sb.appendLine("${mine.name}|${mine.country} \u2022 ${mine.code}")
        } else if (current.isNotEmpty()) {
            sb.appendLine("# Your SIM")
            sb.appendLine("MCC-MNC|$current (not in this list)")
        }
        val hits = if (q.isEmpty() || q == "all") all else all.filter {
            it.country.lowercase().contains(q) || it.name.lowercase().contains(q) || it.code.contains(q)
        }
        if (hits.isEmpty()) {
            sb.appendLine("# No match")
            sb.appendLine("! Try a country name like Bangladesh, or type all to see everything.")
            return sb.toString()
        }
        var lastCountry = ""
        for (e in hits) {
            if (e.country != lastCountry) {
                sb.appendLine("# ${e.country}")
                lastCountry = e.country
            }
            sb.appendLine("${e.name}|${e.code}")
        }
        sb.appendLine("! MCC-MNC is the code your SIM and network report. This list is a reference and can be out of date.")
        return sb.toString()
    }
}

object Guides {

    fun preferredNetwork(): String = listOf(
        "# Choose your network mode",
        "1. Open Settings, then SIM cards or Mobile network",
        "2. Pick your SIM, then Preferred network type",
        "3. Choose the 5G/4G/3G/2G (auto) option for the best coverage",
        "# When to change it",
        "Weak 5G or battery drain|Use 4G (LTE) only",
        "Slow data in a weak area|Use the auto option",
        "No 5G option|Phone, SIM or plan may not support 5G",
        "! Apps cannot change this. Android only allows it from system settings.",
        "btn|Open mobile network settings|net_settings"
    ).joinToString("\n")

    fun volte(typeText: String, onLte: Boolean): String = listOf(
        "# VoLTE (HD calls over 4G)",
        "Current network|$typeText",
        "VoLTE possible|${if (onLte) "Yes, you are on 4G/5G" else "Not on 4G/5G right now"}",
        "! Android does not let normal apps read the VoLTE status. Check it in Settings, SIM or Mobile network, VoLTE or HD Voice.",
        "! Many phones also show IMS registration in the hidden phone-information screen of the dialer.",
        "btn|Open mobile network settings|net_settings"
    ).joinToString("\n")

    fun securityGuide(): String = listOf(
        "# Wi-Fi security levels",
        "WPA3|Best. Use it if your router and devices support it",
        "WPA2 (AES)|Good. Safe with a strong password",
        "WPA / TKIP|Old. Change it to WPA2 or WPA3",
        "WEP|Broken. Can be cracked in minutes. Never use it",
        "Open|No password. Anyone can read your traffic",
        "# Quick tips",
        "1. Use a long password (12+ characters) and not your phone number",
        "2. Change the router admin password",
        "3. Turn off WPS if you do not use it",
        "4. Update the router firmware",
        "5. Use a guest network for visitors and smart devices"
    ).joinToString("\n")

    fun bandGuide(): String = listOf(
        "# 2.4 GHz",
        "Range|Longer, goes through walls better",
        "Speed|Lower",
        "Crowding|High: many routers, microwaves and Bluetooth use it",
        "Best for|Far rooms, smart home gadgets",
        "# 5 GHz",
        "Range|Shorter",
        "Speed|Much faster",
        "Crowding|Low",
        "Best for|Streaming, gaming, video calls near the router",
        "# 6 GHz (Wi-Fi 6E / 7)",
        "Range|Shortest",
        "Speed|Fastest, very little crowding",
        "Best for|Newest phones and routers in the same room",
        "! Tip: use 5 GHz when you are close to the router and 2.4 GHz when you are far away."
    ).joinToString("\n")

    fun routerLogin(gateway: String?): String {
        val sb = StringBuilder()
        sb.appendLine("# Your router address")
        sb.appendLine("Address|${gateway ?: "Connect to Wi-Fi first"}")
        if (gateway != null) sb.appendLine("btn|Open router page|open_router")
        sb.appendLine("# Common router addresses")
        sb.appendLine("TP-Link|tplinkwifi.net or 192.168.0.1")
        sb.appendLine("Tenda|tendawifi.com or 192.168.0.1")
        sb.appendLine("D-Link|192.168.0.1")
        sb.appendLine("Xiaomi / Mi Router|miwifi.com or 192.168.31.1")
        sb.appendLine("Huawei|192.168.3.1 or 192.168.100.1")
        sb.appendLine("ZTE / fiber ONT|192.168.1.1 or 192.168.100.1")
        sb.appendLine("Netgear|routerlogin.net")
        sb.appendLine("Asus|router.asus.com")
        sb.appendLine("Linksys|192.168.1.1")
        sb.appendLine("# How to log in")
        sb.appendLine("1. Connect your phone to the router's Wi-Fi")
        sb.appendLine("2. Open a browser and type the address above")
        sb.appendLine("3. The username and password are usually printed on a sticker under the router")
        sb.appendLine("4. If your internet company installed it, they may have set their own password. Ask them")
        sb.appendLine("# If you forgot the password")
        sb.appendLine("! Holding the small Reset button for about 10 seconds restores factory settings. You must set up the internet and Wi-Fi again.")
        sb.appendLine("# After logging in")
        sb.appendLine("! Change the admin password, use WPA2/WPA3, turn off WPS and update the firmware.")
        return sb.toString()
    }
}
