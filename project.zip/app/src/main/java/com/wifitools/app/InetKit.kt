package com.wifitools.app

import android.content.Context
import android.net.ConnectivityManager
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.Locale
import javax.net.ssl.SSLException

internal fun shell(args: List<String>, timeoutMs: Long): String {
    val p = ProcessBuilder(args).redirectErrorStream(true).start()
    val sb = StringBuilder()
    val t = Thread {
        try {
            p.inputStream.bufferedReader().forEachLine { sb.appendLine(it) }
        } catch (e: Exception) {
        }
    }
    t.start()
    t.join(timeoutMs)
    if (t.isAlive) {
        p.destroy()
        t.join(500)
    }
    return sb.toString()
}

class InetKit(private val ctx: Context) {

    private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "WifiTools/3.0")
        return try {
            c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun getOrNull(url: String): String? = try { httpGet(url).trim() } catch (e: Exception) { null }

    /** Time to open a TCP connection, in ms. -1 means it failed. */
    fun tcpLatency(host: String, port: Int = 443, timeoutMs: Int = 2000): Long {
        val s = Socket()
        return try {
            val t0 = System.nanoTime()
            s.connect(InetSocketAddress(host, port), timeoutMs)
            (System.nanoTime() - t0) / 1_000_000
        } catch (e: Exception) {
            -1L
        } finally {
            try { s.close() } catch (e: Exception) { }
        }
    }

    private fun rate(jitter: Double) = when {
        jitter < 5 -> "\u2714 Excellent. Great for gaming and video calls."
        jitter < 15 -> "\u2714 Good. Fine for calls and streaming."
        jitter < 30 -> "\u26A0 Fair. Video calls may stutter sometimes."
        else -> "\u2718 Poor. Calls and games will lag."
    }

    // ------------------------------------------------------------------
    //  33. Jitter
    // ------------------------------------------------------------------

    fun jitter(rawHost: String, update: (String) -> Unit): String {
        val host = rawHost.trim()
        val vals = ArrayList<Long>()
        var lost = 0
        for (i in 1..20) {
            val v = tcpLatency(host)
            if (v < 0) lost++ else vals.add(v)
            update("Measuring... $i of 20")
            Thread.sleep(200)
        }
        if (vals.isEmpty()) return "# No reply from $host\n! The server did not answer on port 443."
        var diff = 0.0
        for (i in 1 until vals.size) diff += Math.abs(vals[i] - vals[i - 1])
        val jit = if (vals.size > 1) diff / (vals.size - 1) else 0.0
        val sb = StringBuilder()
        sb.appendLine("stat|Jitter|${f1(jit)}|ms")
        sb.appendLine("stat|Average|${vals.average().toLong()}|ms")
        sb.appendLine("stat|Max|${vals.max()}|ms")
        sb.appendLine("Host|$host")
        sb.appendLine("Lowest|${vals.min()} ms")
        sb.appendLine("Failed samples|$lost of 20")
        sb.appendLine("Verdict|${rate(jit)}")
        sb.appendLine("graph|Latency per sample (ms)|${vals.joinToString(",")}")
        sb.appendLine("! Jitter is how much the delay changes from one packet to the next. Lower is better.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  34. Packet loss
    // ------------------------------------------------------------------

    fun packetLoss(rawHost: String, update: (String) -> Unit): String {
        val host = rawHost.trim()
        update("Sending 30 test packets to $host ... (about 10 seconds)")
        val out = try {
            shell(listOf("ping", "-c", "30", "-i", "0.3", "-W", "1", host), 25000)
        } catch (e: Exception) {
            ""
        }
        val tx = Regex("(\\d+) packets transmitted, (\\d+)").find(out)
        var sent = 0
        var recv = 0
        var method = "ICMP ping"
        if (tx != null) {
            sent = tx.groupValues[1].toInt()
            recv = tx.groupValues[2].toInt()
        } else {
            method = "TCP connect (ICMP is not available)"
            sent = 30
            for (i in 1..30) {
                if (tcpLatency(host, 443, 1000) >= 0) recv++
                Thread.sleep(100)
            }
        }
        if (sent == 0) return "Could not run the test."
        val loss = (sent - recv) * 100.0 / sent
        val verdict = when {
            loss == 0.0 -> "\u2714 No loss. Excellent."
            loss < 1.0 -> "\u2714 Almost none. Fine."
            loss < 3.0 -> "\u26A0 Noticeable in calls and games."
            else -> "\u2718 High loss. Expect lag and drops."
        }
        val sb = StringBuilder()
        sb.appendLine("stat|Packet loss|${f1(loss)}|%")
        sb.appendLine("stat|Sent|$sent|packets")
        sb.appendLine("stat|Received|$recv|packets")
        sb.appendLine("Host|$host")
        sb.appendLine("Method|$method")
        sb.appendLine("Verdict|$verdict")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  36 / 43. Public IP and IPv4 / IPv6
    // ------------------------------------------------------------------

    fun publicIp(): String {
        val j = JSONObject(httpGet("https://ipinfo.io/json"))
        val ip = j.optString("ip", "-")
        val sb = StringBuilder()
        sb.appendLine("# Your public IP")
        sb.appendLine("IP address|$ip")
        sb.appendLine("Type|${classifyIp(ip)}")
        sb.appendLine("Provider|${j.optString("org", "-")}")
        sb.appendLine("Location (approx.)|${j.optString("city", "-")}, ${j.optString("country", "-")}")
        sb.appendLine("btn|Copy this result with the COPY button above|noop")
        sb.appendLine("! This is the address websites see. Everyone on your Wi-Fi shares it.")
        return sb.toString()
    }

    fun ipv46(): String {
        val v4 = getOrNull("https://api.ipify.org")
        val v6 = getOrNull("https://api6.ipify.org")
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val props = cm.getLinkProperties(cm.activeNetwork)
        val local6 = props?.linkAddresses
            ?.map { it.address }
            ?.filter { it is Inet6Address && !it.isLinkLocalAddress && !it.isLoopbackAddress }
            ?.mapNotNull { it.hostAddress?.substringBefore("%") } ?: emptyList()

        val sb = StringBuilder()
        sb.appendLine("# Public addresses")
        sb.appendLine("IPv4|${v4 ?: "not available"}")
        sb.appendLine("IPv6|${v6 ?: "not available"}")
        sb.appendLine("# This phone")
        sb.appendLine("IPv6 on this phone|${if (local6.isEmpty()) "none" else local6.first()}")
        val verdict = when {
            v4 != null && v6 != null -> "\u2714 Dual-stack: IPv4 and IPv6 both work"
            v4 != null -> "IPv4 only. This is normal on many networks."
            v6 != null -> "IPv6 only"
            else -> "\u2718 No internet"
        }
        sb.appendLine("# Verdict")
        sb.appendLine("Status|$verdict")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  37. Private IP checker
    // ------------------------------------------------------------------

    fun classifyIp(ip: String): String {
        if (ip.contains(":")) {
            val l = ip.lowercase()
            return when {
                l == "::1" -> "Loopback (this device)"
                l.startsWith("fe80") -> "Link-local (private, this network only)"
                l.startsWith("fc") || l.startsWith("fd") -> "Unique local (private)"
                else -> "Public (global IPv6)"
            }
        }
        val p = ip.split(".").mapNotNull { it.toIntOrNull() }
        if (p.size != 4 || p.any { it !in 0..255 }) return "Not a valid IP address"
        val a = p[0]
        val b = p[1]
        return when {
            a == 10 -> "Private (10.0.0.0/8)"
            a == 172 && b in 16..31 -> "Private (172.16.0.0/12)"
            a == 192 && b == 168 -> "Private (192.168.0.0/16)"
            a == 169 && b == 254 -> "Link-local (no DHCP reply)"
            a == 100 && b in 64..127 -> "Carrier-grade NAT (your ISP shares one public IP)"
            a == 127 -> "Loopback (this device)"
            a == 0 -> "Invalid (0.x.x.x)"
            a >= 224 -> "Multicast or reserved"
            else -> "Public"
        }
    }

    fun privateIp(other: String): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val props = cm.getLinkProperties(cm.activeNetwork)
        val v4 = props?.linkAddresses?.firstOrNull { it.address is Inet4Address }?.address?.hostAddress
        val gw = props?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress
        val sb = StringBuilder()
        sb.appendLine("# This phone")
        sb.appendLine("IPv4|${v4 ?: "-"}")
        sb.appendLine("Type|${if (v4 != null) classifyIp(v4) else "-"}")
        sb.appendLine("Router|${gw ?: "-"}")
        sb.appendLine("Router type|${if (gw != null) classifyIp(gw) else "-"}")
        val o = other.trim()
        if (o.isNotEmpty() && o != v4) {
            sb.appendLine("# Checked address")
            sb.appendLine("IP|$o")
            sb.appendLine("Type|${classifyIp(o)}")
        }
        sb.appendLine("# Good to know")
        sb.appendLine("Private IP|Used inside your home network. Not visible to websites")
        sb.appendLine("Public IP|The address websites see. Shared by everyone on your Wi-Fi")
        sb.appendLine("! If a result says Carrier-grade NAT, port forwarding from the internet will not work on that connection.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  39. Stability test
    // ------------------------------------------------------------------

    fun stability(update: (String) -> Unit): String {
        val total = 40
        val vals = ArrayList<Long>()
        var fails = 0
        var drops = 0
        var prevFail = false
        for (i in 1..total) {
            val v = tcpLatency("1.1.1.1", 443, 1500)
            if (v < 0) {
                fails++
                if (!prevFail) drops++
                prevFail = true
            } else {
                vals.add(v)
                prevFail = false
            }
            if (i % 2 == 0) {
                val sb = StringBuilder()
                sb.appendLine("# Testing... $i / $total seconds")
                sb.appendLine("Success|${vals.size}")
                sb.appendLine("Failed|$fails")
                if (vals.size >= 2) sb.appendLine("graph|Latency (ms)|${vals.takeLast(40).joinToString(",")}")
                update(sb.toString())
            }
            Thread.sleep(maxOf(0L, 1000L - maxOf(0L, v)))
        }
        val ok = vals.size
        val pct = ok * 100.0 / total
        val sb = StringBuilder()
        sb.appendLine("stat|Stability|${f1(pct)}|%")
        sb.appendLine("stat|Dropouts|$drops|times")
        sb.appendLine("stat|Failed|$fails|of $total")
        if (vals.isNotEmpty()) {
            var diff = 0.0
            for (i in 1 until vals.size) diff += Math.abs(vals[i] - vals[i - 1])
            val jit = if (vals.size > 1) diff / (vals.size - 1) else 0.0
            sb.appendLine("Average latency|${vals.average().toLong()} ms")
            sb.appendLine("Worst latency|${vals.max()} ms")
            sb.appendLine("Jitter|${f1(jit)} ms")
            sb.appendLine("graph|Latency (ms)|${vals.joinToString(",")}")
        }
        val verdict = when {
            pct >= 99.0 && drops == 0 -> "\u2714 Rock solid"
            pct >= 95.0 -> "\u2714 Mostly stable"
            pct >= 85.0 -> "\u26A0 Unstable, some dropouts"
            else -> "\u2718 Very unstable"
        }
        sb.appendLine("Verdict|$verdict")
        sb.appendLine("! The test checks a connection to 1.1.1.1 once a second for $total seconds.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  40. Website connectivity
    // ------------------------------------------------------------------

    fun website(raw: String): String {
        var u = raw.trim()
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
        val url = try { URL(u) } catch (e: Exception) { return "That does not look like a valid address." }
        val host = url.host
        val sb = StringBuilder()
        sb.appendLine("# $host")

        val t0 = System.nanoTime()
        val addrs = try {
            InetAddress.getAllByName(host)
        } catch (e: UnknownHostException) {
            return "# DNS failed\n! Cannot find $host. Check the spelling, or your DNS server may be down."
        } catch (e: Exception) {
            return "# DNS failed\n! ${e.message}"
        }
        sb.appendLine("DNS lookup|${(System.nanoTime() - t0) / 1_000_000} ms")
        val ip = addrs[0].hostAddress ?: host
        sb.appendLine("IP address|$ip")

        val port = if (url.port > 0) url.port else if (u.startsWith("https")) 443 else 80
        val tcp = tcpLatency(ip, port, 4000)
        sb.appendLine("TCP connect (port $port)|${if (tcp < 0) "failed" else "$tcp ms"}")
        if (tcp < 0) {
            sb.appendLine("! The server did not accept a connection. It may be down, or blocked on your network.")
            return sb.toString()
        }

        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = false
        c.setRequestProperty("User-Agent", "WifiTools/3.0")
        try {
            val t1 = System.nanoTime()
            val code = c.responseCode
            val ms = (System.nanoTime() - t1) / 1_000_000
            sb.appendLine("HTTP status|$code ${c.responseMessage ?: ""}")
            sb.appendLine("Response time|$ms ms")
            c.getHeaderField("Server")?.let { sb.appendLine("Server|${it.replace("|", "/")}") }
            c.getHeaderField("Content-Type")?.let { sb.appendLine("Content type|${it.substringBefore(";")}") }
            c.getHeaderField("Location")?.let { sb.appendLine("Redirects to|${it.replace("|", "/")}") }
            val verdict = when (code) {
                in 200..299 -> "\u2714 Website is reachable"
                in 300..399 -> "\u2714 Reachable (it redirects)"
                in 400..499 -> "\u26A0 Reachable, but the page returned an error ($code)"
                else -> "\u26A0 Server error ($code). The site itself has a problem"
            }
            sb.appendLine("Verdict|$verdict")
        } catch (e: SSLException) {
            sb.appendLine("! Secure connection (TLS) failed. A Wi-Fi login page or a wrong phone date and time can cause this.")
        } catch (e: SocketTimeoutException) {
            sb.appendLine("! The server connected but did not answer in time.")
        } catch (e: Exception) {
            sb.appendLine("! Request failed: ${e.message}")
        } finally {
            c.disconnect()
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  42. DNS speed test
    // ------------------------------------------------------------------

    private fun dnsQuery(server: InetAddress, domain: String): Long {
        return try {
            val baos = ByteArrayOutputStream()
            val d = DataOutputStream(baos)
            d.writeShort(0x4321)
            d.writeShort(0x0100)
            d.writeShort(1)
            d.writeShort(0)
            d.writeShort(0)
            d.writeShort(0)
            for (part in domain.split(".")) {
                d.writeByte(part.length)
                d.write(part.toByteArray())
            }
            d.writeByte(0)
            d.writeShort(1)
            d.writeShort(1)
            val data = baos.toByteArray()
            val s = DatagramSocket()
            try {
                s.soTimeout = 2000
                val t0 = System.nanoTime()
                s.send(DatagramPacket(data, data.size, server, 53))
                s.receive(DatagramPacket(ByteArray(512), 512))
                (System.nanoTime() - t0) / 1_000_000
            } finally {
                s.close()
            }
        } catch (e: Exception) {
            -1L
        }
    }

    private class DnsRow(val name: String, val ip: String, val host: String, val avg: Double, val fails: Int)

    fun dnsSpeed(update: (String) -> Unit): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val current = cm.getLinkProperties(cm.activeNetwork)?.dnsServers ?: emptyList()
        val list = ArrayList<DnsRow>()
        val domains = listOf("google.com", "wikipedia.org", "cloudflare.com")
        val servers = ArrayList<Triple<String, String, String>>()
        for ((i, s) in current.withIndex()) {
            val ip = s.hostAddress ?: continue
            if (ip.contains(":")) continue
            servers.add(Triple("Your DNS ${i + 1}", ip, ""))
        }
        servers.add(Triple("Google", "8.8.8.8", "dns.google"))
        servers.add(Triple("Cloudflare", "1.1.1.1", "one.one.one.one"))
        servers.add(Triple("Quad9", "9.9.9.9", "dns.quad9.net"))
        servers.add(Triple("OpenDNS", "208.67.222.222", ""))
        servers.add(Triple("AdGuard", "94.140.14.14", "dns-unfiltered.adguard.com"))

        for ((idx, sv) in servers.withIndex()) {
            update("Testing ${sv.first} (${idx + 1} of ${servers.size})...")
            val addr = InetAddress.getByName(sv.second)
            val times = ArrayList<Long>()
            var fails = 0
            for (d in domains) {
                for (rep in 1..2) {
                    val v = dnsQuery(addr, d)
                    if (v < 0) fails++ else times.add(v)
                }
            }
            list.add(DnsRow(sv.first, sv.second, sv.third, if (times.isEmpty()) -1.0 else times.average(), fails))
        }

        val ranked = list.filter { it.avg >= 0 }.sortedBy { it.avg }
        val sb = StringBuilder()
        sb.appendLine("# Fastest to slowest")
        for ((i, r) in ranked.withIndex()) {
            sb.appendLine("${i + 1}. ${r.name} (${r.ip})|${f1(r.avg)} ms${if (r.fails > 0) "  (${r.fails} failed)" else ""}")
        }
        val dead = list.filter { it.avg < 0 }
        for (r in dead) sb.appendLine("${r.name} (${r.ip})|no answer")
        if (ranked.isNotEmpty()) {
            val best = ranked[0]
            sb.appendLine("# Recommendation")
            sb.appendLine("Fastest|${best.name} (${f1(best.avg)} ms)")
            if (best.host.isNotEmpty()) {
                sb.appendLine("! To use it on your phone: Settings, Network, Private DNS, then enter ${best.host}")
                sb.appendLine("btn|Open network settings|private_dns")
            } else {
                sb.appendLine("! To use it, set ${best.ip} as the DNS server in your router or Wi-Fi settings.")
            }
        }
        sb.appendLine("! Each server is asked 6 questions. Results change with your location and network.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  45. Download test
    // ------------------------------------------------------------------

    fun downloadTest(update: (String) -> Unit): String {
        val c = URL("https://speed.cloudflare.com/__down?bytes=100000000").openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 10000
        val buf = ByteArray(128 * 1024)
        var total = 0L
        val start = System.nanoTime()
        var lastT = start
        var lastB = 0L
        val speeds = ArrayList<Double>()
        try {
            c.inputStream.use { s ->
                while (true) {
                    val n = s.read(buf)
                    if (n < 0) break
                    total += n
                    val now = System.nanoTime()
                    if (now - lastT >= 500_000_000L) {
                        val mbps = (total - lastB) * 8 / 1e6 / ((now - lastT) / 1e9)
                        speeds.add(mbps)
                        lastT = now
                        lastB = total
                        val avg = total * 8 / 1e6 / ((now - start) / 1e9)
                        val sb = StringBuilder()
                        sb.appendLine("stat|Now|${f1(mbps)}|Mbps")
                        sb.appendLine("stat|Average|${f1(avg)}|Mbps")
                        sb.appendLine("stat|Downloaded|${f1(total / 1e6)}|MB")
                        sb.appendLine("graph|Speed (Mbps)|${speeds.takeLast(40).joinToString(",") { f1(it) }}")
                        update(sb.toString())
                    }
                    if (now - start > 15_000_000_000L) break
                }
            }
        } finally {
            c.disconnect()
        }
        val secs = (System.nanoTime() - start) / 1e9
        val avg = total * 8 / 1e6 / secs
        val peak = speeds.maxOrNull() ?: avg
        val verdict = when {
            avg < 5 -> "Basic: browsing and SD video"
            avg < 25 -> "Good: HD video and video calls"
            avg < 100 -> "Very good: 4K video and many devices"
            else -> "Excellent: heavy downloads and gaming"
        }
        val sb = StringBuilder()
        sb.appendLine("stat|Average|${f1(avg)}|Mbps")
        sb.appendLine("stat|Peak|${f1(peak)}|Mbps")
        sb.appendLine("stat|Speed|${f1(avg / 8)}|MB/s")
        sb.appendLine("Data used|${f1(total / 1e6)} MB in ${f1(secs)} s")
        sb.appendLine("Good for|$verdict")
        if (speeds.size >= 2) sb.appendLine("graph|Speed (Mbps)|${speeds.joinToString(",") { f1(it) }}")
        sb.appendLine("! This test downloads up to 100 MB. Use Wi-Fi if your mobile data is limited.")
        return sb.toString()
    }
}
