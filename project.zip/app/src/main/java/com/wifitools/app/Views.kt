package com.wifitools.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/** The app logo, drawn in code so it can be animated (arcs appear one by one). */
class WifiLogoView(context: Context) : View(context) {
    var progress = 0f
        set(value) {
            field = value
            invalidate()
        }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        val left = (width - s) / 2f
        val top = (height - s) / 2f

        bgPaint.shader = LinearGradient(
            left, top, left + s, top + s,
            Color.parseColor("#38BDF8"), Color.parseColor("#7C3AED"),
            Shader.TileMode.CLAMP
        )
        rect.set(left, top, left + s, top + s)
        canvas.drawRoundRect(rect, s * 0.26f, s * 0.26f, bgPaint)

        val cx = left + s / 2f
        val cy = top + s * 0.67f
        arcPaint.strokeWidth = s * 0.075f
        val radii = floatArrayOf(0.15f, 0.27f, 0.39f)
        for (i in 0..2) {
            val a = (progress - (i + 1)).coerceIn(0f, 1f)
            if (a <= 0f) continue
            val r = s * radii[i] * (0.8f + 0.2f * a)
            arcPaint.alpha = (255 * a).toInt()
            rect.set(cx - r, cy - r, cx + r, cy + r)
            canvas.drawArc(rect, 225f, 90f, false, arcPaint)
        }
        val d = progress.coerceIn(0f, 1f)
        if (d > 0f) {
            dotPaint.alpha = (255 * d).toInt()
            canvas.drawCircle(cx, cy, s * 0.055f * d, dotPaint)
        }
    }
}

/** Four little signal bars. */
class SignalView(context: Context) : View(context) {
    var level = 0
        set(value) {
            field = value
            invalidate()
        }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val gap = w * 0.08f
        val bw = (w - gap * 3) / 4f
        for (i in 0 until 4) {
            val bh = h * (0.3f + 0.7f * (i / 3f))
            p.color = if (i < level) Color.WHITE else Color.parseColor("#55FFFFFF")
            val l = i * (bw + gap)
            canvas.drawRoundRect(l, h - bh, l + bw, h, bw / 3f, bw / 3f, p)
        }
    }
}

/** A simple line graph with a soft filled area. */
class GraphView(context: Context) : View(context) {
    var values: List<Float> = emptyList()
        set(v) {
            field = v
            invalidate()
        }
    var minV: Float? = null
    var maxV: Float? = null
    var lineColor: Int = Color.parseColor("#38BDF8")
    var gridColor: Int = Color.parseColor("#26344D")

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint().apply { strokeWidth = 2f }
    private val path = Path()
    private val area = Path()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = 8f * resources.displayMetrics.density

        grid.color = gridColor
        for (i in 0..3) {
            val y = pad + (h - 2 * pad) * i / 3f
            canvas.drawLine(pad, y, w - pad, y, grid)
        }
        if (values.size < 2) return

        val lo = minV ?: values.minOrNull() ?: 0f
        val hi = maxV ?: values.maxOrNull() ?: 1f
        val range = if (hi - lo < 1f) 1f else hi - lo
        val n = values.size

        path.reset()
        area.reset()
        for (i in 0 until n) {
            val x = pad + (w - 2 * pad) * i / (n - 1)
            val frac = ((values[i] - lo) / range).coerceIn(0f, 1f)
            val y = pad + (h - 2 * pad) * (1f - frac)
            if (i == 0) {
                path.moveTo(x, y)
                area.moveTo(x, h - pad)
                area.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                area.lineTo(x, y)
            }
        }
        area.lineTo(w - pad, h - pad)
        area.close()

        fill.color = lineColor
        fill.alpha = 40
        canvas.drawPath(area, fill)
        line.color = lineColor
        canvas.drawPath(path, line)
    }
}
