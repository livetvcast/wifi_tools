package com.wifitools.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.CellIdentityNr
import android.telephony.CellSignalStrengthGsm
import android.telephony.CellSignalStrengthLte
import android.telephony.CellSignalStrengthNr
import android.telephony.CellSignalStrengthWcdma
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MobSignal(val dbm: Int, val level: Int, val type: String)

class CellDesc(
    val type: String,
    val registered: Boolean,
    val dbm: Int,
    val ids: List<Pair<String, String>>,
    val band: String
)

object MobileKit {

    private const val NEED_LOC =
        "# Location permission needed\n" +
            "! Android only shows cell tower info to apps that have Location permission, and Location must be ON.\n" +
            "btn|Open app settings|app_settings\n" +
            "btn|Open location settings|location_settings"

    fun tm(ctx: Context): TelephonyManager = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

    fun hasPhonePerm(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    fun hasLocPerm(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun cm(ctx: Context) = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    // ------------------------------------------------------------------
    //  names
    // ------------------------------------------------------------------

    fun typeName(t: Int): String = when (t) {
        1 -> "GPRS"
        2 -> "EDGE"
        3 -> "UMTS"
        4 -> "CDMA"
        5 -> "EVDO rev.0"
        6 -> "EVDO rev.A"
        7 -> "1xRTT"
        8 -> "HSDPA"
        9 -> "HSUPA"
        10 -> "HSPA"
        11 -> "iDEN"
        12 -> "EVDO rev.B"
        13 -> "LTE"
        14 -> "eHRPD"
        15 -> "HSPA+"
        16 -> "GSM"
        17 -> "TD-SCDMA"
        18 -> "Wi-Fi calling (IWLAN)"
        19 -> "LTE-Advanced"
        20 -> "NR (5G)"
        else -> "Unknown"
    }

    fun generation(t: Int): String = when (t) {
        1, 2, 4, 7, 11, 16 -> "2G"
        3, 5, 6, 8, 9, 10, 12, 14, 15, 17 -> "3G"
        13, 19 -> "4G"
        20 -> "5G"
        18 -> "Wi-Fi calling"
        else -> "Unknown"
    }

    private fun simStateName(s: Int) = when (s) {
        1 -> "No SIM card"
        2 -> "Locked (PIN needed)"
        3 -> "Locked (PUK needed)"
        4 -> "Locked to a network"
        5 -> "Ready"
        6 -> "Not ready"
        7 -> "Disabled"
        8 -> "Card error"
        9 -> "Restricted"
        else -> "Unknown"
    }

    @Suppress("DEPRECATION")
    fun dataType(ctx: Context): Int {
        try {
            return tm(ctx).dataNetworkType
        } catch (e: Exception) {
        }
        val ni = cm(ctx).activeNetworkInfo
        return if (ni != null && ni.type == ConnectivityManager.TYPE_MOBILE) ni.subtype else 0
    }

    fun simOperatorCode(ctx: Context): String = try { tm(ctx).simOperator ?: "" } catch (e: Exception) { "" }

    private fun airplane(ctx: Context) =
        Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1

    private fun mobileDataSetting(ctx: Context): Int =
        try { Settings.Global.getInt(ctx.contentResolver, "mobile_data", -1) } catch (e: Exception) { -1 }

    private fun fmtBytes(b: Long): String = when {
        b < 0 -> "n/a"
        b < 1024L * 1024 -> "${b / 1024} KB"
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }

    // ------------------------------------------------------------------
    //  Signal
    // ------------------------------------------------------------------

    fun signal(ctx: Context): MobSignal? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val ss = tm(ctx).signalStrength ?: return null
            val list = ss.cellSignalStrengths
            if (list.isEmpty()) return null
            val cs = list[0]
            val dbm = cs.dbm
            if (dbm == Int.MAX_VALUE || dbm == 0) return null
            val type = when (cs) {
                is CellSignalStrengthNr -> "5G NR"
                is CellSignalStrengthLte -> "4G LTE"
                is CellSignalStrengthWcdma -> "3G"
                is CellSignalStrengthGsm -> "2G"
                else -> "Mobile"
            }
            MobSignal(dbm, cs.level, type)
        } catch (e: Exception) {
            null
        }
    }

    fun signalName(level: Int) = arrayOf("None", "Poor", "Fair", "Good", "Great")[level.coerceIn(0, 4)]

    // ------------------------------------------------------------------
    //  1. SIM information
    // ------------------------------------------------------------------

    fun simInfo(ctx: Context): String {
        val tm = tm(ctx)
        val sb = StringBuilder()
        sb.appendLine("# SIM overview")
        sb.appendLine("SIM slots on phone|${try { tm.phoneCount } catch (e: Exception) { 1 }}")
        sb.appendLine("SIM state|${simStateName(tm.simState)}")
        sb.appendLine("SIM operator|${(tm.simOperatorName ?: "").ifEmpty { "-" }}")
        sb.appendLine("MCC-MNC|${(tm.simOperator ?: "").ifEmpty { "-" }}")
        sb.appendLine("SIM country|${(tm.simCountryIso ?: "").uppercase().ifEmpty { "-" }}")
        if (hasPhonePerm(ctx)) {
            try {
                val sm = ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
                val subs = sm.activeSubscriptionInfoList ?: emptyList()
                sb.appendLine("# Active SIMs (${subs.size})")
                if (subs.isEmpty()) sb.appendLine("None active|-")
                for (s in subs) {
                    sb.appendLine("SIM ${s.simSlotIndex + 1}|${s.carrierName} (${s.displayName})")
                }
            } catch (e: Exception) {
                sb.appendLine("! Could not read the SIM list.")
            }
        } else {
            sb.appendLine("! Allow Phone permission to also list every SIM with its slot and carrier name.")
            sb.appendLine("btn|Open app settings|app_settings")
        }
        sb.appendLine("! Phone numbers, IMEI and SIM serial numbers are protected by Android and are not shown.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  2. Network type
    // ------------------------------------------------------------------

    fun networkType(ctx: Context): String {
        val t = dataType(ctx)
        val sb = StringBuilder()
        sb.appendLine("# Mobile network type")
        sb.appendLine("Generation|${generation(t)}")
        sb.appendLine("Technology|${typeName(t)}")
        sb.appendLine("Active connection|${LogKit.transport(ctx)}")
        if (t == 0) sb.appendLine("! Type unknown. Allow Phone permission, make sure a SIM is inserted and mobile data is on.")
        if (t == 20) sb.appendLine("! You are on the 5G radio now.")
        if (t == 13 || t == 19) sb.appendLine("! Some phones show a 5G icon while using 4G as the anchor. This tool shows the data radio in use.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  4. Operator
    // ------------------------------------------------------------------

    fun operatorInfo(ctx: Context): String {
        val tm = tm(ctx)
        val code = tm.networkOperator ?: ""
        val known = OperatorDb.find(code)
        val sb = StringBuilder()
        sb.appendLine("# Network operator")
        sb.appendLine("Name|${(tm.networkOperatorName ?: "").ifEmpty { "-" }}")
        sb.appendLine("MCC-MNC|${code.ifEmpty { "-" }}")
        if (known != null) sb.appendLine("In database|${known.name} (${known.country})")
        sb.appendLine("Country|${(tm.networkCountryIso ?: "").uppercase().ifEmpty { "-" }}")
        sb.appendLine("Roaming|${if (tm.isNetworkRoaming) "Yes" else "No"}")
        sb.appendLine("# Your SIM")
        sb.appendLine("SIM operator|${(tm.simOperatorName ?: "").ifEmpty { "-" }}")
        sb.appendLine("SIM MCC-MNC|${(tm.simOperator ?: "").ifEmpty { "-" }}")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  5. Mobile network status
    // ------------------------------------------------------------------

    fun mobileStatus(ctx: Context): String {
        val tm = tm(ctx)
        val cm = cm(ctx)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val sb = StringBuilder()
        sb.appendLine("# Radio")
        sb.appendLine("Airplane mode|${if (airplane(ctx)) "ON" else "Off"}")
        val md = mobileDataSetting(ctx)
        sb.appendLine("Mobile data setting|${when (md) { 1 -> "ON"; 0 -> "OFF"; else -> "Unknown" }}")
        val ds = when (tm.dataState) {
            0 -> "Disconnected"
            1 -> "Connecting"
            2 -> "Connected"
            3 -> "Suspended"
            else -> "Unknown"
        }
        sb.appendLine("Data connection|$ds")
        val act = when (tm.dataActivity) {
            1 -> "Receiving"
            2 -> "Sending"
            3 -> "Sending and receiving"
            4 -> "Dormant"
            else -> "Idle"
        }
        sb.appendLine("Data activity|$act")
        sb.appendLine("# Active connection")
        sb.appendLine("Using|${LogKit.transport(ctx)}")
        sb.appendLine("Metered|${if (cm.isActiveNetworkMetered) "Yes (data charges may apply)" else "No"}")
        if (caps != null) {
            sb.appendLine("Internet verified|${if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "Yes" else "No"}")
            sb.appendLine("Reported speed (est.)|\u2193 ${caps.linkDownstreamBandwidthKbps / 1000} Mbps  \u2191 ${caps.linkUpstreamBandwidthKbps / 1000} Mbps")
        }
        sb.appendLine("# Cell service")
        sb.appendLine("Operator|${(tm.networkOperatorName ?: "").ifEmpty { "-" }}")
        sb.appendLine("Network|${generation(dataType(ctx))}")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  6. SIM slot checker
    // ------------------------------------------------------------------

    fun slotChecker(ctx: Context): String {
        val tm = tm(ctx)
        val n = try { tm.phoneCount } catch (e: Exception) { 1 }
        val sb = StringBuilder()
        sb.appendLine("# SIM slots ($n)")
        for (slot in 0 until n) {
            val st = if (Build.VERSION.SDK_INT >= 26) tm.getSimState(slot) else tm.simState
            sb.appendLine("Slot ${slot + 1}|${simStateName(st)}")
        }
        if (hasPhonePerm(ctx)) {
            try {
                val sm = ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
                val subs = sm.activeSubscriptionInfoList ?: emptyList()
                if (subs.isNotEmpty()) sb.appendLine("# Carrier per slot")
                for (s in subs) sb.appendLine("Slot ${s.simSlotIndex + 1}|${s.carrierName}")
            } catch (e: Exception) {
            }
        }
        sb.appendLine("! Slot numbers follow the order used by Android and may be swapped on some phones.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  7. Data monitor
    // ------------------------------------------------------------------

    fun dataMonitor(ctx: Context): String {
        val mRx = TrafficStats.getMobileRxBytes()
        val mTx = TrafficStats.getMobileTxBytes()
        val tRx = TrafficStats.getTotalRxBytes()
        val tTx = TrafficStats.getTotalTxBytes()
        val uid = Process.myUid()
        val aRx = TrafficStats.getUidRxBytes(uid)
        val aTx = TrafficStats.getUidTxBytes(uid)

        val p = ctx.getSharedPreferences("wifitools", Context.MODE_PRIVATE)
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val now = if (mRx >= 0 && mTx >= 0) mRx + mTx else -1L
        if (p.getString("mob_base_date", "") != today || p.getLong("mob_base_bytes", 0L) > now) {
            p.edit().putString("mob_base_date", today).putLong("mob_base_bytes", maxOf(0L, now)).apply()
        }
        val base = p.getLong("mob_base_bytes", 0L)
        val sb = StringBuilder()
        sb.appendLine("# Mobile data (since the phone started)")
        sb.appendLine("Downloaded|${fmtBytes(mRx)}")
        sb.appendLine("Uploaded|${fmtBytes(mTx)}")
        sb.appendLine("Total|${fmtBytes(now)}")
        sb.appendLine("# Today")
        sb.appendLine("Used since first check today|${if (now >= 0) fmtBytes(maxOf(0L, now - base)) else "n/a"}")
        sb.appendLine("# All networks (Wi-Fi and mobile)")
        sb.appendLine("Downloaded|${fmtBytes(tRx)}")
        sb.appendLine("Uploaded|${fmtBytes(tTx)}")
        sb.appendLine("# This app")
        sb.appendLine("Downloaded|${fmtBytes(aRx)}")
        sb.appendLine("Uploaded|${fmtBytes(aTx)}")
        sb.appendLine("! Counters reset when the phone restarts. For exact billing numbers use your phone's data usage screen or your operator.")
        sb.appendLine("btn|Open data usage settings|data_usage")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  10. Roaming
    // ------------------------------------------------------------------

    fun roaming(ctx: Context): String {
        val tm = tm(ctx)
        val cm = cm(ctx)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val roam = tm.isNetworkRoaming
        val notRoaming = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_ROAMING)
        val setting = try { Settings.Global.getInt(ctx.contentResolver, Settings.Global.DATA_ROAMING, -1) } catch (e: Exception) { -1 }
        val sb = StringBuilder()
        sb.appendLine("# Roaming status")
        sb.appendLine("Roaming now|${if (roam) "YES" else "No"}")
        sb.appendLine("Network says|${if (notRoaming == null) "-" else if (notRoaming) "Not roaming" else "Roaming"}")
        sb.appendLine("Data roaming setting|${when (setting) { 1 -> "ON"; 0 -> "OFF"; else -> "Unknown" }}")
        sb.appendLine("Your SIM country|${(tm.simCountryIso ?: "").uppercase().ifEmpty { "-" }}")
        sb.appendLine("Network country|${(tm.networkCountryIso ?: "").uppercase().ifEmpty { "-" }}")
        if (roam && setting == 1) sb.appendLine("! You are roaming with data roaming ON. Extra charges may apply.")
        if (!roam) sb.appendLine("! You are on your home network.")
        sb.appendLine("btn|Open roaming settings|data_roaming")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  Cells (11, 14, 46)
    // ------------------------------------------------------------------

    private fun u(v: Int) = if (v == Int.MAX_VALUE || v < 0) "-" else v.toString()

    private fun plmnStr(mcc: String?, mnc: String?) = "${mcc ?: "-"}-${mnc ?: "-"}"

    private fun lteBand(e: Int): String {
        val r = listOf(
            0..599 to "B1 (2100)", 600..1199 to "B2 (1900)", 1200..1949 to "B3 (1800)",
            1950..2399 to "B4 (AWS)", 2400..2649 to "B5 (850)", 2750..3449 to "B7 (2600)",
            3450..3799 to "B8 (900)", 5010..5179 to "B12 (700)", 5180..5279 to "B13 (700)",
            5730..5849 to "B17 (700)", 6150..6449 to "B20 (800)", 8040..8689 to "B25 (1900)",
            8690..9039 to "B26 (850)", 9210..9659 to "B28 (700)", 37750..38249 to "B38 (2600 TDD)",
            38250..38649 to "B39 (1900 TDD)", 38650..39649 to "B40 (2300 TDD)", 39650..41589 to "B41 (2500 TDD)",
            66436..67335 to "B66 (AWS-3)", 68586..68935 to "B71 (600)"
        )
        for ((range, name) in r) if (e in range) return name
        return "-"
    }

    private fun describe(ci: CellInfo): CellDesc? {
        val reg = ci.isRegistered
        if (ci is CellInfoLte) {
            val id = ci.cellIdentity
            var band = lteBand(id.earfcn)
            if (Build.VERSION.SDK_INT >= 30 && id.bands.isNotEmpty()) band = id.bands.joinToString(" / ") { "B$it" }
            val plmn = if (Build.VERSION.SDK_INT >= 28) plmnStr(id.mccString, id.mncString) else "-"
            return CellDesc(
                "4G LTE", reg, ci.cellSignalStrength.dbm,
                listOf("Cell ID" to u(id.ci), "TAC" to u(id.tac), "PCI" to u(id.pci), "EARFCN" to u(id.earfcn), "MCC-MNC" to plmn),
                band
            )
        }
        if (ci is CellInfoGsm) {
            val id = ci.cellIdentity
            val plmn = if (Build.VERSION.SDK_INT >= 28) plmnStr(id.mccString, id.mncString) else "-"
            return CellDesc(
                "2G GSM", reg, ci.cellSignalStrength.dbm,
                listOf("Cell ID" to u(id.cid), "LAC" to u(id.lac), "ARFCN" to u(id.arfcn), "MCC-MNC" to plmn),
                "ARFCN ${u(id.arfcn)}"
            )
        }
        if (ci is CellInfoWcdma) {
            val id = ci.cellIdentity
            val plmn = if (Build.VERSION.SDK_INT >= 28) plmnStr(id.mccString, id.mncString) else "-"
            return CellDesc(
                "3G WCDMA", reg, ci.cellSignalStrength.dbm,
                listOf("Cell ID" to u(id.cid), "LAC" to u(id.lac), "PSC" to u(id.psc), "UARFCN" to u(id.uarfcn), "MCC-MNC" to plmn),
                "UARFCN ${u(id.uarfcn)}"
            )
        }
        if (Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr) {
            val id = ci.cellIdentity as CellIdentityNr
            var band = "ARFCN ${u(id.nrarfcn)}"
            if (Build.VERSION.SDK_INT >= 30 && id.bands.isNotEmpty()) band = id.bands.joinToString(" / ") { "n$it" }
            val nci = if (id.nci == Long.MAX_VALUE) "-" else id.nci.toString()
            return CellDesc(
                "5G NR", reg, ci.cellSignalStrength.dbm,
                listOf("Cell ID (NCI)" to nci, "TAC" to u(id.tac), "PCI" to u(id.pci), "NR-ARFCN" to u(id.nrarfcn), "MCC-MNC" to plmnStr(id.mccString, id.mncString)),
                band
            )
        }
        return null
    }

    fun cells(ctx: Context): List<CellDesc>? {
        if (!hasLocPerm(ctx)) return null
        val infos: List<CellInfo>? = try { tm(ctx).allCellInfo } catch (e: Exception) { null }
        if (infos == null) return null
        val out = ArrayList<CellDesc>()
        for (ci in infos) {
            try {
                val d = describe(ci)
                if (d != null) out.add(d)
            } catch (e: Exception) {
            }
        }
        return out.sortedByDescending { it.registered }
    }

    fun cellId(ctx: Context): String {
        val list = cells(ctx) ?: return NEED_LOC
        val serving = list.filter { it.registered }
        if (serving.isEmpty()) {
            return "# No serving cell data\n" +
                "! Your phone did not report one. Turn Location ON and mobile data ON, then try again. Some phones hide this."
        }
        val sb = StringBuilder()
        for ((i, c) in serving.withIndex()) {
            sb.appendLine("# Serving cell ${i + 1}  \u2022  ${c.type}")
            for ((k, v) in c.ids) sb.appendLine("$k|$v")
            sb.appendLine("Signal|${if (c.dbm == Int.MAX_VALUE) "-" else "${c.dbm} dBm"}")
        }
        sb.appendLine("! The Cell ID identifies the tower sector you are connected to. It stays on your phone.")
        return sb.toString()
    }

    fun bands(ctx: Context): String {
        val list = cells(ctx) ?: return NEED_LOC
        if (list.isEmpty()) return "# No band data\n! Your phone did not report cell information. Turn Location ON and try again."
        val sb = StringBuilder()
        sb.appendLine("# Bands in use")
        for (c in list.take(8)) {
            sb.appendLine("${c.type}${if (c.registered) "  (serving)" else ""}|${c.band}")
        }
        if (Build.VERSION.SDK_INT < 30) {
            sb.appendLine("! Exact band lists need Android 11 or newer. LTE bands here are estimated from the channel number.")
        }
        sb.appendLine("! Bands the phone supports are not shown. Android hides that list from apps.")
        return sb.toString()
    }

    fun nearbyCells(ctx: Context): String {
        val list = cells(ctx) ?: return NEED_LOC
        if (list.isEmpty()) return "# No cells reported\n! Turn Location ON and mobile data ON, then try again."
        val sb = StringBuilder()
        sb.appendLine("# Cells around you (${list.size})")
        for (c in list.take(20)) {
            val id = c.ids.firstOrNull()?.second ?: "-"
            val dbm = if (c.dbm == Int.MAX_VALUE) "-" else "${c.dbm} dBm"
            sb.appendLine("${c.type}  \u2022  ${if (c.registered) "serving" else "neighbor"}  \u2022  ID $id|$dbm")
        }
        sb.appendLine("! Stronger (closer to 0) dBm is better. Neighbor cells are towers your phone can also hear.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  9. VoLTE
    // ------------------------------------------------------------------

    fun volte(ctx: Context): String {
        val t = dataType(ctx)
        return Guides.volte("${generation(t)} (${typeName(t)})", t == 13 || t == 19 || t == 20)
    }

    // ------------------------------------------------------------------
    //  15. Troubleshooter
    // ------------------------------------------------------------------

    fun troubleshoot(ctx: Context, update: (String) -> Unit): String {
        update("Checking your SIM and mobile network...")
        val tm = tm(ctx)
        val fix = ArrayList<String>()
        val sb = StringBuilder()
        sb.appendLine("# Checks")

        val air = airplane(ctx)
        sb.appendLine("Airplane mode|${if (air) "\u2718 ON" else "\u2714 Off"}")
        if (air) fix.add("Turn Airplane mode off.")

        val st = tm.simState
        sb.appendLine("SIM card|${if (st == 5) "\u2714 Ready" else "\u2718 ${simStateName(st)}"}")
        if (st == 1) fix.add("No SIM found. Switch the phone off, take the SIM out, clean it and put it back.")
        if (st == 2 || st == 3) fix.add("The SIM is locked. Enter the PIN or ask your operator for the PUK.")

        val op = tm.networkOperatorName ?: ""
        sb.appendLine("Registered on network|${if (op.isNotEmpty()) "\u2714 $op" else "\u2718 No network"}")
        if (op.isEmpty() && !air && st == 5) fix.add("No network found. Try choosing the operator manually in network settings, or restart the phone.")

        val md = mobileDataSetting(ctx)
        sb.appendLine("Mobile data|${when (md) { 1 -> "\u2714 ON"; 0 -> "\u2718 OFF"; else -> "? Unknown" }}")
        if (md == 0) fix.add("Turn Mobile data ON.")

        val sig = signal(ctx)
        if (sig != null) {
            sb.appendLine("Signal|${if (sig.level >= 2) "\u2714" else "\u2718"} ${sig.dbm} dBm (${signalName(sig.level)}, ${sig.type})")
            if (sig.level < 2) fix.add("Signal is weak. Move near a window or outside, away from thick walls.")
        } else {
            sb.appendLine("Signal|? Not available (needs Android 10+ and Phone permission)")
        }

        if (tm.isNetworkRoaming) {
            sb.appendLine("Roaming|\u26A0 Yes")
            fix.add("You are roaming. Turn Data roaming ON only if you accept the extra cost.")
        } else {
            sb.appendLine("Roaming|\u2714 No")
        }

        update("Testing internet...")
        val transport = LogKit.transport(ctx)
        val ok = try {
            val s = Socket()
            try {
                s.connect(InetSocketAddress("1.1.1.1", 443), 3000)
                true
            } finally {
                try { s.close() } catch (e: Exception) { }
            }
        } catch (e: Exception) {
            false
        }
        sb.appendLine("Internet test|${if (ok) "\u2714 Reachable" else "\u2718 Failed"} (via $transport)")
        if (!ok) fix.add("Internet is not reachable. Check your data balance or pack, and the APN settings.")
        if (transport == "Wi-Fi") sb.appendLine("! Wi-Fi is active, so this internet test used Wi-Fi. Turn Wi-Fi off to test mobile data itself.")

        sb.appendLine("# What to try")
        if (fix.isEmpty()) {
            sb.appendLine("Everything looks fine.")
        } else {
            for ((i, f) in fix.withIndex()) sb.appendLine("${i + 1}. $f")
        }
        sb.appendLine("# Common fixes")
        sb.appendLine("1. Toggle Airplane mode on for 10 seconds, then off")
        sb.appendLine("2. Restart the phone")
        sb.appendLine("3. Check the APN settings match your operator")
        sb.appendLine("4. Check your balance and data pack, or call your operator")
        sb.appendLine("btn|Open airplane mode settings|airplane")
        sb.appendLine("btn|Open APN settings|apn")
        sb.appendLine("btn|Open mobile network settings|net_settings")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  summary for reports
    // ------------------------------------------------------------------

    fun summary(ctx: Context): String {
        val tm = tm(ctx)
        val t = dataType(ctx)
        val sig = signal(ctx)
        val sb = StringBuilder()
        sb.appendLine("# Mobile network")
        sb.appendLine("SIM state|${simStateName(tm.simState)}")
        sb.appendLine("Operator|${(tm.networkOperatorName ?: "").ifEmpty { "-" }}")
        sb.appendLine("Network|${generation(t)} (${typeName(t)})")
        sb.appendLine("Signal|${if (sig != null) "${sig.dbm} dBm (${signalName(sig.level)})" else "-"}")
        sb.appendLine("Roaming|${if (tm.isNetworkRoaming) "Yes" else "No"}")
        return sb.toString()
    }
}
