package com.wifitools.app

import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small on-device logs: signal samples, connection events and speed results. */
object LogKit {

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("wifitools", Context.MODE_PRIVATE)

    fun transportOf(c: NetworkCapabilities?): String = when {
        c == null -> "None"
        c.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
        c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
        c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        else -> "Other"
    }

    fun transport(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return transportOf(cm.getNetworkCapabilities(cm.activeNetwork))
    }

    @Suppress("DEPRECATION")
    fun wifiRssi(ctx: Context): Int? {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!wm.isWifiEnabled) return null
        val info = wm.connectionInfo ?: return null
        if (info.networkId == -1 || info.rssi <= -127) return null
        return info.rssi
    }

    @Synchronized
    private fun append(ctx: Context, key: String, o: JSONObject, max: Int) {
        val p = prefs(ctx)
        val arr = try { JSONArray(p.getString(key, "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(o)
        val out = JSONArray()
        for (i in maxOf(0, arr.length() - max) until arr.length()) out.put(arr.get(i))
        p.edit().putString(key, out.toString()).apply()
    }

    fun read(ctx: Context, key: String): List<JSONObject> {
        val arr = try { JSONArray(prefs(ctx).getString(key, "[]")) } catch (e: Exception) { JSONArray() }
        val res = ArrayList<JSONObject>()
        for (i in 0 until arr.length()) res.add(arr.getJSONObject(i))
        return res
    }

    fun addSample(ctx: Context) {
        val o = JSONObject().put("t", System.currentTimeMillis())
        val w = wifiRssi(ctx)
        if (w != null) o.put("w", w)
        val m = try { MobileKit.signal(ctx) } catch (e: Exception) { null }
        if (m != null) {
            o.put("m", m.dbm)
            o.put("l", m.level)
            o.put("nt", m.type)
        }
        val tr = transport(ctx)
        o.put("tr", tr)
        append(ctx, "sig_log", o, 400)
        val last = prefs(ctx).getString("last_tr", null)
        if (last != null && last != tr) addEvent(ctx, "Network changed: $last \u2192 $tr")
        prefs(ctx).edit().putString("last_tr", tr).apply()
    }

    fun addSampleThrottled(ctx: Context) {
        val last = prefs(ctx).getLong("last_sample", 0L)
        if (System.currentTimeMillis() - last < 120_000) return
        prefs(ctx).edit().putLong("last_sample", System.currentTimeMillis()).apply()
        addSample(ctx)
    }

    fun addEvent(ctx: Context, text: String) {
        val p = prefs(ctx)
        val now = System.currentTimeMillis()
        if (text == p.getString("last_ev", "") && now - p.getLong("last_ev_t", 0L) < 3000) return
        p.edit().putString("last_ev", text).putLong("last_ev_t", now).apply()
        append(ctx, "ev_log", JSONObject().put("t", now).put("e", text), 200)
    }

    private fun ts(t: Long) = SimpleDateFormat("dd MMM, HH:mm", Locale.US).format(Date(t))

    // ------------------------------------------------------------------
    //  Signal history (Wi-Fi or mobile)
    // ------------------------------------------------------------------

    fun signalHistory(ctx: Context, kind: String): String {
        val key = if (kind == "wifi") "w" else "m"
        val label = if (kind == "wifi") "Wi-Fi" else "Mobile"
        val list = read(ctx, "sig_log").filter { it.has(key) }
        val sb = StringBuilder()
        sb.appendLine("# $label signal history")
        if (list.isEmpty()) {
            sb.appendLine("No samples recorded yet.")
            sb.appendLine("! Samples are saved when you open the app, use a live meter, and about every 15 minutes while Background Logging is ON.")
            sb.appendLine("btn|Turn Background Logging ON or OFF|toggle_log")
            return sb.toString()
        }
        val vals = list.map { it.getInt(key) }
        sb.appendLine("Samples|${vals.size}")
        sb.appendLine("Average|${vals.average().toInt()} dBm")
        sb.appendLine("Best|${vals.max()} dBm")
        sb.appendLine("Worst|${vals.min()} dBm")
        sb.appendLine("graph|Last ${minOf(60, vals.size)} samples (dBm, higher is better)|${vals.takeLast(60).joinToString(",")}")
        sb.appendLine("# Recent")
        for (o in list.takeLast(12).reversed()) {
            val extra = if (kind == "mobile") "  \u2022  ${o.optString("nt", "")}" else ""
            sb.appendLine("${ts(o.getLong("t"))}|${o.getInt(key)} dBm$extra")
        }
        sb.appendLine("btn|Turn Background Logging ON or OFF|toggle_log")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  Network comparison
    // ------------------------------------------------------------------

    fun comparison(ctx: Context): String {
        val hist = read(ctx, "hist")
        val sb = StringBuilder()
        sb.appendLine("# Speed by connection type")
        if (hist.isEmpty()) {
            sb.appendLine("No speed tests saved yet.")
            sb.appendLine("! Run the Speed Test once on Wi-Fi and once on mobile data. Results are saved and compared here.")
        } else {
            val groups = hist.groupBy { it.optString("tr", "Unknown") }
            val avgDown = HashMap<String, Double>()
            for ((name, items) in groups) {
                val d = items.map { it.getDouble("d") }
                val u = items.map { it.getDouble("u") }
                val p = items.map { it.getLong("p").toDouble() }
                avgDown[name] = d.average()
                sb.appendLine("# $name (${items.size} test(s))")
                sb.appendLine("Average download|${fmt(d.average())} Mbps")
                sb.appendLine("Average upload|${fmt(u.average())} Mbps")
                sb.appendLine("Average ping|${p.average().toLong()} ms")
                sb.appendLine("Best download|${fmt(d.max())} Mbps")
            }
            val wifi = avgDown["Wi-Fi"]
            val mob = avgDown["Mobile data"]
            if (wifi != null && mob != null && wifi > 0 && mob > 0) {
                val faster = if (wifi >= mob) "Wi-Fi" else "Mobile data"
                val ratio = if (wifi >= mob) wifi / mob else mob / wifi
                sb.appendLine("# Verdict")
                sb.appendLine("Faster connection|$faster (${fmt(ratio)}x)")
            }
            val byNet = hist.filter { it.optString("net", "").isNotEmpty() }.groupBy { it.optString("net") }
            if (byNet.size > 1) {
                sb.appendLine("# By network name")
                for ((n, items) in byNet.entries.sortedByDescending { e -> e.value.map { it.getDouble("d") }.average() }) {
                    sb.appendLine("${n.replace("|", "/")}|${fmt(items.map { it.getDouble("d") }.average())} Mbps (${items.size})")
                }
            }
        }
        val log = read(ctx, "sig_log")
        val w = log.filter { it.has("w") }.map { it.getInt("w") }
        val m = log.filter { it.has("m") }.map { it.getInt("m") }
        sb.appendLine("# Average signal")
        sb.appendLine("Wi-Fi|${if (w.isEmpty()) "no samples" else "${w.average().toInt()} dBm (${w.size} samples)"}")
        sb.appendLine("Mobile|${if (m.isEmpty()) "no samples" else "${m.average().toInt()} dBm (${m.size} samples)"}")
        return sb.toString()
    }

    private fun fmt(x: Double) = String.format(Locale.US, "%.1f", x)

    // ------------------------------------------------------------------
    //  Network monitor (connection events)
    // ------------------------------------------------------------------

    fun eventsPage(ctx: Context, limit: Int, withButton: Boolean): String {
        val ev = read(ctx, "ev_log")
        val sb = StringBuilder()
        sb.appendLine("# Connection events")
        sb.appendLine("Right now|${transport(ctx)}")
        val lost = ev.count { it.optString("e").startsWith("Connection lost") }
        sb.appendLine("Disconnections recorded|$lost")
        if (ev.isEmpty()) {
            sb.appendLine("! No events yet. The app records connect and disconnect events while it is running. Turn Background Logging ON to also catch changes every ~15 minutes.")
        } else {
            sb.appendLine("# Latest")
            for (o in ev.takeLast(limit).reversed()) {
                sb.appendLine("${ts(o.getLong("t"))}|${o.optString("e").replace("|", "/")}")
            }
        }
        if (withButton) sb.appendLine("btn|Turn Background Logging ON or OFF|toggle_log")
        return sb.toString()
    }
}

/** Runs every ~15 minutes when Background Logging is ON. */
class LogJobService : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        Thread {
            try {
                LogKit.addSample(applicationContext)
            } catch (e: Exception) {
            }
            jobFinished(params, false)
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean = true
}
