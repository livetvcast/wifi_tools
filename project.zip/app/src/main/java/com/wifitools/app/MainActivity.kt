package com.wifitools.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.net.ConnectException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "WiFi Tools"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
        })

        addButton(root, "Wi-Fi Info") { runTask("Wi-Fi Info") { wifiInfoText() } }
        addButton(root, "Speed Test") { runTask("Speed Test") { u -> speedTest(u) } }
        addButton(root, "ISP Check") { runTask("ISP Check") { ispInfo() } }
        addButton(root, "DNS Check") { runTask("DNS Check") { dnsCheck() } }
        addButton(root, "Scan Connected Devices") { runTask("Scanning network") { u -> scanDevices(u) } }
        addButton(root, "Wi-Fi Password (root only)") { runTask("Reading password") { wifiPasswordRoot() } }
        addButton(root, "Open Wi-Fi Settings (QR share)") {
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
        }

        output = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(0, dp(16), 0, 0)
            text = "Tap a tool above."
        }
        root.addView(output)

        setContentView(ScrollView(this).apply { addView(root) })

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        parent.addView(b, lp)
    }

    private fun runTask(title: String, block: suspend (update: (String) -> Unit) -> String) {
        output.text = "$title...\n"
        val update: (String) -> Unit = { msg -> runOnUiThread { output.text = msg } }
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) { block(update) }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            output.text = result
        }
    }

    // ---------- Network helpers ----------

    private fun cm() = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private fun linkProps() = cm().let { it.getLinkProperties(it.activeNetwork) }

    private fun localIpv4(): String? {
        val la = linkProps()?.linkAddresses?.firstOrNull { it.address is Inet4Address } ?: return null
        return la.address.hostAddress
    }

    private fun gatewayIp(): String? {
        val r = linkProps()?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
        return r?.gateway?.hostAddress
    }

    @Suppress("DEPRECATION")
    private fun currentSsid(): String? {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val s = wm.connectionInfo?.ssid?.trim('"') ?: return null
        return if (s == "<unknown ssid>" || s.isEmpty()) null else s
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 7000
        c.setRequestProperty("User-Agent", "WifiTools/1.0")
        return try {
            c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    // ---------- 1. Wi-Fi info ----------

    @Suppress("DEPRECATION")
    private fun wifiInfoText(): String {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val ssid = currentSsid()
        val sb = StringBuilder()
        sb.appendLine("SSID      : ${ssid ?: "unknown (allow Location permission and turn Location ON)"}")
        sb.appendLine("BSSID     : ${info?.bssid ?: "-"}")
        sb.appendLine("Signal    : ${info?.rssi ?: "-"} dBm")
        sb.appendLine("Link speed: ${info?.linkSpeed ?: "-"} Mbps")
        sb.appendLine("Frequency : ${info?.frequency ?: "-"} MHz")
        sb.appendLine("My IP     : ${localIpv4() ?: "-"}")
        sb.appendLine("Gateway   : ${gatewayIp() ?: "-"}")
        return sb.toString()
    }

    // ---------- 2. Speed test ----------

    private fun measurePing(): Long {
        val t = System.nanoTime()
        val c = URL("https://speed.cloudflare.com/__down?bytes=0").openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 5000
        c.inputStream.use { it.readBytes() }
        c.disconnect()
        return (System.nanoTime() - t) / 1_000_000
    }

    private fun speedTest(update: (String) -> Unit): String {
        val sb = StringBuilder()

        update("Testing latency...")
        try { measurePing() } catch (e: Exception) { /* warm-up */ }
        val pings = (1..5).mapNotNull { try { measurePing() } catch (e: Exception) { null } }
        if (pings.isEmpty()) return "No internet connection."
        val jitter = if (pings.size > 1) pings.zipWithNext { a, b -> Math.abs(a - b) }.average() else 0.0
        sb.appendLine("Ping  : ${pings.average().toLong()} ms (min ${pings.min()} ms)")
        sb.appendLine("Jitter: ${"%.1f".format(jitter)} ms")

        update("$sb\nTesting download...")
        val dc = URL("https://speed.cloudflare.com/__down?bytes=25000000").openConnection() as HttpURLConnection
        dc.connectTimeout = 7000
        dc.readTimeout = 10000
        var total = 0L
        val start = System.nanoTime()
        dc.inputStream.use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                total += n
                if (System.nanoTime() - start > 10_000_000_000L) break
            }
        }
        dc.disconnect()
        val dSecs = (System.nanoTime() - start) / 1e9
        sb.appendLine("Download: ${"%.2f".format(total * 8 / 1e6 / dSecs)} Mbps")

        update("$sb\nTesting upload...")
        val size = 8_000_000
        val uc = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
        uc.requestMethod = "POST"
        uc.doOutput = true
        uc.connectTimeout = 7000
        uc.readTimeout = 15000
        uc.setFixedLengthStreamingMode(size)
        val us = System.nanoTime()
        uc.outputStream.use { os ->
            val chunk = ByteArray(64 * 1024)
            var sent = 0
            while (sent < size) {
                val n = minOf(chunk.size, size - sent)
                os.write(chunk, 0, n)
                sent += n
            }
        }
        uc.responseCode
        uc.disconnect()
        val uSecs = (System.nanoTime() - us) / 1e9
        sb.appendLine("Upload  : ${"%.2f".format(size * 8 / 1e6 / uSecs)} Mbps")
        return sb.toString()
    }

    // ---------- 3. ISP check ----------

    private fun ispInfo(): String {
        val j = JSONObject(httpGet("https://ipinfo.io/json"))
        val sb = StringBuilder()
        sb.appendLine("Public IP: ${j.optString("ip", "-")}")
        sb.appendLine("ISP / ASN: ${j.optString("org", "-")}")
        sb.appendLine("City     : ${j.optString("city", "-")}")
        sb.appendLine("Region   : ${j.optString("region", "-")}")
        sb.appendLine("Country  : ${j.optString("country", "-")}")
        sb.appendLine("Timezone : ${j.optString("timezone", "-")}")
        return sb.toString()
    }

    // ---------- 4. DNS check ----------

    private fun dnsQuery(server: InetAddress, domain: String): Long {
        return try {
            val baos = ByteArrayOutputStream()
            val d = DataOutputStream(baos)
            d.writeShort(0x1234)
            d.writeShort(0x0100)
            d.writeShort(1)
            d.writeShort(0)
            d.writeShort(0)
            d.writeShort(0)
            for (label in domain.split(".")) {
                d.writeByte(label.length)
                d.write(label.toByteArray())
            }
            d.writeByte(0)
            d.writeShort(1)
            d.writeShort(1)
            val data = baos.toByteArray()
            val s = DatagramSocket()
            try {
                s.soTimeout = 3000
                val t = System.nanoTime()
                s.send(DatagramPacket(data, data.size, server, 53))
                val buf = ByteArray(512)
                s.receive(DatagramPacket(buf, buf.size))
                (System.nanoTime() - t) / 1_000_000
            } finally {
                s.close()
            }
        } catch (e: Exception) {
            -1L
        }
    }

    private fun fmtMs(ms: Long) = if (ms < 0) "timeout" else "$ms ms"

    private fun dnsCheck(): String {
        val sb = StringBuilder()
        val lp = linkProps()
        val servers = lp?.dnsServers ?: emptyList()

        sb.appendLine("== Your DNS servers ==")
        if (servers.isEmpty()) sb.appendLine("none found")
        for (s in servers) {
            sb.appendLine("${s.hostAddress}  ->  ${fmtMs(dnsQuery(s, "example.com"))}")
        }
        if (Build.VERSION.SDK_INT >= 28 && lp != null) {
            sb.appendLine("Private DNS: ${if (lp.isPrivateDnsActive) "ON (${lp.privateDnsServerName ?: "auto"})" else "OFF"}")
        }

        sb.appendLine()
        sb.appendLine("== Public DNS comparison ==")
        val publics = listOf("Google 8.8.8.8" to "8.8.8.8", "Cloudflare 1.1.1.1" to "1.1.1.1", "Quad9 9.9.9.9" to "9.9.9.9")
        for ((name, ip) in publics) {
            sb.appendLine("$name  ->  ${fmtMs(dnsQuery(InetAddress.getByName(ip), "example.com"))}")
        }

        sb.appendLine()
        sb.appendLine("== System resolver ==")
        val t = System.nanoTime()
        val r = try {
            InetAddress.getByName("www.wikipedia.org").hostAddress
        } catch (e: Exception) {
            "failed"
        }
        sb.appendLine("www.wikipedia.org -> $r (${(System.nanoTime() - t) / 1_000_000} ms)")
        return sb.toString()
    }

    // ---------- 5. Device scan ----------

    private fun isAlive(host: String): Boolean {
        val addr = InetAddress.getByName(host)
        try {
            if (addr.isReachable(400)) return true
        } catch (e: Exception) { }
        for (port in intArrayOf(80, 443, 53, 22, 445, 8080, 62078)) {
            val s = Socket()
            try {
                s.connect(InetSocketAddress(addr, port), 150)
                return true
            } catch (e: ConnectException) {
                return true // connection refused = a device exists there
            } catch (e: Exception) {
            } finally {
                try { s.close() } catch (e: Exception) { }
            }
        }
        return false
    }

    private fun hostName(host: String): String {
        return try {
            val n = InetAddress.getByName(host).canonicalHostName
            if (n == host) "-" else n
        } catch (e: Exception) {
            "-"
        }
    }

    private fun arpTable(): Map<String, String> = try {
        File("/proc/net/arp").readLines().drop(1).mapNotNull { line ->
            val p = line.trim().split(Regex("\\s+"))
            if (p.size >= 4 && p[3] != "00:00:00:00:00:00") p[0] to p[3] else null
        }.toMap()
    } catch (e: Exception) {
        emptyMap()
    }

    private suspend fun scanDevices(update: (String) -> Unit): String = coroutineScope {
        val me = localIpv4() ?: return@coroutineScope "Not connected to Wi-Fi."
        val gw = gatewayIp()
        val base = me.substringBeforeLast(".")
        val found = ConcurrentHashMap<String, String>()
        val sem = Semaphore(64)

        update("Scanning $base.1 - $base.254 ...\n(takes about 10 seconds)")
        (1..254).map { i ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    val host = "$base.$i"
                    if (host == me || isAlive(host)) found[host] = hostName(host)
                }
            }
        }.awaitAll()

        val arp = arpTable()
        val sb = StringBuilder()
        sb.appendLine("Found ${found.size} device(s):\n")
        for ((ip, name) in found.toSortedMap(compareBy<String> { it.substringAfterLast(".").toInt() })) {
            val tag = when (ip) {
                me -> " (this phone)"
                gw -> " (router)"
                else -> ""
            }
            sb.appendLine("$ip$tag")
            sb.appendLine("  name: $name")
            sb.appendLine("  MAC : ${arp[ip] ?: "hidden by Android"}")
        }
        sb.appendLine()
        sb.appendLine("Note: sleeping devices may not respond, and Android 10+ hides MAC addresses.")
        sb.toString()
    }

    // ---------- 6. Wi-Fi password (root only) ----------

    private fun wifiPasswordRoot(): String {
        val xml = try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "cat /data/misc/wifi/WifiConfigStore.xml"))
            p.inputStream.bufferedReader().readText()
        } catch (e: Exception) {
            ""
        }
        if (xml.isBlank()) {
            return "Root access not available.\n\n" +
                "Without root, use Android's own screen:\n" +
                "1. Tap 'Open Wi-Fi Settings (QR share)'\n" +
                "2. Tap the connected network\n" +
                "3. Tap 'Share' and confirm your PIN/fingerprint\n" +
                "4. The password is shown under the QR code."
        }
        val ssid = currentSsid()
        val saved = xml.split("<Network>").mapNotNull { b ->
            val s = Regex("name=\"SSID\">(.*?)</string>").find(b)?.groupValues?.get(1)?.replace("&quot;", "")
            val pw = Regex("name=\"PreSharedKey\">(.*?)</string>").find(b)?.groupValues?.get(1)?.replace("&quot;", "")
            if (s != null) s to (pw ?: "(open network, no password)") else null
        }
        val sb = StringBuilder()
        val match = saved.firstOrNull { it.first == ssid }
        if (match != null) {
            sb.appendLine("Connected: ${match.first}")
            sb.appendLine("Password : ${match.second}")
            sb.appendLine()
        }
        sb.appendLine("All saved networks on this phone:")
        for ((s, p) in saved) sb.appendLine("$s  ->  $p")
        return sb.toString()
    }
}
