package com.wifitools.app

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.net.ConnectException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

// ======================================================================
//  Custom views
// ======================================================================

/** The app logo, drawn in code so it can be animated (arcs appear one by one). */
class WifiLogoView(context: Context) : View(context) {
    var progress = 0f
        set(value) {
            field = value
            invalidate()
        }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        val left = (width - s) / 2f
        val top = (height - s) / 2f

        bgPaint.shader = LinearGradient(
            left, top, left + s, top + s,
            Color.parseColor("#38BDF8"), Color.parseColor("#7C3AED"),
            Shader.TileMode.CLAMP
        )
        rect.set(left, top, left + s, top + s)
        canvas.drawRoundRect(rect, s * 0.26f, s * 0.26f, bgPaint)

        val cx = left + s / 2f
        val cy = top + s * 0.67f
        arcPaint.strokeWidth = s * 0.075f
        val radii = floatArrayOf(0.15f, 0.27f, 0.39f)
        for (i in 0..2) {
            val a = (progress - (i + 1)).coerceIn(0f, 1f)
            if (a <= 0f) continue
            val r = s * radii[i] * (0.8f + 0.2f * a)
            arcPaint.alpha = (255 * a).toInt()
            rect.set(cx - r, cy - r, cx + r, cy + r)
            canvas.drawArc(rect, 225f, 90f, false, arcPaint)
        }
        val d = progress.coerceIn(0f, 1f)
        if (d > 0f) {
            dotPaint.alpha = (255 * d).toInt()
            canvas.drawCircle(cx, cy, s * 0.055f * d, dotPaint)
        }
    }
}

/** Four little signal bars. */
class SignalView(context: Context) : View(context) {
    var level = 0
        set(value) {
            field = value
            invalidate()
        }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val gap = w * 0.08f
        val bw = (w - gap * 3) / 4f
        for (i in 0 until 4) {
            val bh = h * (0.3f + 0.7f * (i / 3f))
            p.color = if (i < level) Color.WHITE else Color.parseColor("#55FFFFFF")
            val l = i * (bw + gap)
            canvas.drawRoundRect(l, h - bh, l + bw, h, bw / 3f, bw / 3f, p)
        }
    }
}

// ======================================================================
//  Main screen
// ======================================================================

class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val appVersion = "v2.0"

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val cBg = Color.parseColor("#0B1220")
    private val cBg2 = Color.parseColor("#0E1626")
    private val cCard = Color.parseColor("#162032")
    private val cStroke = Color.parseColor("#26344D")
    private val cDivider = Color.parseColor("#1F2C44")
    private val cAccent = Color.parseColor("#38BDF8")
    private val cText = Color.parseColor("#F1F5F9")
    private val cMuted = Color.parseColor("#8FA3BF")

    private lateinit var scroller: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var resultCard: View
    private lateinit var resultBox: LinearLayout
    private lateinit var resultTitle: TextView
    private lateinit var progress: ProgressBar
    private lateinit var ssidText: TextView
    private lateinit var ipText: TextView
    private lateinit var chipBand: TextView
    private lateinit var chipSpeed: TextView
    private lateinit var chipSignal: TextView
    private lateinit var signalView: SignalView
    private var plainResult = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        buildContent()

        scroller = ScrollView(this).apply {
            setBackgroundColor(cBg)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content)
        }
        val frame = FrameLayout(this).apply {
            setBackgroundColor(cBg)
            addView(scroller, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        setContentView(frame)

        if (savedInstanceState == null) {
            prepareContentIn()
            frame.addView(buildSplash(), FrameLayout.LayoutParams(MATCH, MATCH))
        }

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshHeader()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshHeader()
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    // ------------------------------------------------------------------
    //  Splash / opening animation
    // ------------------------------------------------------------------

    private fun buildSplash(): FrameLayout {
        val splash = FrameLayout(this).apply {
            setBackgroundColor(cBg)
            isClickable = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val logo = WifiLogoView(this)
        col.addView(logo, lp(dp(132), dp(132)))
        val name = label("WiFi Tools", 28f, cText, true).apply {
            alpha = 0f
            translationY = dp(12).toFloat()
            setPadding(0, dp(22), 0, 0)
        }
        val tag = label("Your network toolkit", 14f, cMuted).apply {
            alpha = 0f
            setPadding(0, dp(4), 0, 0)
        }
        col.addView(name)
        col.addView(tag)
        splash.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        splash.post {
            logo.scaleX = 0.6f
            logo.scaleY = 0.6f
            logo.animate().scaleX(1f).scaleY(1f).setDuration(1100)
                .setInterpolator(OvershootInterpolator(1.4f)).start()
            ValueAnimator.ofFloat(0f, 4f).apply {
                duration = 1100
                addUpdateListener { logo.progress = it.animatedValue as Float }
                start()
            }
            name.animate().alpha(1f).translationY(0f).setStartDelay(650).setDuration(450).start()
            tag.animate().alpha(1f).setStartDelay(850).setDuration(450).start()

            splash.postDelayed({
                splash.animate().alpha(0f).setDuration(380).withEndAction {
                    splash.visibility = View.GONE
                }.start()
                animateContentIn()
            }, 2100)
        }
        return splash
    }

    private fun prepareContentIn() {
        for (i in 0 until content.childCount) {
            val c = content.getChildAt(i)
            c.alpha = 0f
            c.translationY = dp(36).toFloat()
        }
    }

    private fun animateContentIn() {
        for (i in 0 until content.childCount) {
            content.getChildAt(i).animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(i * 70L)
                .setDuration(450)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    // ------------------------------------------------------------------
    //  Building the screen
    // ------------------------------------------------------------------

    private fun buildContent() {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), 0, 0, dp(18))
        }
        head.addView(label("WiFi Tools", 30f, cText, true))
        head.addView(label("Your network toolkit  \u2022  $appVersion", 13f, cMuted).apply {
            setPadding(0, dp(2), 0, 0)
        })
        content.addView(head)

        content.addView(buildStatusCard())

        content.addView(label("TOOLS", 11f, cMuted, true).apply {
            letterSpacing = 0.12f
            setPadding(dp(4), dp(22), 0, dp(6))
        })

        addRow(
            tile("\u26A1", "#F59E0B", "Speed Test", "Ping, download, upload") {
                runTask("Speed Test") { u -> speedTest(u) }
            },
            tile("\uD83C\uDF10", "#10B981", "ISP Check", "IP, provider, city") {
                runTask("ISP Check") { ispInfo() }
            }
        )
        addRow(
            tile("\uD83E\uDDED", "#8B5CF6", "DNS Check", "Servers and latency") {
                runTask("DNS Check") { dnsCheck() }
            },
            tile("\uD83D\uDCE1", "#06B6D4", "Devices", "Who is on my network") {
                runTask("Connected Devices") { u -> scanDevices(u) }
            }
        )
        addRow(
            tile("\uD83D\uDD11", "#F43F5E", "Password", "Saved Wi-Fi (root only)") {
                runTask("Wi-Fi Password") { wifiPasswordRoot() }
            },
            tile("\uD83D\uDCF6", "#64748B", "Wi-Fi Settings", "Share password via QR") {
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
        )

        resultCard = buildResultCard()
        content.addView(resultCard, lp(MATCH, WRAP).apply { topMargin = dp(14) })
    }

    private fun buildStatusCard(): View {
        val gradient = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#2563EB"), Color.parseColor("#7C3AED"))
        ).apply { cornerRadius = dp(26).toFloat() }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(20))
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), gradient, null)
            isClickable = true
            setOnClickListener { runTask("Wi-Fi Info") { wifiInfoText() } }
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(
            label("\u25CF  CONNECTED", 11f, Color.parseColor("#CCFFFFFF"), true).apply { letterSpacing = 0.1f },
            lp(0, WRAP, 1f)
        )
        signalView = SignalView(this)
        top.addView(signalView, lp(dp(30), dp(22)))
        card.addView(top)

        ssidText = label("-", 28f, Color.WHITE, true).apply {
            setPadding(0, dp(10), 0, dp(12))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        card.addView(ssidText)

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipBand = chip()
        chipSpeed = chip()
        chipSignal = chip()
        chips.addView(chipBand, lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        chips.addView(chipSpeed, lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        chips.addView(chipSignal, lp(WRAP, WRAP))
        card.addView(chips)

        ipText = label("", 12.5f, Color.parseColor("#D9FFFFFF")).apply {
            setPadding(0, dp(12), 0, 0)
        }
        card.addView(ipText)
        card.addView(label("Tap for full details", 11f, Color.parseColor("#99FFFFFF")).apply {
            setPadding(0, dp(6), 0, 0)
        })
        return card
    }

    private fun buildResultCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(cCard, 22)
            setPadding(dp(20), dp(16), dp(20), dp(20))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        resultTitle = label("RESULT", 11f, cMuted, true).apply { letterSpacing = 0.12f }
        head.addView(resultTitle, lp(0, WRAP, 1f))
        head.addView(label("COPY", 11f, cAccent, true).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(50).toFloat()
                setStroke(dp(1), cAccent)
            }
            setOnClickListener { copyResult() }
        })
        card.addView(head)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(cAccent)
            visibility = View.GONE
        }
        card.addView(progress, lp(MATCH, dp(4)).apply { topMargin = dp(10) })

        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        card.addView(resultBox)
        render("Pick a tool above to get started.")
        return card
    }

    // ------------------------------------------------------------------
    //  UI helpers
    // ------------------------------------------------------------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun bg(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), cStroke)
    }

    private fun chip(): TextView = TextView(this).apply {
        textSize = 12f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(11), dp(5), dp(11), dp(5))
        background = GradientDrawable().apply {
            setColor(0x33FFFFFF)
            cornerRadius = dp(50).toFloat()
        }
        visibility = View.GONE
    }

    private fun tile(icon: String, accentHex: String, title: String, sub: String, action: () -> Unit): LinearLayout {
        val accent = Color.parseColor(accentHex)
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = RippleDrawable(ColorStateList.valueOf(0x22FFFFFF), bg(cCard, 20), null)
            isClickable = true
            setOnClickListener { action() }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
        }
        val badge = TextView(this).apply {
            text = icon
            textSize = 22f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor((accent and 0x00FFFFFF) or 0x33000000)
            }
        }
        t.addView(badge, lp(dp(46), dp(46)))
        t.addView(label(title, 16f, cText, true).apply { setPadding(0, dp(12), 0, dp(2)) })
        t.addView(label(sub, 12f, cMuted))
        return t
    }

    private fun addRow(a: View, b: View) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = dp(6)
        r.addView(a, lp(0, MATCH, 1f).apply { setMargins(m, m, m, m) })
        r.addView(b, lp(0, MATCH, 1f).apply { setMargins(m, m, m, m) })
        content.addView(r, lp(MATCH, WRAP).apply { setMargins(-m, 0, -m, 0) })
    }

    private fun signalLevel(rssi: Int) = when {
        rssi >= -55 -> 4
        rssi >= -65 -> 3
        rssi >= -75 -> 2
        rssi >= -88 -> 1
        else -> 0
    }

    private fun signalName(level: Int) = arrayOf("Very weak", "Weak", "Fair", "Good", "Excellent")[level]

    private fun bandName(mhz: Int) = when {
        mhz < 3000 -> "2.4 GHz"
        mhz < 5900 -> "5 GHz"
        else -> "6 GHz"
    }

    @Suppress("DEPRECATION")
    private fun refreshHeader() {
        val ip = localIpv4()
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val onWifi = ip != null && wm.isWifiEnabled && info != null && info.networkId != -1

        if (!onWifi) {
            ssidText.text = "Not connected"
            ipText.text = "Connect to a Wi-Fi network to use the tools"
            chipBand.visibility = View.GONE
            chipSpeed.visibility = View.GONE
            chipSignal.visibility = View.GONE
            signalView.level = 0
            return
        }

        ssidText.text = currentSsid() ?: "Wi-Fi (allow Location to see name)"

        val f = info.frequency
        if (f > 0) {
            chipBand.text = bandName(f)
            chipBand.visibility = View.VISIBLE
        } else {
            chipBand.visibility = View.GONE
        }
        val ls = info.linkSpeed
        if (ls > 0) {
            chipSpeed.text = "$ls Mbps"
            chipSpeed.visibility = View.VISIBLE
        } else {
            chipSpeed.visibility = View.GONE
        }
        val rssi = info.rssi
        if (rssi > -127) {
            chipSignal.text = "$rssi dBm"
            chipSignal.visibility = View.VISIBLE
        } else {
            chipSignal.visibility = View.GONE
        }
        signalView.level = signalLevel(rssi)
        val gw = gatewayIp()
        ipText.text = "IP $ip" + (if (gw != null) "   \u2022   Router $gw" else "")
    }

    private fun copyResult() {
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("result", plainResult))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun runTask(title: String, block: suspend (update: (String) -> Unit) -> String) {
        resultTitle.text = title.uppercase()
        render("Working...")
        progress.visibility = View.VISIBLE
        scroller.post { scroller.smoothScrollTo(0, maxOf(0, resultCard.top - dp(12))) }
        val update: (String) -> Unit = { msg -> runOnUiThread { render(msg) } }
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) { block(update) }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            progress.visibility = View.GONE
            render(result)
        }
    }

    // ------------------------------------------------------------------
    //  Result rendering.
    //  Tiny markup used by the tools:
    //    "# Title"                 section heading
    //    "key|value"               a row
    //    "stat|Label|123|unit"     big number box (consecutive ones share a row)
    //    "dev|ip|name|mac|tag"     a device row
    //    "! text"                  small note
    //    anything else             plain text
    // ------------------------------------------------------------------

    private fun toPlain(text: String): String {
        val sb = StringBuilder()
        for (l in text.lines()) {
            when {
                l.isBlank() -> {}
                l.startsWith("# ") -> sb.appendLine().appendLine(l.substring(2).uppercase())
                l.startsWith("! ") -> sb.appendLine(l.substring(2))
                l.startsWith("stat|") -> {
                    val p = l.split("|")
                    sb.appendLine("${p.getOrElse(1) { "" }}: ${p.getOrElse(2) { "" }} ${p.getOrElse(3) { "" }}")
                }
                l.startsWith("dev|") -> {
                    val p = l.split("|")
                    sb.appendLine("${p.getOrElse(1) { "" }} ${p.getOrElse(4) { "" }} - ${p.getOrElse(2) { "" }} - ${p.getOrElse(3) { "" }}")
                }
                l.contains("|") -> sb.appendLine(l.replaceFirst("|", ": "))
                else -> sb.appendLine(l)
            }
        }
        return sb.toString().trim()
    }

    private fun render(text: String) {
        plainResult = toPlain(text)
        resultBox.removeAllViews()
        val lines = text.lines().filter { it.isNotBlank() }
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            if (l.startsWith("stat|")) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                while (i < lines.size && lines[i].startsWith("stat|")) {
                    val p = lines[i].split("|")
                    r.addView(
                        statBox(p.getOrElse(1) { "" }, p.getOrElse(2) { "" }, p.getOrElse(3) { "" }),
                        lp(0, WRAP, 1f).apply { setMargins(dp(4), dp(6), dp(4), dp(2)) }
                    )
                    i++
                }
                resultBox.addView(r, lp(MATCH, WRAP).apply { setMargins(-dp(4), 0, -dp(4), 0) })
                continue
            }
            if (l.startsWith("# ")) {
                resultBox.addView(label(l.substring(2).uppercase(), 11f, cAccent, true).apply {
                    letterSpacing = 0.12f
                    setPadding(0, dp(14), 0, dp(4))
                })
            } else if (l.startsWith("! ")) {
                resultBox.addView(label(l.substring(2), 11.5f, cMuted).apply { setPadding(0, dp(12), 0, 0) })
            } else if (l.startsWith("dev|")) {
                val p = l.split("|")
                resultBox.addView(devRow(p.getOrElse(1) { "" }, p.getOrElse(2) { "" }, p.getOrElse(3) { "" }, p.getOrElse(4) { "" }))
            } else if (l.contains("|")) {
                val p = l.split("|", limit = 2)
                resultBox.addView(kvRow(p[0], p.getOrElse(1) { "" }))
                resultBox.addView(View(this).apply { setBackgroundColor(cDivider) }, lp(MATCH, dp(1)))
            } else {
                resultBox.addView(label(l, 14f, cText).apply { setPadding(0, dp(4), 0, dp(4)) })
            }
            i++
        }
    }

    private fun kvRow(k: String, v: String): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(9), 0, dp(9))
        }
        r.addView(label(k, 13.5f, cMuted), lp(WRAP, WRAP).apply { rightMargin = dp(16) })
        r.addView(label(v, 14f, cText, true).apply {
            gravity = Gravity.END
            setTextIsSelectable(true)
        }, lp(0, WRAP, 1f))
        return r
    }

    private fun statBox(k: String, v: String, unit: String): View {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(14), dp(6), dp(14))
            background = bg(cBg2, 16)
        }
        b.addView(label(k.uppercase(), 10f, cMuted, true).apply { letterSpacing = 0.1f })
        b.addView(label(v, 24f, cText, true).apply { setPadding(0, dp(6), 0, 0) })
        b.addView(label(unit, 11f, cAccent))
        return b
    }

    private fun devRow(ip: String, name: String, mac: String, tag: String): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val icon = when (tag) {
            "Router" -> "\uD83D\uDCE1"
            "This phone" -> "\uD83D\uDCF1"
            else -> "\uD83D\uDCBB"
        }
        val badge = TextView(this).apply {
            text = icon
            textSize = 18f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(cBg2)
                setStroke(dp(1), cStroke)
            }
        }
        r.addView(badge, lp(dp(42), dp(42)).apply { rightMargin = dp(14) })

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        title.addView(label(ip, 15f, cText, true))
        if (tag.isNotEmpty()) {
            title.addView(label(tag, 11f, cAccent, true).apply { setPadding(dp(8), 0, 0, 0) })
        }
        col.addView(title)
        col.addView(label("$name  \u2022  $mac", 12f, cMuted).apply { setPadding(0, dp(2), 0, 0) })
        r.addView(col, lp(0, WRAP, 1f))
        return r
    }

    // ------------------------------------------------------------------
    //  Network helpers
    // ------------------------------------------------------------------

    private fun cm() = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private fun linkProps() = cm().let { it.getLinkProperties(it.activeNetwork) }

    private fun localIpv4(): String? {
        val la = linkProps()?.linkAddresses?.firstOrNull { it.address is Inet4Address } ?: return null
        return la.address.hostAddress
    }

    private fun gatewayIp(): String? {
        val r = linkProps()?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
        return r?.gateway?.hostAddress
    }

    @Suppress("DEPRECATION")
    private fun currentSsid(): String? {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val s = wm.connectionInfo?.ssid?.trim('"') ?: return null
        return if (s == "<unknown ssid>" || s.isEmpty()) null else s
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 7000
        c.setRequestProperty("User-Agent", "WifiTools/2.0")
        return try {
            c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)
    private fun f2(x: Double) = String.format(Locale.US, "%.2f", x)

    // ------------------------------------------------------------------
    //  1. Wi-Fi info
    // ------------------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun wifiInfoText(): String {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val ssid = currentSsid()
        val rssi = info?.rssi ?: -127
        val sb = StringBuilder()
        sb.appendLine("# Connection")
        sb.appendLine("Network|${ssid ?: "unknown (allow Location, turn it ON)"}")
        sb.appendLine("BSSID|${info?.bssid ?: "-"}")
        sb.appendLine("Signal|$rssi dBm (${signalName(signalLevel(rssi))})")
        sb.appendLine("Link speed|${info?.linkSpeed ?: "-"} Mbps")
        val f = info?.frequency ?: 0
        sb.appendLine("Frequency|${if (f > 0) "$f MHz (${bandName(f)})" else "-"}")
        sb.appendLine("# Addresses")
        sb.appendLine("My IP|${localIpv4() ?: "-"}")
        sb.appendLine("Router|${gatewayIp() ?: "-"}")
        val dns = linkProps()?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()
        sb.appendLine("DNS|${if (dns.isEmpty()) "-" else dns.joinToString(", ")}")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  2. Speed test
    // ------------------------------------------------------------------

    private fun measurePing(): Long {
        val t = System.nanoTime()
        val c = URL("https://speed.cloudflare.com/__down?bytes=0").openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 5000
        c.inputStream.use { it.readBytes() }
        c.disconnect()
        return (System.nanoTime() - t) / 1_000_000
    }

    private fun speedTest(update: (String) -> Unit): String {
        update("Testing latency...")
        try { measurePing() } catch (e: Exception) { /* warm-up */ }
        val pings = (1..5).mapNotNull { try { measurePing() } catch (e: Exception) { null } }
        if (pings.isEmpty()) return "No internet connection."
        val jitter = if (pings.size > 1) pings.zipWithNext { a, b -> Math.abs(a - b) }.average() else 0.0
        val pingAvg = pings.average().toLong()
        val pingMin = pings.min()

        update("Ping $pingAvg ms\nTesting download...")
        val dc = URL("https://speed.cloudflare.com/__down?bytes=25000000").openConnection() as HttpURLConnection
        dc.connectTimeout = 7000
        dc.readTimeout = 10000
        var total = 0L
        val start = System.nanoTime()
        dc.inputStream.use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                total += n
                if (System.nanoTime() - start > 10_000_000_000L) break
            }
        }
        dc.disconnect()
        val dSecs = (System.nanoTime() - start) / 1e9
        val down = total * 8 / 1e6 / dSecs

        update("Ping $pingAvg ms\nDownload ${f1(down)} Mbps\nTesting upload...")
        val size = 8_000_000
        val uc = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
        uc.requestMethod = "POST"
        uc.doOutput = true
        uc.connectTimeout = 7000
        uc.readTimeout = 15000
        uc.setFixedLengthStreamingMode(size)
        val us = System.nanoTime()
        uc.outputStream.use { os ->
            val chunk = ByteArray(64 * 1024)
            var sent = 0
            while (sent < size) {
                val n = minOf(chunk.size, size - sent)
                os.write(chunk, 0, n)
                sent += n
            }
        }
        uc.responseCode
        uc.disconnect()
        val uSecs = (System.nanoTime() - us) / 1e9
        val up = size * 8 / 1e6 / uSecs

        val sb = StringBuilder()
        sb.appendLine("stat|Download|${f1(down)}|Mbps")
        sb.appendLine("stat|Upload|${f1(up)}|Mbps")
        sb.appendLine("stat|Ping|$pingAvg|ms")
        sb.appendLine("Best ping|$pingMin ms")
        sb.appendLine("Jitter|${f1(jitter)} ms")
        sb.appendLine("! Measured against Cloudflare's speed servers.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  3. ISP check
    // ------------------------------------------------------------------

    private fun ispInfo(): String {
        val j = JSONObject(httpGet("https://ipinfo.io/json"))
        val sb = StringBuilder()
        sb.appendLine("# Your connection")
        sb.appendLine("Public IP|${j.optString("ip", "-")}")
        sb.appendLine("ISP / ASN|${j.optString("org", "-")}")
        sb.appendLine("# Location (approximate)")
        sb.appendLine("City|${j.optString("city", "-")}")
        sb.appendLine("Region|${j.optString("region", "-")}")
        sb.appendLine("Country|${j.optString("country", "-")}")
        sb.appendLine("Timezone|${j.optString("timezone", "-")}")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  4. DNS check
    // ------------------------------------------------------------------

    private fun dnsQuery(server: InetAddress, domain: String): Long {
        return try {
            val baos = ByteArrayOutputStream()
            val d = DataOutputStream(baos)
            d.writeShort(0x1234)
            d.writeShort(0x0100)
            d.writeShort(1)
            d.writeShort(0)
            d.writeShort(0)
            d.writeShort(0)
            for (label in domain.split(".")) {
                d.writeByte(label.length)
                d.write(label.toByteArray())
            }
            d.writeByte(0)
            d.writeShort(1)
            d.writeShort(1)
            val data = baos.toByteArray()
            val s = DatagramSocket()
            try {
                s.soTimeout = 3000
                val t = System.nanoTime()
                s.send(DatagramPacket(data, data.size, server, 53))
                val buf = ByteArray(512)
                s.receive(DatagramPacket(buf, buf.size))
                (System.nanoTime() - t) / 1_000_000
            } finally {
                s.close()
            }
        } catch (e: Exception) {
            -1L
        }
    }

    private fun fmtMs(ms: Long) = if (ms < 0) "timeout" else "$ms ms"

    private fun dnsCheck(): String {
        val sb = StringBuilder()
        val lp = linkProps()
        val servers = lp?.dnsServers ?: emptyList()

        sb.appendLine("# Your DNS servers")
        if (servers.isEmpty()) sb.appendLine("None found|-")
        for (s in servers) {
            sb.appendLine("${s.hostAddress}|${fmtMs(dnsQuery(s, "example.com"))}")
        }
        if (Build.VERSION.SDK_INT >= 28 && lp != null) {
            sb.appendLine("Private DNS|${if (lp.isPrivateDnsActive) "ON (${lp.privateDnsServerName ?: "auto"})" else "OFF"}")
        }

        sb.appendLine("# Public DNS comparison")
        val publics = listOf("Google 8.8.8.8" to "8.8.8.8", "Cloudflare 1.1.1.1" to "1.1.1.1", "Quad9 9.9.9.9" to "9.9.9.9")
        for ((name, ip) in publics) {
            sb.appendLine("$name|${fmtMs(dnsQuery(InetAddress.getByName(ip), "example.com"))}")
        }

        sb.appendLine("# System resolver")
        val t = System.nanoTime()
        val r = try {
            InetAddress.getByName("www.wikipedia.org").hostAddress
        } catch (e: Exception) {
            "failed"
        }
        sb.appendLine("www.wikipedia.org|$r (${(System.nanoTime() - t) / 1_000_000} ms)")
        sb.appendLine("! Lower milliseconds means faster DNS.")
        return sb.toString()
    }

    // ------------------------------------------------------------------
    //  5. Device scan
    // ------------------------------------------------------------------

    private fun isAlive(host: String): Boolean {
        val addr = InetAddress.getByName(host)
        try {
            if (addr.isReachable(400)) return true
        } catch (e: Exception) { }
        for (port in intArrayOf(80, 443, 53, 22, 445, 8080, 62078)) {
            val s = Socket()
            try {
                s.connect(InetSocketAddress(addr, port), 150)
                return true
            } catch (e: ConnectException) {
                return true // connection refused = a device exists there
            } catch (e: Exception) {
            } finally {
                try { s.close() } catch (e: Exception) { }
            }
        }
        return false
    }

    private fun hostName(host: String): String {
        return try {
            val n = InetAddress.getByName(host).canonicalHostName
            if (n == host) "Unknown device" else n
        } catch (e: Exception) {
            "Unknown device"
        }
    }

    private fun arpTable(): Map<String, String> = try {
        File("/proc/net/arp").readLines().drop(1).mapNotNull { line ->
            val p = line.trim().split(Regex("\\s+"))
            if (p.size >= 4 && p[3] != "00:00:00:00:00:00") p[0] to p[3] else null
        }.toMap()
    } catch (e: Exception) {
        emptyMap()
    }

    private suspend fun scanDevices(update: (String) -> Unit): String = coroutineScope {
        val me = localIpv4() ?: return@coroutineScope "Not connected to Wi-Fi."
        val gw = gatewayIp()
        val base = me.substringBeforeLast(".")
        val found = ConcurrentHashMap<String, String>()
        val sem = Semaphore(64)

        update("Scanning $base.1 - $base.254 ...\nThis takes about 10 seconds.")
        (1..254).map { i ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    val host = "$base.$i"
                    if (host == me || isAlive(host)) found[host] = hostName(host)
                }
            }
        }.awaitAll()

        val arp = arpTable()
        val sb = StringBuilder()
        sb.appendLine("# ${found.size} device(s) found")
        for ((ip, name) in found.toSortedMap(compareBy<String> { it.substringAfterLast(".").toInt() })) {
            val tag = when (ip) {
                me -> "This phone"
                gw -> "Router"
                else -> ""
            }
            sb.appendLine("dev|$ip|$name|${arp[ip] ?: "MAC hidden"}|$tag")
        }
        sb.appendLine("! Sleeping devices may not respond, and Android 10+ hides MAC addresses.")
        sb.toString()
    }

    // ------------------------------------------------------------------
    //  6. Wi-Fi password (root only)
    // ------------------------------------------------------------------

    private fun wifiPasswordRoot(): String {
        val xml = try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "cat /data/misc/wifi/WifiConfigStore.xml"))
            p.inputStream.bufferedReader().readText()
        } catch (e: Exception) {
            ""
        }
        if (xml.isBlank()) {
            return "# Root access not available\n" +
                "Without root, Android only shows the password on its own screen:\n" +
                "1. Tap the 'Wi-Fi Settings' tile\n" +
                "2. Tap the connected network\n" +
                "3. Tap Share and confirm your PIN or fingerprint\n" +
                "4. The password appears under the QR code\n"
        }
        val ssid = currentSsid()
        val saved = xml.split("<Network>").mapNotNull { b ->
            val s = Regex("name=\"SSID\">(.*?)</string>").find(b)?.groupValues?.get(1)?.replace("&quot;", "")
            val pw = Regex("name=\"PreSharedKey\">(.*?)</string>").find(b)?.groupValues?.get(1)?.replace("&quot;", "")
            if (s != null) s to (pw ?: "(open network)") else null
        }
        val sb = StringBuilder()
        val match = saved.firstOrNull { it.first == ssid }
        if (match != null) {
            sb.appendLine("# Connected network")
            sb.appendLine("Name|${match.first}")
            sb.appendLine("Password|${match.second}")
        }
        sb.appendLine("# All saved networks")
        for ((s, p) in saved) sb.appendLine("$s|$p")
        return sb.toString()
    }
}
