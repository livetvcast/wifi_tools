package com.wifitools.app

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.EncodeHintType
import com.google.zxing.LuminanceSource
import com.google.zxing.MultiFormatReader
import com.google.zxing.NotFoundException
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.net.ConnectException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val appVersion = "v3.0"
    private val reqPick = 42
    private val watchJobId = 7001

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val prefs by lazy { getSharedPreferences("wifitools", Context.MODE_PRIVATE) }
    private val kit by lazy { NetKit(this) }

    private var dark = true
    private var bn = false

    private var cBg = 0
    private var cBg2 = 0
    private var cCard = 0
    private var cStroke = 0
    private var cDivider = 0
    private var cAccent = 0
    private var cText = 0
    private var cMuted = 0

    private lateinit var scroller: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var resultCard: View
    private lateinit var resultBox: LinearLayout
    private lateinit var resultTitle: TextView
    private lateinit var progress: ProgressBar
    private lateinit var ssidText: TextView
    private lateinit var ipText: TextView
    private lateinit var chipBand: TextView
    private lateinit var chipSpeed: TextView
    private lateinit var chipSignal: TextView
    private lateinit var signalView: SignalView
    private var plainResult = ""
    private var signalJob: Job? = null

    // ======================================================================
    //  Lifecycle
    // ======================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dark = prefs.getBoolean("dark", true)
        bn = prefs.getBoolean("bn", false)
        applyPalette()

        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (!dark) {
            var flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            window.decorView.systemUiVisibility = flags
        }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        buildContent()

        scroller = ScrollView(this).apply {
            setBackgroundColor(cBg)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content)
        }
        val frame = FrameLayout(this).apply {
            setBackgroundColor(cBg)
            addView(scroller, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        setContentView(frame)

        if (savedInstanceState == null) {
            prepareContentIn()
            frame.addView(buildSplash(), FrameLayout.LayoutParams(MATCH, MATCH))
        }

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshHeader()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshHeader()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPick && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            runTask("QR Password") { decodeQr(uri) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    // ======================================================================
    //  Theme and language
    // ======================================================================

    private fun applyPalette() {
        if (dark) {
            cBg = Color.parseColor("#0B1220")
            cBg2 = Color.parseColor("#0E1626")
            cCard = Color.parseColor("#162032")
            cStroke = Color.parseColor("#26344D")
            cDivider = Color.parseColor("#1F2C44")
            cAccent = Color.parseColor("#38BDF8")
            cText = Color.parseColor("#F1F5F9")
            cMuted = Color.parseColor("#8FA3BF")
        } else {
            cBg = Color.parseColor("#F1F5F9")
            cBg2 = Color.parseColor("#E8EEF6")
            cCard = Color.parseColor("#FFFFFF")
            cStroke = Color.parseColor("#D5DEEA")
            cDivider = Color.parseColor("#E5EAF1")
            cAccent = Color.parseColor("#0284C7")
            cText = Color.parseColor("#0F172A")
            cMuted = Color.parseColor("#5B6B82")
        }
    }

    private fun t(en: String, b: String): String = if (bn) b else en

    private fun toggleTheme() {
        prefs.edit().putBoolean("dark", !dark).apply()
        recreate()
    }

    private fun toggleLang() {
        prefs.edit().putBoolean("bn", !bn).apply()
        recreate()
    }

    private fun toast(msg: String, long: Boolean = false) {
        Toast.makeText(this, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    // ======================================================================
    //  Splash / opening animation
    // ======================================================================

    private fun buildSplash(): FrameLayout {
        val splash = FrameLayout(this).apply {
            setBackgroundColor(cBg)
            isClickable = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val logo = WifiLogoView(this)
        col.addView(logo, lp(dp(132), dp(132)))
        val name = label("WiFi Tools", 28f, cText, true).apply {
            alpha = 0f
            translationY = dp(12).toFloat()
            setPadding(0, dp(22), 0, 0)
        }
        val tag = label(t("Your network toolkit", "আপনার নেটওয়ার্ক টুলকিট"), 14f, cMuted).apply {
            alpha = 0f
            setPadding(0, dp(4), 0, 0)
        }
        col.addView(name)
        col.addView(tag)
        splash.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        splash.post {
            logo.scaleX = 0.6f
            logo.scaleY = 0.6f
            logo.animate().scaleX(1f).scaleY(1f).setDuration(1100)
                .setInterpolator(OvershootInterpolator(1.4f)).start()
            ValueAnimator.ofFloat(0f, 4f).apply {
                duration = 1100
                addUpdateListener { logo.progress = it.animatedValue as Float }
                start()
            }
            name.animate().alpha(1f).translationY(0f).setStartDelay(650).setDuration(450).start()
            tag.animate().alpha(1f).setStartDelay(850).setDuration(450).start()

            splash.postDelayed({
                splash.animate().alpha(0f).setDuration(380).withEndAction {
                    splash.visibility = View.GONE
                }.start()
                animateContentIn()
            }, 2100)
        }
        return splash
    }

    private fun prepareContentIn() {
        for (i in 0 until content.childCount) {
            val c = content.getChildAt(i)
            c.alpha = 0f
            c.translationY = dp(36).toFloat()
        }
    }

    private fun animateContentIn() {
        for (i in 0 until content.childCount) {
            content.getChildAt(i).animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(minOf(i, 12) * 60L)
                .setDuration(450)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    // ======================================================================
    //  Building the screen
    // ======================================================================

    private fun buildContent() {
        // ----- header -----
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, 0, dp(16))
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label("WiFi Tools", 30f, cText, true))
        titles.addView(
            label("${t("Your network toolkit", "আপনার নেটওয়ার্ক টুলকিট")}  \u2022  $appVersion", 13f, cMuted)
                .apply { setPadding(0, dp(2), 0, 0) }
        )
        head.addView(titles, lp(0, WRAP, 1f))
        head.addView(pill(if (dark) "\u2600" else "\uD83C\uDF19") { toggleTheme() },
            lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        head.addView(pill(if (bn) "EN" else "বাং") { toggleLang() })
        content.addView(head)

        content.addView(buildStatusCard())

        resultCard = buildResultCard()
        content.addView(resultCard, lp(MATCH, WRAP).apply { topMargin = dp(14) })

        // ----- quick tools -----
        addSection(t("QUICK TOOLS", "দ্রুত টুল"))
        addRow(
            tile("\u26A1", "#F59E0B", t("Speed Test", "স্পিড টেস্ট"), t("Ping, download, upload", "পিং, ডাউনলোড, আপলোড")) {
                runTask("Speed Test") { u -> speedTest(u) }
            },
            tile("\uD83C\uDF10", "#10B981", t("ISP Check", "ISP চেক"), t("IP, provider, city", "IP, প্রোভাইডার, শহর")) {
                runTask("ISP Check") { ispInfo() }
            }
        )
        addRow(
            tile("\uD83E\uDDED", "#8B5CF6", t("DNS Check", "DNS চেক"), t("Servers and speed", "সার্ভার ও গতি")) {
                runTask("DNS Check") { dnsCheck() }
            },
            tile("\uD83D\uDCE1", "#06B6D4", t("Devices", "ডিভাইস"), t("Who is on my network", "নেটওয়ার্কে কারা আছে")) {
                runTask("Connected Devices") { u -> scanDevices(u) }
            }
        )

        // ----- diagnose -----
        addSection(t("DIAGNOSE", "নেটওয়ার্ক পরীক্ষা"))
        addRow(
            tile("\uD83C\uDFD3", "#22C55E", "Ping", t("Test any site or IP", "যেকোনো সাইট বা IP টেস্ট")) {
                askText(t("Ping which site or IP?", "কোন সাইট বা IP পিং করবেন?"), "google.com", lastHost()) { h ->
                    prefs.edit().putString("last_host", h).apply()
                    runTask("Ping  $h") { kit.ping(h) }
                }
            },
            tile("\uD83D\uDEE3", "#F97316", "Traceroute", t("Where is it slow?", "কোথায় ধীর?")) {
                askText(t("Trace route to?", "কোথায় ট্রেস করবেন?"), "google.com", lastHost()) { h ->
                    prefs.edit().putString("last_host", h).apply()
                    runTask("Traceroute  $h") { u -> kit.traceroute(h, u) }
                }
            }
        )
        addRow(
            tile("\uD83D\uDEAA", "#EF4444", t("Port Scan", "পোর্ট স্ক্যান"), t("Open ports (own devices)", "খোলা পোর্ট (নিজের ডিভাইস)")) {
                askText(t("Scan which device?", "কোন ডিভাইস স্ক্যান করবেন?"), "192.168.0.1", gatewayIp() ?: "192.168.0.1") { h ->
                    runTask("Port Scan  $h") { u -> kit.portScan(h, u) }
                }
            },
            tile("\uD83D\uDD0D", "#A855F7", t("DNS Lookup", "DNS লুকআপ"), "A, MX, NS, TXT") {
                askText(t("Domain name?", "ডোমেইন নাম?"), "example.com", lastHost()) { h ->
                    prefs.edit().putString("last_host", h).apply()
                    runTask("DNS Lookup  $h") { kit.dnsLookup(h) }
                }
            }
        )
        addRow(
            tile("\uD83D\uDCCB", "#14B8A6", "Whois", t("Domain owner and dates", "ডোমেইনের তথ্য")) {
                askText(t("Domain name?", "ডোমেইন নাম?"), "example.com", lastHost()) { h ->
                    prefs.edit().putString("last_host", h).apply()
                    runTask("Whois  $h") { kit.whois(h) }
                }
            },
            tile("\uD83D\uDEE1", "#3B82F6", t("VPN and Leak", "VPN ও লিক"), t("DNS leak check", "DNS লিক চেক")) {
                runTask("VPN and DNS Leak") { kit.leakCheck() }
            }
        )

        // ----- wifi -----
        addSection(t("WI-FI", "ওয়াই-ফাই"))
        addRow(
            tile("\uD83D\uDCC8", "#22C55E", t("Signal Meter", "সিগন্যাল মিটার"), t("Live dBm graph", "লাইভ dBm গ্রাফ")) {
                toggleSignalMeter()
            },
            tile("\uD83D\uDCF6", "#F59E0B", t("Channels", "চ্যানেল"), t("Find the best channel", "সেরা চ্যানেল খুঁজুন")) {
                runTask("Channel Analyzer") { u -> kit.channels(u) }
            }
        )
        addRow(
            tile("\uD83D\uDCF7", "#38BDF8", t("Decode QR", "QR থেকে পাসওয়ার্ড"), t("Screenshot to password", "স্ক্রিনশট থেকে পাসওয়ার্ড")) {
                pickImage()
            },
            tile("\u2728", "#EC4899", t("Create QR", "QR তৈরি"), t("Let guests join", "অতিথিদের জন্য")) {
                showQrDialog()
            }
        )
        addRow(
            tile("\uD83D\uDD11", "#F43F5E", t("Password", "পাসওয়ার্ড"), t("Saved Wi-Fi (root only)", "সেভ করা (রুট লাগে)")) {
                runTask("Wi-Fi Password") { wifiPasswordRoot() }
            },
            tile("\u2699", "#64748B", t("Wi-Fi Settings", "ওয়াই-ফাই সেটিংস"), t("Open Share / QR screen", "শেয়ার/QR স্ক্রিন খুলুন")) {
                toast(
                    t(
                        "Tap your Wi-Fi, then Share, then take a screenshot. Come back and use Decode QR.",
                        "আপনার WiFi-তে ট্যাপ করে Share দিন, স্ক্রিনশট নিন, তারপর ফিরে এসে Decode QR ব্যবহার করুন।"
                    ), true
                )
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
        )

        // ----- extras -----
        addSection(t("EXTRAS", "আরও"))
        addRow(
            tile("\uD83C\uDF10", "#0EA5E9", t("Router Page", "রাউটার পেজ"), t("Open admin page", "অ্যাডমিন পেজ খুলুন")) {
                openRouter()
            },
            tile("\u23FB", "#84CC16", "Wake-on-LAN", t("Start a PC remotely", "দূর থেকে PC চালু")) {
                askText(t("MAC address of the PC", "PC-এর MAC অ্যাড্রেস"), "AA:BB:CC:DD:EE:FF", prefs.getString("wol_mac", "") ?: "") { mac ->
                    prefs.edit().putString("wol_mac", mac).apply()
                    runTask("Wake-on-LAN") { kit.sendWol(mac) }
                }
            }
        )
        addRow(
            tile("\uD83D\uDCCA", "#F59E0B", t("Speed History", "স্পিড হিস্ট্রি"), t("Past results", "আগের ফলাফল")) {
                resultTitle.text = "SPEED HISTORY"
                stopSignalMeter()
                render(historyText(10, false))
                scrollToResult()
            },
            tile("\uD83D\uDD14", "#EF4444", t("Network Watch", "নেটওয়ার্ক ওয়াচ"), t("Alert when a new device joins", "নতুন ডিভাইস এলে অ্যালার্ট")) {
                toggleWatch()
            }
        )
        content.addView(
            tile("\u2753", "#64748B", t("Help", "সাহায্য"), t("Tips and limits", "টিপস ও সীমাবদ্ধতা")) {
                resultTitle.text = "HELP"
                stopSignalMeter()
                render(helpText())
                scrollToResult()
            },
            lp(MATCH, WRAP).apply { setMargins(0, dp(6), 0, dp(6)) }
        )
    }

    private fun lastHost(): String = prefs.getString("last_host", "google.com") ?: "google.com"

    private fun buildStatusCard(): View {
        val gradient = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#2563EB"), Color.parseColor("#7C3AED"))
        ).apply { cornerRadius = dp(26).toFloat() }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(20))
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), gradient, null)
            isClickable = true
            setOnClickListener { runTask("Wi-Fi Info") { wifiInfoText() } }
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(
            label("\u25CF  " + t("CONNECTED", "সংযুক্ত"), 11f, Color.parseColor("#CCFFFFFF"), true)
                .apply { letterSpacing = 0.1f },
            lp(0, WRAP, 1f)
        )
        signalView = SignalView(this)
        top.addView(signalView, lp(dp(30), dp(22)))
        card.addView(top)

        ssidText = label("-", 28f, Color.WHITE, true).apply {
            setPadding(0, dp(10), 0, dp(12))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        card.addView(ssidText)

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipBand = chip()
        chipSpeed = chip()
        chipSignal = chip()
        chips.addView(chipBand, lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        chips.addView(chipSpeed, lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        chips.addView(chipSignal, lp(WRAP, WRAP))
        card.addView(chips)

        ipText = label("", 12.5f, Color.parseColor("#D9FFFFFF")).apply { setPadding(0, dp(12), 0, 0) }
        card.addView(ipText)
        card.addView(
            label(t("Tap for full details", "বিস্তারিত দেখতে ট্যাপ করুন"), 11f, Color.parseColor("#99FFFFFF"))
                .apply { setPadding(0, dp(6), 0, 0) }
        )
        return card
    }

    private fun buildResultCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(cCard, 22)
            setPadding(dp(20), dp(16), dp(20), dp(20))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        resultTitle = label(t("RESULT", "ফলাফল"), 11f, cMuted, true).apply { letterSpacing = 0.12f }
        head.addView(resultTitle, lp(0, WRAP, 1f))
        head.addView(pill(t("SHARE", "শেয়ার")) { shareResult() }, lp(WRAP, WRAP).apply { rightMargin = dp(8) })
        head.addView(pill(t("COPY", "কপি")) { copyResult() })
        card.addView(head)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(cAccent)
            visibility = View.GONE
        }
        card.addView(progress, lp(MATCH, dp(4)).apply { topMargin = dp(10) })

        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        card.addView(resultBox)
        render(t("Pick a tool below to get started.", "শুরু করতে নিচ থেকে একটি টুল বেছে নিন।"))
        return card
    }

    // ======================================================================
    //  UI helpers
    // ======================================================================

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun bg(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), cStroke)
    }

    private fun pill(s: String, action: () -> Unit) = TextView(this).apply {
        text = s
        textSize = 12f
        setTextColor(cAccent)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(7), dp(12), dp(7))
        background = GradientDrawable().apply {
            cornerRadius = dp(50).toFloat()
            setStroke(dp(1), cAccent)
        }
        setOnClickListener { action() }
    }

    private fun chip(): TextView = TextView(this).apply {
        textSize = 12f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(11), dp(5), dp(11), dp(5))
        background = GradientDrawable().apply {
            setColor(0x33FFFFFF)
            cornerRadius = dp(50).toFloat()
        }
        visibility = View.GONE
    }

    private fun addSection(title: String) {
        content.addView(label(title, 11f, cMuted, true).apply {
            letterSpacing = 0.12f
            setPadding(dp(4), dp(22), 0, dp(6))
        })
    }

    private fun tile(icon: String, accentHex: String, title: String, sub: String, action: () -> Unit): LinearLayout {
        val accent = Color.parseColor(accentHex)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = RippleDrawable(ColorStateList.valueOf(0x22888888), bg(cCard, 20), null)
            isClickable = true
            setOnClickListener { action() }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
        }
        val badge = TextView(this).apply {
            text = icon
            textSize = 22f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor((accent and 0x00FFFFFF) or 0x33000000)
            }
        }
        box.addView(badge, lp(dp(46), dp(46)))
        box.addView(label(title, 16f, cText, true).apply { setPadding(0, dp(12), 0, dp(2)) })
        box.addView(label(sub, 12f, cMuted))
        return box
    }

    private fun addRow(a: View, b: View) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = dp(6)
        r.addView(a, lp(0, MATCH, 1f).apply { setMargins(m, m, m, m) })
        r.addView(b, lp(0, MATCH, 1f).apply { setMargins(m, m, m, m) })
        content.addView(r, lp(MATCH, WRAP).apply { setMargins(-m, 0, -m, 0) })
    }

    private fun askText(title: String, hint: String, def: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply {
            setText(def)
            setSelection(text.length)
            this.hint = hint
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(et)
        }
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val v = et.text.toString().trim()
                if (v.isNotEmpty()) onOk(v)
            }
            .setNegativeButton(t("Cancel", "বাতিল"), null)
            .show()
    }

    private fun signalLevel(rssi: Int) = when {
        rssi >= -55 -> 4
        rssi >= -65 -> 3
        rssi >= -75 -> 2
        rssi >= -88 -> 1
        else -> 0
    }

    private fun signalName(level: Int) = arrayOf("Very weak", "Weak", "Fair", "Good", "Excellent")[level]

    private fun bandName(mhz: Int) = when {
        mhz < 3000 -> "2.4 GHz"
        mhz < 5900 -> "5 GHz"
        else -> "6 GHz"
    }

    @Suppress("DEPRECATION")
    private fun refreshHeader() {
        val ip = localIpv4()
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val onWifi = ip != null && wm.isWifiEnabled && info != null && info.networkId != -1

        if (!onWifi) {
            ssidText.text = t("Not connected", "সংযুক্ত নয়")
            ipText.text = t("Connect to a Wi-Fi network to use the tools", "টুল ব্যবহার করতে WiFi-তে সংযুক্ত হন")
            chipBand.visibility = View.GONE
            chipSpeed.visibility = View.GONE
            chipSignal.visibility = View.GONE
            signalView.level = 0
            return
        }

        ssidText.text = currentSsid() ?: t("Wi-Fi (allow Location to see name)", "ওয়াই-ফাই (নাম দেখতে Location অনুমতি দিন)")

        val f = info.frequency
        if (f > 0) {
            chipBand.text = bandName(f)
            chipBand.visibility = View.VISIBLE
        } else {
            chipBand.visibility = View.GONE
        }
        val ls = info.linkSpeed
        if (ls > 0) {
            chipSpeed.text = "$ls Mbps"
            chipSpeed.visibility = View.VISIBLE
        } else {
            chipSpeed.visibility = View.GONE
        }
        val rssi = info.rssi
        if (rssi > -127) {
            chipSignal.text = "$rssi dBm"
            chipSignal.visibility = View.VISIBLE
        } else {
            chipSignal.visibility = View.GONE
        }
        signalView.level = signalLevel(rssi)
        val gw = gatewayIp()
        ipText.text = "IP $ip" + (if (gw != null) "   \u2022   Router $gw" else "")
    }

    private fun copyResult() {
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("result", plainResult))
        toast(t("Copied", "কপি হয়েছে"))
    }

    private fun shareResult() {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, plainResult)
        }
        startActivity(Intent.createChooser(i, t("Share result", "ফলাফল শেয়ার")))
    }

    private fun scrollToResult() {
        scroller.post { scroller.smoothScrollTo(0, maxOf(0, resultCard.top - dp(12))) }
    }

    private fun runTask(title: String, block: suspend (update: (String) -> Unit) -> String) {
        stopSignalMeter()
        resultTitle.text = title.uppercase()
        render("Working...")
        progress.visibility = View.VISIBLE
        scrollToResult()
        val update: (String) -> Unit = { msg -> runOnUiThread { render(msg) } }
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) { block(update) }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            progress.visibility = View.GONE
            render(result)
        }
    }

    // ======================================================================
    //  Result rendering.
    //  Tiny markup used by the tools:
    //    "# Title"                       section heading
    //    "key|value"                     a row
    //    "stat|Label|123|unit"           big number box (consecutive ones share a row)
    //    "dev|ip|name|mac|tag|isNew"     a device row
    //    "graph|Label|1,2,3"             a small line graph
    //    "! text"                        small note
    //    anything else                   plain text
    // ======================================================================

    private fun toPlain(text: String): String {
        val sb = StringBuilder()
        for (l in text.lines()) {
            when {
                l.isBlank() -> {}
                l.startsWith("# ") -> sb.appendLine().appendLine(l.substring(2).uppercase())
                l.startsWith("! ") -> sb.appendLine(l.substring(2))
                l.startsWith("graph|") -> {}
                l.startsWith("stat|") -> {
                    val p = l.split("|")
                    sb.appendLine("${p.getOrElse(1) { "" }}: ${p.getOrElse(2) { "" }} ${p.getOrElse(3) { "" }}")
                }
                l.startsWith("dev|") -> {
                    val p = l.split("|")
                    sb.appendLine("${p.getOrElse(1) { "" }} ${p.getOrElse(4) { "" }} - ${p.getOrElse(2) { "" }} - ${p.getOrElse(3) { "" }}")
                }
                l.contains("|") -> sb.appendLine(l.replaceFirst("|", ": "))
                else -> sb.appendLine(l)
            }
        }
        return sb.toString().trim()
    }

    private fun render(text: String) {
        plainResult = toPlain(text)
        resultBox.removeAllViews()
        val lines = text.lines().filter { it.isNotBlank() }
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            if (l.startsWith("stat|")) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                while (i < lines.size && lines[i].startsWith("stat|")) {
                    val p = lines[i].split("|")
                    r.addView(
                        statBox(p.getOrElse(1) { "" }, p.getOrElse(2) { "" }, p.getOrElse(3) { "" }),
                        lp(0, WRAP, 1f).apply { setMargins(dp(4), dp(6), dp(4), dp(2)) }
                    )
                    i++
                }
                resultBox.addView(r, lp(MATCH, WRAP).apply { setMargins(-dp(4), 0, -dp(4), 0) })
                continue
            }
            if (l.startsWith("# ")) {
                resultBox.addView(label(l.substring(2).uppercase(), 11f, cAccent, true).apply {
                    letterSpacing = 0.12f
                    setPadding(0, dp(14), 0, dp(4))
                })
            } else if (l.startsWith("! ")) {
                resultBox.addView(label(l.substring(2), 11.5f, cMuted).apply { setPadding(0, dp(12), 0, 0) })
            } else if (l.startsWith("graph|")) {
                val p = l.split("|")
                val vals = p.getOrElse(2) { "" }.split(",").mapNotNull { it.toFloatOrNull() }
                resultBox.addView(label(p.getOrElse(1) { "" }, 11.5f, cMuted).apply { setPadding(0, dp(14), 0, dp(4)) })
                resultBox.addView(GraphView(this).apply {
                    values = vals
                    lineColor = cAccent
                    gridColor = cDivider
                }, lp(MATCH, dp(110)))
            } else if (l.startsWith("dev|")) {
                val p = l.split("|")
                resultBox.addView(
                    devRow(
                        p.getOrElse(1) { "" }, p.getOrElse(2) { "" }, p.getOrElse(3) { "" },
                        p.getOrElse(4) { "" }, p.getOrElse(5) { "0" } == "1"
                    )
                )
            } else if (l.contains("|")) {
                val p = l.split("|", limit = 2)
                resultBox.addView(kvRow(p[0], p.getOrElse(1) { "" }))
                resultBox.addView(View(this).apply { setBackgroundColor(cDivider) }, lp(MATCH, dp(1)))
            } else {
                resultBox.addView(label(l, 14f, cText).apply { setPadding(0, dp(4), 0, dp(4)) })
            }
            i++
        }
    }

    private fun kvRow(k: String, v: String): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(9), 0, dp(9))
        }
        r.addView(label(k, 13.5f, cMuted), lp(WRAP, WRAP).apply { rightMargin = dp(16) })
        r.addView(label(v, 14f, cText, true).apply {
            gravity = Gravity.END
            setTextIsSelectable(true)
        }, lp(0, WRAP, 1f))
        return r
    }

    private fun statBox(k: String, v: String, unit: String): View {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(14), dp(6), dp(14))
            background = bg(cBg2, 16)
        }
        b.addView(label(k.uppercase(), 10f, cMuted, true).apply { letterSpacing = 0.1f })
        b.addView(label(v, 24f, cText, true).apply { setPadding(0, dp(6), 0, 0) })
        b.addView(label(unit, 11f, cAccent))
        return b
    }

    private fun devKey(ip: String, name: String, mac: String): String =
        if (mac.contains(":")) mac else if (name != "Unknown device") name else ip

    private fun devRow(ip: String, name: String, mac: String, tag: String, isNew: Boolean): View {
        val key = devKey(ip, name, mac)
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
            isClickable = true
        }
        val icon = when (tag) {
            "Router" -> "\uD83D\uDCE1"
            "This phone" -> "\uD83D\uDCF1"
            else -> "\uD83D\uDCBB"
        }
        val badge = TextView(this).apply {
            text = icon
            textSize = 18f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(cBg2)
                setStroke(dp(1), cStroke)
            }
        }
        r.addView(badge, lp(dp(42), dp(42)).apply { rightMargin = dp(14) })

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleView = label(ip, 15f, cText, true)
        val subView = label("", 12f, cMuted).apply { setPadding(0, dp(2), 0, 0) }
        titleRow.addView(titleView)
        if (tag.isNotEmpty()) {
            titleRow.addView(label(tag, 11f, cAccent, true).apply { setPadding(dp(8), 0, 0, 0) })
        }
        if (isNew) {
            titleRow.addView(label("NEW", 10f, Color.parseColor("#22C55E"), true).apply { setPadding(dp(8), 0, 0, 0) })
        }
        col.addView(titleRow)
        col.addView(subView)
        r.addView(col, lp(0, WRAP, 1f))

        fun custom(): String? = prefs.getString("dn_$key", null)
        fun refresh() {
            val c = custom()
            titleView.text = c ?: ip
            subView.text = if (c != null) "$ip  \u2022  $name  \u2022  $mac" else "$name  \u2022  $mac"
        }
        refresh()
        r.setOnClickListener {
            askText(t("Name this device", "ডিভাইসের নাম দিন"), "e.g. Dad's phone", custom() ?: "") { v ->
                prefs.edit().putString("dn_$key", v).apply()
                refresh()
            }
        }
        return r
    }

    // ======================================================================
    //  Network helpers
    // ======================================================================

    private fun cm() = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private fun linkProps() = cm().let { it.getLinkProperties(it.activeNetwork) }

    private fun localIpv4(): String? {
        val la = linkProps()?.linkAddresses?.firstOrNull { it.address is Inet4Address } ?: return null
        return la.address.hostAddress
    }

    private fun gatewayIp(): String? {
        val r = linkProps()?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
        return r?.gateway?.hostAddress
    }

    @Suppress("DEPRECATION")
    private fun currentSsid(): String? {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val s = wm.connectionInfo?.ssid?.trim('"') ?: return null
        return if (s == "<unknown ssid>" || s.isEmpty()) null else s
    }

    @Suppress("DEPRECATION")
    private fun currentRssi(): Int {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return wm.connectionInfo?.rssi ?: -127
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 7000
        c.setRequestProperty("User-Agent", "WifiTools/3.0")
        return try {
            c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)

    // ======================================================================
    //  Wi-Fi info
    // ======================================================================

    @Suppress("DEPRECATION")
    private fun wifiInfoText(): String {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val ssid = currentSsid()
        val rssi = info?.rssi ?: -127
        val sb = StringBuilder()
        sb.appendLine("# Connection")
        sb.appendLine("Network|${ssid ?: "unknown (allow Location, turn it ON)"}")
        sb.appendLine("BSSID|${info?.bssid ?: "-"}")
        sb.appendLine("Signal|$rssi dBm (${signalName(signalLevel(rssi))})")
        sb.appendLine("Link speed|${info?.linkSpeed ?: "-"} Mbps")
        val f = info?.frequency ?: 0
        sb.appendLine("Frequency|${if (f > 0) "$f MHz (${bandName(f)})" else "-"}")
        sb.appendLine("# Addresses")
        sb.appendLine("My IP|${localIpv4() ?: "-"}")
        sb.appendLine("Router|${gatewayIp() ?: "-"}")
        val dns = linkProps()?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()
        sb.appendLine("DNS|${if (dns.isEmpty()) "-" else dns.joinToString(", ")}")
        return sb.toString()
    }

    // ======================================================================
    //  Speed test + history
    // ======================================================================

    private fun measurePing(): Long {
        val t0 = System.nanoTime()
        val c = URL("https://speed.cloudflare.com/__down?bytes=0").openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 5000
        c.inputStream.use { it.readBytes() }
        c.disconnect()
        return (System.nanoTime() - t0) / 1_000_000
    }

    private fun speedTest(update: (String) -> Unit): String {
        update("Testing latency...")
        try { measurePing() } catch (e: Exception) { /* warm-up */ }
        val pings = (1..5).mapNotNull { try { measurePing() } catch (e: Exception) { null } }
        if (pings.isEmpty()) return "No internet connection."
        val jitter = if (pings.size > 1) pings.zipWithNext { a, b -> Math.abs(a - b) }.average() else 0.0
        val pingAvg = pings.average().toLong()
        val pingMin = pings.min()

        update("Ping $pingAvg ms\nTesting download...")
        val dc = URL("https://speed.cloudflare.com/__down?bytes=25000000").openConnection() as HttpURLConnection
        dc.connectTimeout = 7000
        dc.readTimeout = 10000
        var total = 0L
        val start = System.nanoTime()
        dc.inputStream.use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                total += n
                if (System.nanoTime() - start > 10_000_000_000L) break
            }
        }
        dc.disconnect()
        val dSecs = (System.nanoTime() - start) / 1e9
        val down = total * 8 / 1e6 / dSecs

        update("Ping $pingAvg ms\nDownload ${f1(down)} Mbps\nTesting upload...")
        val size = 8_000_000
        val uc = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
        uc.requestMethod = "POST"
        uc.doOutput = true
        uc.connectTimeout = 7000
        uc.readTimeout = 15000
        uc.setFixedLengthStreamingMode(size)
        val us = System.nanoTime()
        uc.outputStream.use { os ->
            val chunk = ByteArray(64 * 1024)
            var sent = 0
            while (sent < size) {
                val n = minOf(chunk.size, size - sent)
                os.write(chunk, 0, n)
                sent += n
            }
        }
        uc.responseCode
        uc.disconnect()
        val uSecs = (System.nanoTime() - us) / 1e9
        val up = size * 8 / 1e6 / uSecs

        saveHistory(down, up, pingAvg)

        val sb = StringBuilder()
        sb.appendLine("stat|Download|${f1(down)}|Mbps")
        sb.appendLine("stat|Upload|${f1(up)}|Mbps")
        sb.appendLine("stat|Ping|$pingAvg|ms")
        sb.appendLine("Best ping|$pingMin ms")
        sb.appendLine("Jitter|${f1(jitter)} ms")
        sb.appendLine("! Measured against Cloudflare's speed servers.")
        sb.append(historyText(5, true))
        return sb.toString()
    }

    private fun readHistory(): JSONArray =
        try { JSONArray(prefs.getString("hist", "[]")) } catch (e: Exception) { JSONArray() }

    private fun saveHistory(down: Double, up: Double, ping: Long) {
        val arr = readHistory()
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("d", down).put("u", up).put("p", ping))
        val out = JSONArray()
        for (i in maxOf(0, arr.length() - 30) until arr.length()) out.put(arr.get(i))
        prefs.edit().putString("hist", out.toString()).apply()
    }

    private fun historyText(limit: Int, skipLatest: Boolean): String {
        val arr = readHistory()
        val n = arr.length()
        if (n == 0) return "No saved speed tests yet.\nRun a Speed Test first, results are saved automatically."
        if (skipLatest && n < 2) return ""
        val sb = StringBuilder()
        sb.appendLine("# ${if (skipLatest) "Previous tests" else "Saved tests"}")
        val fmt = SimpleDateFormat("dd MMM, HH:mm", Locale.US)
        val last = n - 1 - (if (skipLatest) 1 else 0)
        for (i in last downTo maxOf(0, last - limit + 1)) {
            val o = arr.getJSONObject(i)
            sb.appendLine(
                "${fmt.format(Date(o.getLong("t")))}|\u2193 ${f1(o.getDouble("d"))}  \u2191 ${f1(o.getDouble("u"))} Mbps  \u2022  ${o.getLong("p")} ms"
            )
        }
        if (n >= 2) {
            val vals = ArrayList<String>()
            for (i in maxOf(0, n - 20) until n) vals.add(f1(arr.getJSONObject(i).getDouble("d")))
            sb.appendLine("graph|Download history (Mbps)|${vals.joinToString(",")}")
        }
        return sb.toString()
    }

    // ======================================================================
    //  ISP check
    // ======================================================================

    private fun ispInfo(): String {
        val j = JSONObject(httpGet("https://ipinfo.io/json"))
        val sb = StringBuilder()
        sb.appendLine("# Your connection")
        sb.appendLine("Public IP|${j.optString("ip", "-")}")
        sb.appendLine("ISP / ASN|${j.optString("org", "-")}")
        sb.appendLine("# Location (approximate)")
        sb.appendLine("City|${j.optString("city", "-")}")
        sb.appendLine("Region|${j.optString("region", "-")}")
        sb.appendLine("Country|${j.optString("country", "-")}")
        sb.appendLine("Timezone|${j.optString("timezone", "-")}")
        return sb.toString()
    }

    // ======================================================================
    //  DNS check
    // ======================================================================

    private fun dnsQuery(server: InetAddress, domain: String): Long {
        return try {
            val baos = ByteArrayOutputStream()
            val d = DataOutputStream(baos)
            d.writeShort(0x1234)
            d.writeShort(0x0100)
            d.writeShort(1)
            d.writeShort(0)
            d.writeShort(0)
            d.writeShort(0)
            for (part in domain.split(".")) {
                d.writeByte(part.length)
                d.write(part.toByteArray())
            }
            d.writeByte(0)
            d.writeShort(1)
            d.writeShort(1)
            val data = baos.toByteArray()
            val s = DatagramSocket()
            try {
                s.soTimeout = 3000
                val t0 = System.nanoTime()
                s.send(DatagramPacket(data, data.size, server, 53))
                val buf = ByteArray(512)
                s.receive(DatagramPacket(buf, buf.size))
                (System.nanoTime() - t0) / 1_000_000
            } finally {
                s.close()
            }
        } catch (e: Exception) {
            -1L
        }
    }

    private fun fmtMs(ms: Long) = if (ms < 0) "timeout" else "$ms ms"

    private fun dnsCheck(): String {
        val sb = StringBuilder()
        val props = linkProps()
        val servers = props?.dnsServers ?: emptyList()

        sb.appendLine("# Your DNS servers")
        if (servers.isEmpty()) sb.appendLine("None found|-")
        for (s in servers) {
            sb.appendLine("${s.hostAddress}|${fmtMs(dnsQuery(s, "example.com"))}")
        }
        if (Build.VERSION.SDK_INT >= 28 && props != null) {
            sb.appendLine("Private DNS|${if (props.isPrivateDnsActive) "ON (${props.privateDnsServerName ?: "auto"})" else "OFF"}")
        }

        sb.appendLine("# Public DNS comparison")
        val publics = listOf("Google 8.8.8.8" to "8.8.8.8", "Cloudflare 1.1.1.1" to "1.1.1.1", "Quad9 9.9.9.9" to "9.9.9.9")
        for ((name, ip) in publics) {
            sb.appendLine("$name|${fmtMs(dnsQuery(InetAddress.getByName(ip), "example.com"))}")
        }

        sb.appendLine("# System resolver")
        val t0 = System.nanoTime()
        val r = try {
            InetAddress.getByName("www.wikipedia.org").hostAddress
        } catch (e: Exception) {
            "failed"
        }
        sb.appendLine("www.wikipedia.org|$r (${(System.nanoTime() - t0) / 1_000_000} ms)")
        sb.appendLine("! Lower milliseconds means faster DNS.")
        return sb.toString()
    }

    // ======================================================================
    //  Device scan
    // ======================================================================

    private fun isAlive(host: String): Boolean {
        val addr = InetAddress.getByName(host)
        try {
            if (addr.isReachable(400)) return true
        } catch (e: Exception) { }
        for (port in intArrayOf(80, 443, 53, 22, 445, 8080, 62078)) {
            val s = Socket()
            try {
                s.connect(InetSocketAddress(addr, port), 150)
                return true
            } catch (e: ConnectException) {
                return true // connection refused = a device exists there
            } catch (e: Exception) {
            } finally {
                try { s.close() } catch (e: Exception) { }
            }
        }
        return false
    }

    private fun hostName(host: String): String {
        return try {
            val n = InetAddress.getByName(host).canonicalHostName
            if (n == host) "Unknown device" else n
        } catch (e: Exception) {
            "Unknown device"
        }
    }

    private fun arpTable(): Map<String, String> = try {
        File("/proc/net/arp").readLines().drop(1).mapNotNull { line ->
            val p = line.trim().split(Regex("\\s+"))
            if (p.size >= 4 && p[3] != "00:00:00:00:00:00") p[0] to p[3] else null
        }.toMap()
    } catch (e: Exception) {
        emptyMap()
    }

    private suspend fun scanDevices(update: (String) -> Unit): String = coroutineScope {
        val me = localIpv4() ?: return@coroutineScope "Not connected to Wi-Fi."
        val gw = gatewayIp()
        val base = me.substringBeforeLast(".")
        val found = ConcurrentHashMap<String, String>()
        val sem = Semaphore(64)

        update("Scanning $base.1 - $base.254 ...\nThis takes about 10 seconds.")
        (1..254).map { i ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    val host = "$base.$i"
                    if (host == me || isAlive(host)) found[host] = hostName(host)
                }
            }
        }.awaitAll()

        val arp = arpTable()
        val seen = HashSet<String>(prefs.getStringSet("seen", emptySet<String>()) ?: emptySet<String>())
        val firstScan = seen.isEmpty()
        val rows = StringBuilder()
        var newCount = 0
        for ((ip, name) in found.toSortedMap(compareBy<String> { it.substringAfterLast(".").toInt() })) {
            val mac = arp[ip] ?: "MAC hidden"
            val tag = when (ip) {
                me -> "This phone"
                gw -> "Router"
                else -> ""
            }
            val key = devKey(ip, name, mac)
            val isNew = !firstScan && !seen.contains(key)
            if (isNew) newCount++
            seen.add(key)
            rows.appendLine("dev|$ip|$name|$mac|$tag|${if (isNew) "1" else "0"}")
        }
        prefs.edit().putStringSet("seen", seen).apply()

        val sb = StringBuilder()
        sb.appendLine("# ${found.size} device(s) found" + (if (newCount > 0) "  \u2022  $newCount new" else ""))
        sb.append(rows)
        if (firstScan) sb.appendLine("! First scan saved as your baseline. Devices that join later are marked NEW.")
        sb.appendLine("! Tap a device to give it a name.")
        sb.appendLine("! Sleeping devices may not respond, and Android 10+ hides MAC addresses.")
        sb.toString()
    }

    // ======================================================================
    //  Network Watch (background alerts, see NetUtil.kt / WatchJobService)
    // ======================================================================

    private fun toggleWatch() {
        val js = getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (prefs.getBoolean("watch", false)) {
            js.cancel(watchJobId)
            prefs.edit().putBoolean("watch", false).apply()
            toast(t("Network Watch is OFF", "নেটওয়ার্ক ওয়াচ বন্ধ"))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            toast(t("Allow notifications, then tap Network Watch again", "নোটিফিকেশনের অনুমতি দিয়ে আবার ট্যাপ করুন"), true)
            return
        }
        if (localIpv4() == null) {
            toast(t("Connect to Wi-Fi first", "আগে WiFi-তে সংযুক্ত হন"))
            return
        }
        toast(t("Learning the devices on your network...", "আপনার নেটওয়ার্কের ডিভাইসগুলো চিনে নিচ্ছি..."))
        scope.launch {
            val ips = withContext(Dispatchers.IO) { NetUtil.scanIps(applicationContext) }
            prefs.edit().putStringSet("known", HashSet<String>(ips)).putBoolean("watch", true).apply()
            val info = JobInfo.Builder(watchJobId, ComponentName(this@MainActivity, WatchJobService::class.java))
                .setPeriodic(15 * 60 * 1000L)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED)
                .setPersisted(true)
                .build()
            js.schedule(info)
            toast(
                t(
                    "Network Watch is ON. You get an alert when a new device joins.",
                    "নেটওয়ার্ক ওয়াচ চালু। নতুন ডিভাইস এলে অ্যালার্ট পাবেন।"
                ), true
            )
        }
    }

    // ======================================================================
    //  Live signal meter
    // ======================================================================

    private fun stopSignalMeter() {
        signalJob?.cancel()
        signalJob = null
    }

    private fun signalColor(rssi: Int): Int = when {
        rssi >= -60 -> Color.parseColor("#22C55E")
        rssi >= -70 -> Color.parseColor("#84CC16")
        rssi >= -80 -> Color.parseColor("#F59E0B")
        else -> Color.parseColor("#EF4444")
    }

    private fun signalAdvice(rssi: Int): String = when {
        rssi >= -60 -> t("Excellent. You are close to the router.", "চমৎকার। রাউটারের কাছেই আছেন।")
        rssi >= -70 -> t("Good for streaming and calls.", "স্ট্রিমিং ও কলের জন্য ভালো।")
        rssi >= -80 -> t("Fair. Speeds may drop here.", "মোটামুটি। এখানে স্পিড কমতে পারে।")
        else -> t("Weak. Move closer to the router.", "দুর্বল। রাউটারের কাছে যান।")
    }

    private fun toggleSignalMeter() {
        if (signalJob != null) {
            stopSignalMeter()
            toast(t("Signal meter stopped", "সিগন্যাল মিটার বন্ধ"))
            return
        }
        resultTitle.text = t("LIVE SIGNAL", "লাইভ সিগন্যাল")
        resultBox.removeAllViews()
        progress.visibility = View.GONE
        val big = label("--", 46f, cText, true).apply { gravity = Gravity.CENTER }
        val desc = label(t("Reading signal...", "সিগন্যাল পড়া হচ্ছে..."), 14f, cMuted).apply { gravity = Gravity.CENTER }
        val graph = GraphView(this).apply {
            minV = -100f
            maxV = -30f
            lineColor = cAccent
            gridColor = cDivider
        }
        resultBox.addView(big, lp(MATCH, WRAP))
        resultBox.addView(desc, lp(MATCH, WRAP))
        resultBox.addView(graph, lp(MATCH, dp(150)).apply { topMargin = dp(12) })
        resultBox.addView(
            label(
                t(
                    "Walk around with your phone to find the best spot. Tap the Signal Meter tile again to stop.",
                    "ফোন নিয়ে ঘুরে সেরা জায়গা খুঁজুন। বন্ধ করতে আবার Signal Meter টাইলে ট্যাপ করুন।"
                ), 11.5f, cMuted
            ).apply { setPadding(0, dp(12), 0, 0) }
        )
        plainResult = ""
        scrollToResult()

        val samples = ArrayList<Float>()
        signalJob = scope.launch {
            while (true) {
                val rssi = currentRssi()
                if (rssi > -127) {
                    samples.add(rssi.toFloat())
                    if (samples.size > 60) samples.removeAt(0)
                    graph.values = samples.toList()
                    big.text = "$rssi dBm"
                    big.setTextColor(signalColor(rssi))
                    desc.text = signalAdvice(rssi)
                } else {
                    big.text = "--"
                    desc.text = t("Not connected to Wi-Fi", "WiFi-তে সংযুক্ত নন")
                }
                delay(500)
            }
        }
    }

    // ======================================================================
    //  Router page
    // ======================================================================

    private fun openRouter() {
        val gw = gatewayIp()
        if (gw == null) {
            toast(t("Connect to Wi-Fi first", "আগে WiFi-তে সংযুক্ত হন"))
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("http://$gw")))
        } catch (e: Exception) {
            toast("Could not open http://$gw")
        }
    }

    // ======================================================================
    //  QR: create + decode
    // ======================================================================

    private fun esc(s: String) = s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,")
        .replace(":", "\\:").replace("\"", "\\\"")

    private fun showQrDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val ssid = EditText(this).apply {
            hint = t("Wi-Fi name", "ওয়াই-ফাইয়ের নাম")
            setText(currentSsid() ?: "")
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        val pass = EditText(this).apply {
            hint = t("Password (empty if open)", "পাসওয়ার্ড (ওপেন হলে খালি রাখুন)")
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        box.addView(ssid)
        box.addView(pass)
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(t("Create Wi-Fi QR", "ওয়াই-ফাই QR তৈরি"))
            .setView(box)
            .setPositiveButton(t("Create", "তৈরি করুন")) { _, _ ->
                val s = ssid.text.toString()
                if (s.isNotEmpty()) showQrImage(s, pass.text.toString())
            }
            .setNegativeButton(t("Cancel", "বাতিল"), null)
            .show()
    }

    private fun showQrImage(ssid: String, pass: String) {
        try {
            val security = if (pass.isEmpty()) "nopass" else "WPA"
            val payload = "WIFI:T:$security;S:${esc(ssid)};P:${esc(pass)};;"
            val size = 700
            val m = QRCodeWriter().encode(
                payload, BarcodeFormat.QR_CODE, size, size,
                mapOf<EncodeHintType, Any>(EncodeHintType.MARGIN to 2)
            )
            val px = IntArray(size * size)
            for (y in 0 until size) {
                val o = y * size
                for (x in 0 until size) px[o + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
            }
            val bmp = Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
            val img = ImageView(this).apply {
                setImageBitmap(bmp)
                setBackgroundColor(Color.WHITE)
                adjustViewBounds = true
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            val holder = FrameLayout(this).apply {
                setPadding(dp(24), dp(8), dp(24), 0)
                addView(img)
            }
            AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(ssid)
                .setMessage(t("Guests can scan this with their phone camera to join.", "অতিথিরা ফোনের ক্যামেরা দিয়ে স্ক্যান করলেই কানেক্ট হবে।"))
                .setView(holder)
                .setPositiveButton(t("Close", "বন্ধ"), null)
                .show()
        } catch (e: Exception) {
            toast("Could not create the QR code")
        }
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(i, "Select the Wi-Fi QR screenshot"), reqPick)
    }

    private fun decodeBitmap(bmp: Bitmap): String? {
        val w = bmp.width
        val h = bmp.height
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)
        val source = RGBLuminanceSource(w, h, pixels)
        val hints = mapOf<DecodeHintType, Any>(
            DecodeHintType.TRY_HARDER to true,
            DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE)
        )
        val reader = MultiFormatReader()
        for (src in listOf<LuminanceSource>(source, source.invert())) {
            try {
                return reader.decode(BinaryBitmap(HybridBinarizer(src)), hints).text
            } catch (e: NotFoundException) {
            } catch (e: Exception) {
            }
        }
        return null
    }

    private fun parseWifiQr(text: String): Map<String, String> {
        val fields = mutableMapOf<String, String>()
        val body = text.substring(5)
        var i = 0
        while (i < body.length) {
            val colon = body.indexOf(':', i)
            if (colon < 0) break
            val key = body.substring(i, colon)
            i = colon + 1
            val v = StringBuilder()
            while (i < body.length && body[i] != ';') {
                if (body[i] == '\\' && i + 1 < body.length) {
                    v.append(body[i + 1])
                    i += 2
                } else {
                    v.append(body[i])
                    i++
                }
            }
            fields[key.uppercase()] = v.toString()
            i++
        }
        return fields
    }

    private fun decodeQr(uri: Uri): String {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return "Could not open that image."

        val text = decodeBitmap(bmp)
            ?: return "No QR code found in this image.\n" +
                "Tips:\n" +
                "1. Open Wi-Fi Settings, tap your network, tap Share\n" +
                "2. Take a screenshot while the QR code is visible\n" +
                "3. Pick that screenshot here\n" +
                "If your phone blocks screenshots on that screen, scan the QR with another phone's camera or Google Lens."

        if (!text.startsWith("WIFI:", ignoreCase = true)) {
            return "# QR code content\nText|$text\n! This QR does not contain Wi-Fi details."
        }
        val f = parseWifiQr(text)
        val security = when (f["T"]?.uppercase()) {
            "WPA", "WPA2", "WPA3", "SAE" -> "WPA / WPA2 / WPA3"
            "WEP" -> "WEP"
            "NOPASS", "", null -> "Open (no password)"
            else -> f["T"] ?: "-"
        }
        val pass = f["P"]
        val sb = StringBuilder()
        sb.appendLine("# Wi-Fi found in QR")
        sb.appendLine("Network|${f["S"] ?: "-"}")
        sb.appendLine("Password|${if (pass.isNullOrEmpty()) "(none, open network)" else pass}")
        sb.appendLine("Security|$security")
        sb.appendLine("Hidden|${if (f["H"].equals("true", ignoreCase = true)) "Yes" else "No"}")
        sb.appendLine("! Long-press the password to copy it, or tap COPY at the top of this card.")
        return sb.toString()
    }

    // ======================================================================
    //  Wi-Fi password (root only)
    // ======================================================================

    private fun wifiPasswordRoot(): String {
        val xml = try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "cat /data/misc/wifi/WifiConfigStore.xml"))
            p.inputStream.bufferedReader().readText()
        } catch (e: Exception) {
            ""
        }
        if (xml.isBlank()) {
            return "# Root access not available\n" +
                "Without root, use the Decode QR tile:\n" +
                "1. Tap the 'Wi-Fi Settings' tile, tap your network, tap Share\n" +
                "2. Take a screenshot of the QR code\n" +
                "3. Tap 'Decode QR' and pick the screenshot\n"
        }
        val ssid = currentSsid()
        val saved = xml.split("<Network>").mapNotNull { b ->
            val s = Regex("name=\"SSID\">(.*?)</string>").find(b)?.groupValues?.get(1)?.replace("&quot;", "")
            val pw = Regex("name=\"PreSharedKey\">(.*?)</string>").find(b)?.groupValues?.get(1)?.replace("&quot;", "")
            if (s != null) s to (pw ?: "(open network)") else null
        }
        val sb = StringBuilder()
        val match = saved.firstOrNull { it.first == ssid }
        if (match != null) {
            sb.appendLine("# Connected network")
            sb.appendLine("Name|${match.first}")
            sb.appendLine("Password|${match.second}")
        }
        sb.appendLine("# All saved networks")
        for ((s, p) in saved) sb.appendLine("$s|$p")
        return sb.toString()
    }

    // ======================================================================
    //  Help
    // ======================================================================

    private fun helpText(): String {
        val sb = StringBuilder()
        sb.appendLine("# How to use")
        sb.appendLine("Top card|Tap it for full Wi-Fi details")
        sb.appendLine("Devices|Tap a device to name it. NEW marks unknown ones")
        sb.appendLine("Signal Meter|Walk around, tap the tile again to stop")
        sb.appendLine("Create QR|Guests scan it to join your Wi-Fi")
        sb.appendLine("Network Watch|Checks every ~15 min while on Wi-Fi")
        sb.appendLine("# Limits")
        sb.appendLine("! Android only lets root apps read saved Wi-Fi passwords. Use Decode QR instead.")
        sb.appendLine("! Android 10+ hides MAC addresses, so device names and Network Watch are best effort.")
        sb.appendLine("! The home-screen widget cannot always show the Wi-Fi name because Android hides it from background apps.")
        sb.appendLine("! Port Scan is for your own devices only.")
        sb.appendLine("! Result details are in English. Menus and buttons can be switched to Bangla with the top button.")
        return sb.toString()
    }
}
