package com.wifitools.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ProgressBar
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.net.ConnectException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var resultTitle: TextView
    private lateinit var output: TextView
    private lateinit var progress: ProgressBar
    private lateinit var ssidText: TextView
    private lateinit var detailText: TextView

    private val cBg = Color.parseColor("#0B1220")
    private val cCard = Color.parseColor("#162032")
    private val cStroke = Color.parseColor("#26344D")
    private val cAccent = Color.parseColor("#38BDF8")
    private val cText = Color.parseColor("#F1F5F9")
    private val cMuted = Color.parseColor("#8FA3BF")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }

        val topHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(18))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher)
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = bg(Color.parseColor("#172B43"), 18)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        topHeader.addView(logo, LinearLayout.LayoutParams(dp(58), dp(58)))
        val titleStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titleStack.addView(label("WiFi Tools", 25f, cText, true))
        titleStack.addView(label("Your network, at a glance", 12f, cMuted).apply { setPadding(0, dp(3), 0, 0) })
        topHeader.addView(titleStack, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val liveBadge = label("● READY", 10f, Color.parseColor("#4ADE80"), true).apply {
            setPadding(dp(9), dp(7), dp(9), dp(7))
            background = bg(Color.parseColor("#142C2B"), 30)
        }
        topHeader.addView(liveBadge)
        root.addView(topHeader)

        // Status card (tap for full details)
        val status = card().apply {
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg(cCard, 22), null)
            isClickable = true
            setOnClickListener { runTask("Wi-Fi Info") { wifiInfoText() } }
        }
        status.addView(label("CONNECTED TO", 11f, cMuted, true))
        ssidText = label("-", 24f, cAccent, true).apply { setPadding(0, dp(4), 0, dp(4)) }
        status.addView(ssidText)
        detailText = label("", 13f, cMuted)
        status.addView(detailText)
        status.addView(label("Tap for full details", 11f, cMuted).apply { setPadding(0, dp(8), 0, 0) })
        addTo(root, status, 0)

        // Tool grid
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        row(grid,
            tile("\u26A1", "Speed Test", "Ping, download, upload") { runTask("Speed Test") { u -> speedTest(u) } },
            tile("\uD83C\uDF10", "ISP Check", "IP, provider, city") { runTask("ISP Check") { ispInfo() } })
        row(grid,
            tile("\uD83E\uDDED", "DNS Check", "Servers and latency") { runTask("DNS Check") { dnsCheck() } },
            tile("\uD83D\uDCE1", "Devices", "Who is on my network") { runTask("Connected Devices") { u -> scanDevices(u) } })
        row(grid,
            tile("\uD83D\uDD11", "Password", "Saved Wi-Fi (root only)") { runTask("Wi-Fi Password") { wifiPasswordRoot() } },
            tile("\uD83D\uDCF6", "Wi-Fi Settings", "Share password via QR") {
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            })
        addTo(root, grid, 12)

        // Result card
        val result = card().apply { setPadding(dp(20), dp(16), dp(20), dp(20)) }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        resultTitle = label("RESULT", 11f, cMuted, true)
        head.addView(resultTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(label("COPY", 11f, cAccent, true).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { copyOutput() }
        })
        result.addView(head)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(cAccent)
            visibility = View.GONE
        }
        result.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)).apply {
            topMargin = dp(8)
        })
        output = label("Tap a tool above to begin.", 13.5f, cText).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(0, dp(10), 0, 0)
        }
        result.addView(output)
        addTo(root, result, 10)

        val page = ScrollView(this).apply {
            setBackgroundColor(cBg)
            clipToPadding = false
            addView(root)
            alpha = 0f
        }
        val container = FrameLayout(this)
        container.addView(page, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        // Branded animated opening screen
        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#07111F"), Color.parseColor("#102B46"), Color.parseColor("#0B1220"))
            )
        }
        val splashLogo = ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher)
            scaleType = ImageView.ScaleType.FIT_CENTER
            alpha = 0f
            scaleX = 0.72f
            scaleY = 0.72f
            elevation = dp(12).toFloat()
        }
        splash.addView(splashLogo, LinearLayout.LayoutParams(dp(112), dp(112)).apply {
            bottomMargin = dp(24)
        })
        splash.addView(label("WiFi Tools", 30f, cText, true).apply {
            gravity = Gravity.CENTER
            alpha = 0f
        })
        splash.addView(label("SMART NETWORK UTILITIES", 11f, cAccent, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
            setPadding(0, dp(9), 0, dp(28))
            alpha = 0f
        })
        val splashProgress = ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(cAccent)
        }
        splash.addView(splashProgress, LinearLayout.LayoutParams(dp(42), dp(42)))
        container.addView(splash, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(container)

        splashLogo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).start()
        for (i in 1 until splash.childCount) {
            splash.getChildAt(i).animate().alpha(1f).setStartDelay(180L * i).setDuration(500).start()
        }
        page.animate().alpha(1f).setStartDelay(950).setDuration(500).start()
        splash.animate().alpha(0f).setStartDelay(1450).setDuration(350).withEndAction {
            container.removeView(splash)
        }.start()

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshHeader()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshHeader()
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun bg(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), cStroke)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(cCard, 22)
    }

    private fun addTo(parent: LinearLayout, v: View, topDp: Int) {
        parent.addView(v, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(topDp) })
    }

    private fun tile(icon: String, title: String, sub: String, action: () -> Unit): LinearLayout {
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg(cCard, 20), null)
            isClickable = true
            setOnClickListener { action() }
        }
        t.addView(label(icon, 28f, cText))
        t.addView(label(title, 16f, cText, true).apply { setPadding(0, dp(10), 0, dp(2)) })
        t.addView(label(sub, 12f, cMuted))
        return t
    }

    private fun row(parent: LinearLayout, a: View, b: View) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = dp(6)
        fun lp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { setMargins(m, m, m, m) }
        r.addView(a, lp())
        r.addView(b, lp())
        parent.addView(r, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(-m, 0, -m, 0) })
    }

    @Suppress("DEPRECATION")
    private fun refreshHeader() {
        val ip = localIpv4()
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        ssidText.text = currentSsid() ?: if (ip == null) "Not connected" else "Wi-Fi (name hidden)"
        detailText.text = if (ip == null) {
            "Connect to a Wi-Fi network"
        } else {
            "IP $ip  \u2022  ${info?.rssi ?: "-"} dBm  \u2022  ${info?.linkSpeed ?: "-"} Mbps"
        }
    }

    private fun copyOutput() {
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("result", output.text))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun runTask(title: String, block: suspend (update: (String) -> Unit) -> String) {
        resultTitle.text = title.uppercase()
        output.text = "Working..."
        progress.visibility = View.VISIBLE
        val update: (String) -> Unit = { msg -> runOnUiThread { output.text = msg } }
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) { block(update) }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            progress.visibility = View.GONE
            output.text = result
        }
    }

    // ---------- Network helpers ----------

    private fun cm() = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private fun linkProps() = cm().let { it.getLinkProperties(it.activeNetwork) }

    private fun localIpv4(): String? {
        val la = linkProps()?.linkAddresses?.firstOrNull { it.address is Inet4Address } ?: return null
        return la.address.hostAddress
    }

    private fun gatewayIp(): String? {
        val r = linkProps()?.routes?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
        return r?.gateway?.hostAddress
    }

    @Suppress("DEPRECATION")
    private fun currentSsid(): String? {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val s = wm.connectionInfo?.ssid?.trim('"') ?: return null
        return if (s == "<unknown ssid>" || s.isEmpty()) null else s
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 7000
        c.setRequestProperty("User-Agent", "WifiTools/1.0")
        return try {
            c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    // ---------- 1. Wi-Fi info ----------

    @Suppress("DEPRECATION")
    private fun wifiInfoText(): String {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val ssid = currentSsid()
        val sb = StringBuilder()
        sb.appendLine("SSID      : ${ssid ?: "unknown (allow Location permission and turn Location ON)"}")
        sb.appendLine("BSSID     : ${info?.bssid ?: "-"}")
        sb.appendLine("Signal    : ${info?.rssi ?: "-"} dBm")
        sb.appendLine("Link speed: ${info?.linkSpeed ?: "-"} Mbps")
        sb.appendLine("Frequency : ${info?.frequency ?: "-"} MHz")
        sb.appendLine("My IP     : ${localIpv4() ?: "-"}")
        sb.appendLine("Gateway   : ${gatewayIp() ?: "-"}")
        return sb.toString()
    }

    // ---------- 2. Speed test ----------

    private fun measurePing(): Long {
        val t = System.nanoTime()
        val c = URL("https://speed.cloudflare.com/__down?bytes=0").openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 5000
        c.inputStream.use { it.readBytes() }
        c.disconnect()
        return (System.nanoTime() - t) / 1_000_000
    }

    private fun speedTest(update: (String) -> Unit): String {
        val sb = StringBuilder()

        update("Testing latency...")
        try { measurePing() } catch (e: Exception) { /* warm-up */ }
        val pings = (1..5).mapNotNull { try { measurePing() } catch (e: Exception) { null } }
        if (pings.isEmpty()) return "No internet connection."
        val jitter = if (pings.size > 1) pings.zipWithNext { a, b -> Math.abs(a - b) }.average() else 0.0
        sb.appendLine("Ping  : ${pings.average().toLong()} ms (min ${pings.min()} ms)")
        sb.appendLine("Jitter: ${"%.1f".format(jitter)} ms")

        update("$sb\nTesting download...")
        val dc = URL("https://speed.cloudflare.com/__down?bytes=25000000").openConnection() as HttpURLConnection
        dc.connectTimeout = 7000
        dc.readTimeout = 10000
        var total = 0L
        val start = System.nanoTime()
        dc.inputStream.use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                total += n
                if (System.nanoTime() - start > 10_000_000_000L) break
            }
        }
        dc.disconnect()
        val dSecs = (System.nanoTime() - start) / 1e9
        sb.appendLine("Download: ${"%.2f".format(total * 8 / 1e6 / dSecs)} Mbps")

        update("$sb\nTesting upload...")
        val size = 8_000_000
        val uc = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
        uc.requestMethod = "POST"
        uc.doOutput = true
        uc.connectTimeout = 7000
        uc.readTimeout = 15000
        uc.setFixedLengthStreamingMode(size)
        val us = System.nanoTime()
        uc.outputStream.use { os ->
            val chunk = ByteArray(64 * 1024)
            var sent = 0
            while (sent < size) {
                val n = minOf(chunk.size, size - sent)
                os.write(chunk, 0, n)
                sent += n
            }
        }
        uc.responseCode
        uc.disconnect()
        val uSecs = (System.nanoTime() - us) / 1e9
        sb.appendLine("Upload  : ${"%.2f".format(size * 8 / 1e6 / uSecs)} Mbps")
        return sb.toString()
    }

    // ---------- 3. ISP check ----------

    private fun ispInfo(): String {
        val j = JSONObject(httpGet("https://ipinfo.io/json"))
        val sb = StringBuilder()
        sb.appendLine("Public IP: ${j.optString("ip", "-")}")
        sb.appendLine("ISP / ASN: ${j.optString("org", "-")}")
        sb.appendLine("City     : ${j.optString("city", "-")}")
        sb.appendLine("Region   : ${j.optString("region", "-")}")
        sb.appendLine("Country  : ${j.optString("country", "-")}")
        sb.appendLine("Timezone : ${j.optString("timezone", "-")}")
        return sb.toString()
    }

    // ---------- 4. DNS check ----------

    private fun dnsQuery(server: InetAddress, domain: String): Long {
        return try {
            val baos = ByteArrayOutputStream()
            val d = DataOutputStream(baos)
            d.writeShort(0x1234)
            d.writeShort(0x0100)
            d.writeShort(1)
            d.writeShort(0)
            d.writeShort(0)
            d.writeShort(0)
            for (label in domain.split(".")) {
                d.writeByte(label.length)
                d.write(label.toByteArray())
            }
            d.writeByte(0)
            d.writeShort(1)
            d.writeShort(1)
            val data = baos.toByteArray()
            val s = DatagramSocket()
            try {
                s.soTimeout = 3000
                val t = System.nanoTime()
                s.send(DatagramPacket(data, data.size, server, 53))
                val buf = ByteArray(512)
                s.receive(DatagramPacket(buf, buf.size))
                (System.nanoTime() - t) / 1_000_000
            } finally {
                s.close()
            }
        } catch (e: Exception) {
            -1L
        }
    }

    private fun fmtMs(ms: Long) = if (ms < 0) "timeout" else "$ms ms"

    private fun dnsCheck(): String {
        val sb = StringBuilder()
        val lp = linkProps()
        val servers = lp?.dnsServers ?: emptyList()

        sb.appendLine("== Your DNS servers ==")
        if (servers.isEmpty()) sb.appendLine("none found")
        for (s in servers) {
            sb.appendLine("${s.hostAddress}  ->  ${fmtMs(dnsQuery(s, "example.com"))}")
        }
        if (Build.VERSION.SDK_INT >= 28 && lp != null) {
            sb.appendLine("Private DNS: ${if (lp.isPrivateDnsActive) "ON (${lp.privateDnsServerName ?: "auto"})" else "OFF"}")
        }

        sb.appendLine()
        sb.appendLine("== Public DNS comparison ==")
        val publics = listOf("Google 8.8.8.8" to "8.8.8.8", "Cloudflare 1.1.1.1" to "1.1.1.1", "Quad9 9.9.9.9" to "9.9.9.9")
        for ((name, ip) in publics) {
            sb.appendLine("$name  ->  ${fmtMs(dnsQuery(InetAddress.getByName(ip), "example.com"))}")
        }

        sb.appendLine()
        sb.appendLine("== System resolver ==")
        val t = System.nanoTime()
        val r = try {
            InetAddress.getByName("www.wikipedia.org").hostAddress
        } catch (e: Exception) {
            "failed"
        }
        sb.appendLine("www.wikipedia.org -> $r (${(System.nanoTime() - t) / 1_000_000} ms)")
        return sb.toString()
    }

    // ---------- 5. Device scan ----------

    private fun isAlive(host: String): Boolean {
        val addr = InetAddress.getByName(host)
        try {
            if (addr.isReachable(400)) return true
        } catch (e: Exception) { }
        for (port in intArrayOf(80, 443, 53, 22, 445, 8080, 62078)) {
            val s = Socket()
            try {
                s.connect(InetSocketAddress(addr, port), 150)
                return true
            } catch (e: ConnectException) {
                return true // connection refused = a device exists there
            } catch (e: Exception) {
            } finally {
                try { s.close() } catch (e: Exception) { }
            }
        }
        return false
    }

    private fun hostName(host: String): String {
        return try {
            val n = InetAddress.getByName(host).canonicalHostName
            if (n == host) "-" else n
        } catch (e: Exception) {
            "-"
        }
    }

    private fun arpTable(): Map<String, String> = try {
        File("/proc/net/arp").readLines().drop(1).mapNotNull { line ->
            val p = line.trim().split(Regex("\\s+"))
            if (p.size >= 4 && p[3] != "00:00:00:00:00:00") p[0] to p[3] else null
        }.toMap()
    } catch (e: Exception) {
        emptyMap()
    }

    private suspend fun scanDevices(update: (String) -> Unit): String = coroutineScope {
        val me = localIpv4() ?: return@coroutineScope "Not connected to Wi-Fi."
        val gw = gatewayIp()
        val base = me.substringBeforeLast(".")
        val found = ConcurrentHashMap<String, String>()
        val sem = Semaphore(64)

        update("Scanning $base.1 - $base.254 ...\n(takes about 10 seconds)")
        (1..254).map { i ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    val host = "$base.$i"
                    if (host == me || isAlive(host)) found[host] = hostName(host)
                }
            }
        }.awaitAll()

        val arp = arpTable()
        val sb = StringBuilder()
        sb.appendLine("Found ${found.size} device(s):\n")
        for ((ip, name) in found.toSortedMap(compareBy<String> { it.substringAfterLast(".").toInt() })) {
            val tag = when (ip) {
                me -> " (this phone)"
                gw -> " (router)"
                else -> ""
            }
            sb.appendLine("$ip$tag")
            sb.appendLine("  name: $name")
            sb.appendLine("  MAC : ${arp[ip] ?: "hidden by Android"}")
        }
        sb.appendLine()
        sb.appendLine("Note: sleeping devices may not respond, and Android 10+ hides MAC addresses.")
        sb.toString()
    }

    // ---------- 6. Wi-Fi password (root only) ----------

    private fun wifiPasswordRoot(): String {
        val xml = try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "cat /data/misc/wifi/WifiConfigStore.xml"))
            p.inputStream.bufferedReader().readText()
        } catch (e: Exception) {
            ""
        }
        if (xml.isBlank()) {
            return "Root access not available.\n\n" +
                "Without root, use Android's own screen:\n" +
                "1. Tap 'Open Wi-Fi Settings (QR share)'\n" +
                "2. Tap the connected network\n" +
                "3. Tap 'Share' and confirm your PIN/fingerprint\n" +
                "4. The password is shown under the QR code."
        }
        val ssid = currentSsid()
        val saved = xml.split("<Network>").mapNotNull { b ->
            val s = Regex("name=\"SSID\">(.*?)</string>").find(b)?.groupValues?.get(1)?.replace("&quot;", "")
            val pw = Regex("name=\"PreSharedKey\">(.*?)</string>").find(b)?.groupValues?.get(1)?.replace("&quot;", "")
            if (s != null) s to (pw ?: "(open network, no password)") else null
        }
        val sb = StringBuilder()
        val match = saved.firstOrNull { it.first == ssid }
        if (match != null) {
            sb.appendLine("Connected: ${match.first}")
            sb.appendLine("Password : ${match.second}")
            sb.appendLine()
        }
        sb.appendLine("All saved networks on this phone:")
        for ((s, p) in saved) sb.appendLine("$s  ->  $p")
        return sb.toString()
    }
}
